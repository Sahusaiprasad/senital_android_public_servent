with open("app/src/main/java/com/example/ui/screens/AdminConsoleScreen.kt", "r") as f:
    text = f.read()

import re
text = re.sub(r'                    AdminComplaintTable\(viewModel = viewModel, complaints = complaints\)\n                }\n            }\n        }\n    }\n    }\n            }\n        }\n    } // end else\n} // end main column\n\n@Composable\nfun MetricCard', 
'''                    AdminComplaintTable(viewModel = viewModel, complaints = complaints)
                }
            }
        }
    } // end else
} // end main column

@Composable
fun MetricCard''', text)

with open("app/src/main/java/com/example/ui/screens/AdminConsoleScreen.kt", "w") as f:
    f.write(text)
