with open("app/src/main/java/com/example/ui/CivicViewModel.kt", "r") as f:
    content = f.read()

content = content.replace(
    'val formLocation = mutableStateOf("")',
    'val formLocation = mutableStateOf("")\n    val formLatitude = mutableStateOf<Double?>(null)\n    val formLongitude = mutableStateOf<Double?>(null)'
).replace(
    'val formattedLng = String.format("%.4f", lng)\n        formLocation.value = "Lat: $formattedLat, Lng: $formattedLng"',
    'val formattedLng = String.format("%.4f", lng)\n        formLocation.value = "Lat: $formattedLat, Lng: $formattedLng"\n        formLatitude.value = lat\n        formLongitude.value = lng'
).replace(
    'formLocation.value = ""\n        formAttachmentType.value = AttachmentType.NONE',
    'formLocation.value = ""\n        formLatitude.value = null\n        formLongitude.value = null\n        formAttachmentType.value = AttachmentType.NONE'
).replace(
    'location = location,',
    'location = location,\n                    latitude = formLatitude.value ?: (34.05 + (Math.random() - 0.5) * 0.1),\n                    longitude = formLongitude.value ?: (-118.24 + (Math.random() - 0.5) * 0.1),'
)

with open("app/src/main/java/com/example/ui/CivicViewModel.kt", "w") as f:
    f.write(content)
