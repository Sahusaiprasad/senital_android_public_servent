import re

with open("app/src/main/java/com/example/ui/screens/AdminConsoleScreen.kt", "r") as f:
    text = f.read()

pattern = r"val totalCount = complaints.size.*?// Sandbox Simulator Controller Card"

replacement = """val totalCount = complaints.size
    var currentTab by remember { mutableStateOf(0) }
    
    Column(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(20.dp).padding(bottom = 0.dp)) {
            // Console Header
            Text(
                text = "Official Admin Console",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Review incoming reports, manage dispatches, and update service timelines.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            
            TabRow(selectedTabIndex = currentTab) {
                Tab(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    text = { Text("Dashboard") }
                )
                Tab(
                    selected = currentTab == 1,
                    onClick = { currentTab = 1 },
                    text = { Text("Complaint Map") }
                )
            }
        }
        
        if (currentTab == 1) {
            AdminMapScreen(viewModel = viewModel, modifier = Modifier.weight(1f))
        } else {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
        // Sandbox Simulator Controller Card"""

text = re.sub(pattern, replacement, text, flags=re.DOTALL)

# Add closing braces
pattern2 = r"            }\n        }\n    }\n}\n\n@Composable\nfun MetricCard"
replacement2 = """            }
        }
    }
            } // end scroll column
        } // end else
    } // end main column
}

@Composable
fun MetricCard"""
text = re.sub(pattern2, replacement2, text, flags=re.DOTALL)

with open("app/src/main/java/com/example/ui/screens/AdminConsoleScreen.kt", "w") as f:
    f.write(text)
