with open("gradle/libs.versions.toml", "r") as f:
    text = f.read()

text = text.replace('\n[libraries]\n', '\n[libraries]\nmaps-compose-utils = { group = "com.google.maps.android", name = "maps-compose-utils", version = "4.4.1" }\n')
with open("gradle/libs.versions.toml", "w") as f:
    f.write(text)
