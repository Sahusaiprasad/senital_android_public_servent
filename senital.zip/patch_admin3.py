with open("app/src/main/java/com/example/ui/screens/AdminConsoleScreen.kt", "r") as f:
    text = f.read()

text = text.replace(
    '''    } // Close outer column
}

@Composable
fun MetricCard''',
    '''    }
            }
        }
    } // end else
} // end main column

@Composable
fun MetricCard'''
)

with open("app/src/main/java/com/example/ui/screens/AdminConsoleScreen.kt", "w") as f:
    f.write(text)
