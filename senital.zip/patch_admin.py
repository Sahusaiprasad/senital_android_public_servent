with open("app/src/main/java/com/example/ui/screens/AdminConsoleScreen.kt", "r") as f:
    text = f.read()

text = text.replace(
    '''import androidx.compose.runtime.getValue''',
    '''import androidx.compose.runtime.getValue\nimport androidx.compose.runtime.setValue\nimport androidx.compose.runtime.mutableStateOf\nimport androidx.compose.runtime.remember'''
)

text = text.replace(
    '''    val totalCount = complaints.size
    
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        // Console Header
        Text(
            text = "Official Admin Console",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = "Review incoming reports, manage dispatches, and update service timelines.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 20.dp)
        )''',
    '''    val totalCount = complaints.size
    var currentTab by remember { mutableStateOf(0) }
    
    Column(
        modifier = modifier.fillMaxSize()
    ) {
        Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
            // Console Header
            Text(
                text = "Official Admin Console",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Review incoming reports, manage dispatches, and update service timelines.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            
            TabRow(selectedTabIndex = currentTab) {
                Tab(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    text = { Text("Dashboard") }
                )
                Tab(
                    selected = currentTab == 1,
                    onClick = { currentTab = 1 },
                    text = { Text("Complaint Map") }
                )
            }
        }
        
        if (currentTab == 1) {
            AdminMapScreen(viewModel = viewModel, modifier = Modifier.weight(1f))
        } else {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
            ) {'''
)

text = text.replace(
    '''                }
            }
        }
    }
}

@Composable
fun MetricCard(''',
    '''                }
            }
        }
    }
    } // Close outer column
}

@Composable
fun MetricCard('''
)

with open("app/src/main/java/com/example/ui/screens/AdminConsoleScreen.kt", "w") as f:
    f.write(text)
