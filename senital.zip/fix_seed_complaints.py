import re

with open("app/src/main/java/com/example/data/repository/CivicRepository.kt", "r") as f:
    text = f.read()

# Pattern to find seed complaints and add userEmail
# userId = "..." followed by userName = "..."

def replacer(match):
    userId = match.group(1)
    return f'userId = {userId},\n                        userEmail = {userId},'

new_text = re.sub(r'userId\s*=\s*("[^"]+"),', replacer, text)

with open("app/src/main/java/com/example/data/repository/CivicRepository.kt", "w") as f:
    f.write(new_text)
