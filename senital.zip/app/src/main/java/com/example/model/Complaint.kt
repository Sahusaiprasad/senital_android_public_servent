package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ComplaintCategory(val displayName: String, val iconName: String) {
    ROADS("Roads & Potholes", "add_road"),
    WATER("Water Supply & Leaks", "water_drop"),
    ELECTRICITY("Power Outages & Lights", "bolt"),
    GARBAGE("Garbage & Waste", "delete_outline"),
    OTHER("Other Civic Issues", "info")
}

enum class ComplaintStatus {
    PENDING,
    PENDING_REVIEW,
    IN_PROGRESS,
    RESOLVED
}

enum class AttachmentType {
    NONE,
    PHOTO,
    AUDIO,
    VIDEO
}

data class Complaint(
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val location: String,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val status: String, // PENDING, IN_PROGRESS, RESOLVED
    val attachmentType: String, // NONE, PHOTO, AUDIO, VIDEO
    val attachmentUrl: String?,
    val timestamp: Long,
    val userId: String,
    val userEmail: String,
    val userName: String,
    val officialComment: String? = null,
    val adminNote: String? = null,
    val priority: String = "NORMAL",
    val upvoteCount: Int = 0,
    val severity: String = "LOW"
) {
    fun toEntity(): ComplaintEntity {
        return ComplaintEntity(
            id = id,
            title = title,
            description = description,
            category = category,
            location = location,
            latitude = latitude,
            longitude = longitude,
            status = status,
            attachmentType = attachmentType,
            attachmentUrl = attachmentUrl,
            timestamp = timestamp,
            userId = userId,
            userEmail = userEmail,
            userName = userName,
            officialComment = officialComment,
            adminNote = adminNote,
            priority = priority,
            upvoteCount = upvoteCount,
            severity = severity
        )
    }
}

@Entity(tableName = "complaints")
data class ComplaintEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val category: String,
    val location: String,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val status: String,
    val attachmentType: String,
    val attachmentUrl: String?,
    val timestamp: Long,
    val userId: String,
    val userEmail: String,
    val userName: String,
    val officialComment: String? = null,
    val adminNote: String? = null,
    val priority: String = "NORMAL",
    val upvoteCount: Int = 0,
    val severity: String = "LOW"
) {
    fun toDomain(): Complaint {
        return Complaint(
            id = id,
            title = title,
            description = description,
            category = category,
            location = location,
            latitude = latitude,
            longitude = longitude,
            status = status,
            attachmentType = attachmentType,
            attachmentUrl = attachmentUrl,
            timestamp = timestamp,
            userId = userId,
            userEmail = userEmail,
            userName = userName,
            officialComment = officialComment,
            adminNote = adminNote,
            priority = priority,
            upvoteCount = upvoteCount,
            severity = severity
        )
    }
}
