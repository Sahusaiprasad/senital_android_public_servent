package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Palette (Light)
val CivicPrimary = Color(0xFF2563EB) // Blue-600
val CivicSecondary = Color(0xFF3B82F6) // Blue-500
val CivicTertiary = Color(0xFF0D9488) // Teal-600
val CivicBackground = Color(0xFFF7F9FB) // Crisp light background
val CivicSurface = Color(0xFFFFFFFF) // White cards
val CivicSurfaceVariant = Color(0xFFF1F5F9) // Slate-100
val CivicOnSurfaceVariant = Color(0xFF64748B) // Slate-500
val CivicOutline = Color(0xFFE2E8F0) // Slate-200

// Clean Minimalism Palette (Dark)
val CivicPrimaryDark = Color(0xFF60A5FA)
val CivicSecondaryDark = Color(0xFF93C5FD)
val CivicTertiaryDark = Color(0xFF2DD4BF)
val CivicBackgroundDark = Color(0xFF0F172A)
val CivicSurfaceDark = Color(0xFF1E293B)
val CivicSurfaceVariantDark = Color(0xFF334155)
val CivicOnSurfaceVariantDark = Color(0xFF94A3B8)
val CivicOutlineDark = Color(0xFF475569)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

