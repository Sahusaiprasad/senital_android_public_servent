package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun ReportIssueFloatingActionPanel() {
    var isExpanded by remember { mutableStateOf(false) }
    
    // Pulse Animation
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.BottomEnd) {
        // FAB
        FloatingActionButton(
            onClick = { isExpanded = !isExpanded },
            modifier = Modifier
                .scale(if (isExpanded) 1f else scale)
                .size(64.dp)
                .background(
                    brush = Brush.linearGradient(listOf(Color(0xFF8B5CF6), Color(0xFFEC4899))),
                    shape = CircleShape
                ),
            containerColor = Color.Transparent,
            elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp)
        ) {
            Icon(
                imageVector = if (isExpanded) Icons.Filled.Close else Icons.Filled.Flag,
                contentDescription = "Report Issue",
                tint = Color.White,
                modifier = Modifier.size(32.dp)
            )
        }
        
        // ... rest of the code

        // Panel
        AnimatedVisibility(
            visible = isExpanded,
            enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(400, easing = LinearOutSlowInEasing)) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(300, easing = FastOutLinearInEasing)) + fadeOut()
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 600.dp)
                    .padding(bottom = 80.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Report an Issue", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { isExpanded = false }) {
                            Icon(Icons.Filled.Close, contentDescription = "Close")
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Severity Slider
                    var severity by remember { mutableStateOf(0f) }
                    val severityColor = when {
                        severity < 0.3f -> Color(0xFF10B981)
                        severity < 0.6f -> Color(0xFFF59E0B)
                        else -> Color(0xFFEF4444)
                    }
                    Text("Severity: ${when { severity < 0.3f -> "Low"; severity < 0.6f -> "Medium"; else -> "High" }}", fontWeight = FontWeight.Medium)
                    Slider(value = severity, onValueChange = { severity = it }, colors = SliderDefaults.colors(thumbColor = severityColor, activeTrackColor = severityColor))
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Issue Type
                    val issueTypes = listOf("Bug", "Feature", "UI", "Other")
                    var selectedType by remember { mutableStateOf(issueTypes[0]) }
                    Text("Issue Type", fontWeight = FontWeight.Medium)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        issueTypes.forEach { type ->
                            FilterChip(
                                selected = selectedType == type,
                                onClick = { selectedType = type },
                                label = { Text(type) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))

                    // Placeholder for other fields
                    OutlinedTextField(value = "", onValueChange = {}, label = { Text("Describe the issue...") }, modifier = Modifier.fillMaxWidth().height(100.dp))
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // File Upload
                    Box(modifier = Modifier.fillMaxWidth().height(60.dp).border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Text("Drag & Drop or Tap to Upload Screenshot", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Button(
                        onClick = { isExpanded = false },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Submit")
                    }
                }
            }
        }
    }
}
