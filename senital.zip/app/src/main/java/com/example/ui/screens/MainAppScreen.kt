package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.repository.SyncState
import com.example.ui.CivicViewModel
import com.example.ui.SubmissionState
import com.example.util.AppLanguage
import com.example.util.localized
import androidx.compose.foundation.BorderStroke

sealed class AppTab(val route: String, val title: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    object Feed : AppTab("feed", "Public Feed", Icons.Filled.ListAlt, Icons.Outlined.ListAlt)
    object Submit : AppTab("submit", "Report Issue", Icons.Filled.AddCircle, Icons.Outlined.AddCircle)
    object Admin : AppTab("admin", "Admin Hub", Icons.Filled.AdminPanelSettings, Icons.Outlined.AdminPanelSettings)
    object Profile : AppTab("profile", "My Profile", Icons.Filled.AccountCircle, Icons.Outlined.AccountCircle)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(
    viewModel: CivicViewModel,
    modifier: Modifier = Modifier
) {
    var currentTab by remember { mutableStateOf<AppTab>(AppTab.Feed) }
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val currentLang by viewModel.appLanguage.collectAsStateWithLifecycle()
    val submissionState by viewModel.submissionState.collectAsStateWithLifecycle()
    var showDiagnosticsDialog by remember { mutableStateOf(false) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch("android.permission.POST_NOTIFICATIONS")
        }
    }

    // Automatically switch back to Feed tab if submission is successful
    LaunchedEffect(submissionState) {
        if (submissionState is SubmissionState.Success) {
            currentTab = AppTab.Feed
            viewModel.resetSubmissionState()
        }
    }

    // Automatically switch away from Admin tab if user logs out or is not the designated admin
    LaunchedEffect(currentUser) {
        if (currentTab == AppTab.Admin && currentUser?.email?.equals("divyapalleti2006@gmail.com", ignoreCase = true) != true) {
            currentTab = AppTab.Feed
        }
    }

    if (showDiagnosticsDialog) {
        ConnectionDiagnosticsDialog(
            syncState = syncState,
            onSimulateSync = {
                viewModel.simulateIncomingRealtimeUpdate()
            },
            onDismiss = { showDiagnosticsDialog = false }
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        var logoTapCount by remember { mutableStateOf(0) }
                        var showAdminLoginDialog by remember { mutableStateOf(false) }

                        if (showAdminLoginDialog) {
                            AdminLoginDialog(
                                onDismiss = { showAdminLoginDialog = false; logoTapCount = 0 },
                                onLoginSuccess = { email, password ->
                                    // Normally we would make an API call to our new Node endpoint here.
                                    // For now, we simulate success if they match the seeded admin.
                                    viewModel.signInAdmin(email, password) { success ->
                                        if (success) {
                                            showAdminLoginDialog = false
                                            currentTab = AppTab.Admin
                                        } else {
                                            // Show error
                                        }
                                    }
                                }
                            )
                        }

                        Icon(
                            imageVector = Icons.Filled.LocationCity,
                            contentDescription = "City Connect Logo",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .size(32.dp)
                                .pointerInput(Unit) {
                                    detectTapGestures(
                                        onTap = {
                                            logoTapCount++
                                            if (logoTapCount >= 5) {
                                                showAdminLoginDialog = true
                                            }
                                        }
                                    )
                                }
                        )
                        Column {
                            Text(
                                text = "Senital".localized(currentLang),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Municipal Services Platform".localized(currentLang),
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    }
                },
                actions = {
                    // Sync status pill - Clickable connection indicator
                    Surface(
                        shape = MaterialTheme.shapes.extraLarge,
                        color = when (syncState) {
                            is SyncState.Synced -> MaterialTheme.colorScheme.primaryContainer
                            is SyncState.Syncing -> MaterialTheme.colorScheme.secondaryContainer
                            is SyncState.LocalOnly -> MaterialTheme.colorScheme.surfaceVariant
                        },
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .clickable { showDiagnosticsDialog = true }
                            .testTag("connection_indicator")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            val syncIcon = when (syncState) {
                                is SyncState.Synced -> Icons.Filled.CloudDone
                                is SyncState.Syncing -> Icons.Filled.Sync
                                is SyncState.LocalOnly -> Icons.Filled.CloudOff
                            }
                            val syncLabel = when (syncState) {
                                is SyncState.Synced -> "Synced".localized(currentLang)
                                is SyncState.Syncing -> "Syncing".localized(currentLang)
                                is SyncState.LocalOnly -> "Offline".localized(currentLang)
                            }
                            val syncColor = when (syncState) {
                                is SyncState.Synced -> MaterialTheme.colorScheme.primary
                                is SyncState.Syncing -> MaterialTheme.colorScheme.secondary
                                is SyncState.LocalOnly -> MaterialTheme.colorScheme.onSurfaceVariant
                            }

                            Icon(
                                imageVector = syncIcon,
                                contentDescription = syncLabel,
                                tint = syncColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = syncLabel,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = syncColor
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("bottom_nav_bar"),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                val tabs = if (currentUser?.isAdmin == true || currentUser?.email?.equals("divyapalleti2006@gmail.com", ignoreCase = true) == true) {
                    listOf(AppTab.Feed, AppTab.Submit, AppTab.Admin, AppTab.Profile)
                } else {
                    listOf(AppTab.Feed, AppTab.Submit, AppTab.Profile)
                }
                tabs.forEach { tab ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = tab },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                contentDescription = tab.title
                            )
                        },
                        label = {
                            Text(
                                text = tab.title.localized(currentLang),
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        modifier = Modifier.testTag("nav_tab_${tab.route}")
                    )
                }
            }
        },
        floatingActionButton = { ReportIssueFloatingActionPanel() },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (currentTab) {
                AppTab.Feed -> DashboardScreen(viewModel = viewModel, onNavigateToSubmit = { currentTab = AppTab.Submit })
                AppTab.Submit -> {
                    if (currentUser == null) {
                        PleaseSignInPrompt(
                            viewModel = viewModel,
                            onSignInSuccess = { currentTab = AppTab.Submit }
                        )
                    } else {
                        SubmitComplaintScreen(viewModel = viewModel)
                    }
                }
                AppTab.Admin -> {
                    if (currentUser?.isAdmin == true || currentUser?.email?.equals("divyapalleti2006@gmail.com", ignoreCase = true) == true) {
                        AdminConsoleScreen(viewModel = viewModel)
                    } else {
                        FeedScreen(viewModel = viewModel)
                    }
                }
                AppTab.Profile -> ProfileScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun PleaseSignInPrompt(
    viewModel: CivicViewModel,
    onSignInSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentLang by viewModel.appLanguage.collectAsStateWithLifecycle()
    
    var isSignUpMode by remember { mutableStateOf(false) }
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var confirmPasswordInput by remember { mutableStateOf("") }
    var nameInput by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var isConfirmPasswordVisible by remember { mutableStateOf(false) }
    
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var confirmPasswordError by remember { mutableStateOf<String?>(null) }
    var nameError by remember { mutableStateOf<String?>(null) }
    var authErrorMessage by remember { mutableStateOf<String?>(null) }
    var isAuthLoading by remember { mutableStateOf(false) }

    fun validateEmail(email: String): Boolean {
        val emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$".toRegex()
        return emailRegex.matches(email)
    }

    fun resetErrors() {
        emailError = null
        passwordError = null
        confirmPasswordError = null
        nameError = null
        authErrorMessage = null
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Floating Language selector at top
        LanguageSelector(
            viewModel = viewModel,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        Icon(
            imageVector = Icons.Filled.Lock,
            contentDescription = "Security lock icon",
            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
            modifier = Modifier.size(80.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Authentication Required".localized(currentLang),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "To submit, manage, or track public service complaints and reports, please sign up or sign in below.".localized(currentLang),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(modifier = Modifier.height(24.dp))
        
        // Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Title
                Text(
                    text = if (isSignUpMode) "Create an Account" else "Sign In to Senital",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                if (authErrorMessage != null) {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Error,
                                contentDescription = "Error icon",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = authErrorMessage ?: "",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // Role Selection
                var userRole by remember { mutableStateOf("Citizen") }

                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { 
                            userRole = "Citizen" 
                            if (emailInput == "divyapalleti2006@gmail.com") emailInput = ""
                            resetErrors()
                        }
                    ) {
                        androidx.compose.material3.RadioButton(
                            selected = userRole == "Citizen",
                            onClick = null
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Citizen")
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable {
                            userRole = "Admin"
                            emailInput = "divyapalleti2006@gmail.com"
                            passwordInput = "12345678"
                            resetErrors()
                        }
                    ) {
                        androidx.compose.material3.RadioButton(
                            selected = userRole == "Admin",
                            onClick = null
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Admin")
                    }
                }

                // Form Inputs
                if (isSignUpMode) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it; resetErrors() },
                        label = { Text("Full Name") },
                        singleLine = true,
                        enabled = !isAuthLoading,
                        shape = RoundedCornerShape(12.dp),
                        isError = nameError != null,
                        supportingText = { nameError?.let { Text(it) } },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) }
                    )
                }

                OutlinedTextField(
                    value = emailInput,
                    onValueChange = { emailInput = it; resetErrors() },
                    label = { Text("Email Address".localized(currentLang)) },
                    singleLine = true,
                    enabled = !isAuthLoading,
                    readOnly = userRole == "Admin",
                    shape = RoundedCornerShape(12.dp),
                    isError = emailError != null,
                    supportingText = { emailError?.let { Text(it) } },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    leadingIcon = { Icon(Icons.Filled.Email, contentDescription = null) }
                )

                OutlinedTextField(
                    value = passwordInput,
                    onValueChange = { passwordInput = it; resetErrors() },
                    label = { Text("Password") },
                    singleLine = true,
                    enabled = !isAuthLoading,
                    visualTransformation = if (isPasswordVisible) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    shape = RoundedCornerShape(12.dp),
                    isError = passwordError != null,
                    supportingText = { passwordError?.let { Text(it) } },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                    trailingIcon = {
                        IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                            Icon(
                                imageVector = if (isPasswordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                contentDescription = if (isPasswordVisible) "Hide password" else "Show password"
                            )
                        }
                    }
                )

                if (isSignUpMode) {
                    OutlinedTextField(
                        value = confirmPasswordInput,
                        onValueChange = { confirmPasswordInput = it; resetErrors() },
                        label = { Text("Confirm Password") },
                        singleLine = true,
                        enabled = !isAuthLoading,
                        visualTransformation = if (isConfirmPasswordVisible) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        shape = RoundedCornerShape(12.dp),
                        isError = confirmPasswordError != null,
                        supportingText = { confirmPasswordError?.let { Text(it) } },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                        leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                        trailingIcon = {
                            IconButton(onClick = { isConfirmPasswordVisible = !isConfirmPasswordVisible }) {
                                Icon(
                                    imageVector = if (isConfirmPasswordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    contentDescription = if (isConfirmPasswordVisible) "Hide password" else "Show password"
                                )
                            }
                        }
                    )
                } else {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                        TextButton(
                            onClick = {
                                if (emailInput.isBlank() || !validateEmail(emailInput)) {
                                    emailError = "Please enter a valid email to reset your password"
                                } else {
                                    isAuthLoading = true
                                    viewModel.resetPassword(
                                        emailInput,
                                        onSuccess = {
                                            isAuthLoading = false
                                            authErrorMessage = "Password reset link sent to your email (simulated)."
                                        },
                                        onFailure = { error ->
                                            isAuthLoading = false
                                            authErrorMessage = error
                                        }
                                    )
                                }
                            },
                            enabled = !isAuthLoading
                        ) {
                            Text("Forgot Password?", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Sign In / Sign Up Button
                Button(
                    onClick = {
                        resetErrors()
                        var isValid = true

                        if (isSignUpMode) {
                            if (nameInput.isBlank()) {
                                nameError = "Full name is required"
                                isValid = false
                            }
                        }
                        if (emailInput.isBlank() || !validateEmail(emailInput)) {
                            emailError = "Valid email is required"
                            isValid = false
                        }
                        if (passwordInput.isBlank()) {
                            passwordError = "Password is required"
                            isValid = false
                        } else if (passwordInput.length < 8) {
                            passwordError = "Password must be at least 8 characters"
                            isValid = false
                        }
                        if (isSignUpMode) {
                            if (confirmPasswordInput != passwordInput) {
                                confirmPasswordError = "Passwords do not match"
                                isValid = false
                            }
                        }

                        if (!isValid) return@Button

                        isAuthLoading = true
                        if (isSignUpMode) {
                            viewModel.signUpWithEmail(
                                email = emailInput.trim(),
                                password = passwordInput,
                                displayName = nameInput.trim(),
                                isAdmin = userRole == "Admin",
                                onSuccess = {
                                    isAuthLoading = false
                                    onSignInSuccess()
                                },
                                onFailure = { error ->
                                    isAuthLoading = false
                                    authErrorMessage = error
                                }
                            )
                        } else {
                            viewModel.signInWithEmail(
                                email = emailInput.trim(),
                                password = passwordInput,
                                onSuccess = {
                                    isAuthLoading = false
                                    onSignInSuccess()
                                },
                                onFailure = { error ->
                                    isAuthLoading = false
                                    authErrorMessage = "Invalid email or password"
                                }
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isAuthLoading
                ) {
                    if (isAuthLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    } else {
                        Text(if (isSignUpMode) "Register" else "Login")
                    }
                }
                
                // Toggle Mode Link
                TextButton(
                    onClick = {
                        isSignUpMode = !isSignUpMode
                        resetErrors()
                    },
                    enabled = !isAuthLoading
                ) {
                    Text(if (isSignUpMode) "Already have an account? Login" else "Don't have an account? Register")
                }
            }
        }
    }
}

@Composable
fun ConnectionDiagnosticsDialog(
    syncState: SyncState,
    onSimulateSync: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Wifi,
                    contentDescription = "Diagnostics Icon",
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Connection Diagnostics",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Status Section
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Connection Status",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val (icon, label, color) = when (syncState) {
                                is SyncState.Synced -> Triple(Icons.Filled.CloudDone, "Firestore Connected & Synced", MaterialTheme.colorScheme.primary)
                                is SyncState.Syncing -> Triple(Icons.Filled.Sync, "Synchronizing...", MaterialTheme.colorScheme.secondary)
                                is SyncState.LocalOnly -> Triple(Icons.Filled.CloudOff, "Local Offline Mode", MaterialTheme.colorScheme.error)
                            }
                            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
                            Text(text = label, fontWeight = FontWeight.Bold, color = color, fontSize = 14.sp)
                        }
                        
                        if (syncState is SyncState.LocalOnly) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Reason: ${syncState.reason}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Description
                Text(
                    text = "Senital runs offline-first with a local high-performance Room database, and automatically syncs to Google Cloud Firestore in real time once connected.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )

                // Setup Instructions if offline
                if (syncState is SyncState.LocalOnly) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                    
                    Text(
                        text = "To enable live cloud synchronization:",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    
                    Column(
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        BulletPoint("1. Register this package name in Firebase Console:\n   com.aistudio.civicconnect.jpxwyb")
                        BulletPoint("2. Download your google-services.json file.")
                        BulletPoint("3. Place it in the /app/ directory.")
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Button(
                        onClick = {
                            onSimulateSync()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Filled.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Simulate Live Firestore Update", fontSize = 13.sp)
                    }
                } else {
                    Text(
                        text = "✅ Real-time listeners are active! Every change from other users and administrators on Firestore will stream instantly onto this feed.",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun BulletPoint(text: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("•", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(text = text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun LanguageSelector(
    viewModel: CivicViewModel,
    modifier: Modifier = Modifier
) {
    val currentLang by viewModel.appLanguage.collectAsStateWithLifecycle()
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        Card(
            onClick = { expanded = true },
            shape = RoundedCornerShape(50),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Translate,
                    contentDescription = "Translate",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "${currentLang.flag} ${currentLang.displayName}",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(MaterialTheme.colorScheme.surface)
        ) {
            AppLanguage.entries.forEach { lang ->
                DropdownMenuItem(
                    leadingIcon = { Text(lang.flag, fontSize = 16.sp) },
                    text = {
                        Text(
                            text = lang.displayName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (currentLang == lang) FontWeight.Bold else FontWeight.Normal,
                            color = if (currentLang == lang) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    },
                    onClick = {
                        viewModel.updateLanguage(lang)
                        expanded = false
                    }
                )
            }
        }
    }
}
