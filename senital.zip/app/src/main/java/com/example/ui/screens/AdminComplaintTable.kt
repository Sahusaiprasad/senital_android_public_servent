package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Complaint
import com.example.model.ComplaintStatus
import com.example.ui.CivicViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminComplaintTable(viewModel: CivicViewModel, complaints: List<Complaint>) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedComplaint by remember { mutableStateOf<Complaint?>(null) }
    
    val filteredList = complaints.filter {
        searchQuery.isEmpty() || 
        it.userId.contains(searchQuery, ignoreCase = true) || 
        it.title.contains(searchQuery, ignoreCase = true)
    }.sortedByDescending { it.timestamp }

    Column(modifier = Modifier.fillMaxWidth().height(400.dp)) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by email or title...") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        Card(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
        ) {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("ID", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.15f), fontSize = 12.sp)
                        Text("Email", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.35f), fontSize = 12.sp)
                        Text("Status", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.25f), fontSize = 12.sp)
                        Text("Date", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.25f), fontSize = 12.sp)
                    }
                    Divider()
                }
                
                items(filteredList) { complaint ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedComplaint = complaint }
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(complaint.id.take(4), modifier = Modifier.weight(0.15f), fontSize = 12.sp)
                        Text(complaint.userEmail, modifier = Modifier.weight(0.35f), fontSize = 12.sp, maxLines = 1)
                        Text(complaint.status, modifier = Modifier.weight(0.25f), fontSize = 12.sp, maxLines = 1)
                        val dateString = SimpleDateFormat("MMM dd", Locale.getDefault()).format(Date(complaint.timestamp))
                        Text(dateString, modifier = Modifier.weight(0.25f), fontSize = 12.sp)
                    }
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                }
            }
        }
    }

    if (selectedComplaint != null) {
        var statusExpanded by remember { mutableStateOf(false) }
        var officialNote by remember { mutableStateOf(selectedComplaint!!.officialComment ?: "") }
        var adminNote by remember { mutableStateOf(selectedComplaint!!.adminNote ?: "") }
        var currentStatus by remember { mutableStateOf(ComplaintStatus.valueOf(selectedComplaint!!.status.uppercase())) }

        AlertDialog(
            onDismissRequest = { selectedComplaint = null },
            title = { Text("Complaint Details") },
            text = {
                Column {
                    Text("User: ${selectedComplaint!!.userEmail}", fontWeight = FontWeight.Bold)
                    Text("Category: ${selectedComplaint!!.category}")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Description:", fontWeight = FontWeight.Bold)
                    Text(selectedComplaint!!.description)
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text("Update Status:", fontWeight = FontWeight.Bold)
                    ExposedDropdownMenuBox(
                        expanded = statusExpanded,
                        onExpandedChange = { statusExpanded = !statusExpanded }
                    ) {
                        OutlinedTextField(
                            value = currentStatus.name,
                            onValueChange = {},
                            readOnly = true,
                            modifier = Modifier.menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = statusExpanded,
                            onDismissRequest = { statusExpanded = false }
                        ) {
                            ComplaintStatus.values().forEach { status ->
                                DropdownMenuItem(
                                    text = { Text(status.name) },
                                    onClick = {
                                        currentStatus = status
                                        statusExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = officialNote,
                        onValueChange = { officialNote = it },
                        label = { Text("Message to User (Email)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = adminNote,
                        onValueChange = { adminNote = it },
                        label = { Text("Internal Admin Note") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.updateComplaintStatus(selectedComplaint!!.id, currentStatus, officialNote, adminNote)
                    selectedComplaint = null
                }) {
                    Text("Update & Notify")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedComplaint = null }) { Text("Close") }
            }
        )
    }
}
