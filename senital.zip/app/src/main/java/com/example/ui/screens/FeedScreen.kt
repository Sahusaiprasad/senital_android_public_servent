package com.example.ui.screens

import android.text.format.DateUtils
import android.net.Uri
import android.media.MediaPlayer
import android.util.Log
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import com.example.model.AttachmentType
import com.example.model.Complaint
import com.example.model.ComplaintCategory
import com.example.model.ComplaintStatus
import com.example.ui.CivicViewModel
import com.example.util.AppLanguage
import com.example.util.localized

@Composable
fun FeedScreen(
    viewModel: CivicViewModel,
    modifier: Modifier = Modifier
) {
    val complaints by viewModel.filteredComplaints.collectAsStateWithLifecycle()
    val activeCategory by viewModel.selectedCategoryFilter.collectAsStateWithLifecycle()
    val activeStatus by viewModel.selectedStatusFilter.collectAsStateWithLifecycle()
    val sortByRecent by viewModel.sortByRecent.collectAsStateWithLifecycle()
    val currentLang by viewModel.appLanguage.collectAsStateWithLifecycle()
    
    var selectedComplaint by remember { mutableStateOf<Complaint?>(null) }
    var isMapViewActive by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Feed Header & Sorting Toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Community Issues Feed".localized(currentLang),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "${complaints.size} " + "active issues reported by citizens".localized(currentLang),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            IconButton(
                onClick = { viewModel.sortByRecent.value = !sortByRecent },
                colors = IconButtonDefaults.iconButtonColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                modifier = Modifier.testTag("sort_button")
            ) {
                Icon(
                    imageVector = if (sortByRecent) Icons.Filled.SwapVert else Icons.Filled.SwapVerticalCircle,
                    contentDescription = "Toggle Sort Order",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }

        // Category Filter Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = activeCategory == "ALL",
                onClick = { viewModel.selectedCategoryFilter.value = "ALL" },
                label = { Text("All".localized(currentLang)) },
                leadingIcon = { Icon(Icons.Default.Apps, contentDescription = null, modifier = Modifier.size(16.dp)) },
                modifier = Modifier.testTag("cat_filter_all")
            )
            
            ComplaintCategory.values().forEach { category ->
                val isSelected = activeCategory == category.name
                val icon = getCategoryIcon(category.name)
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.selectedCategoryFilter.value = category.name },
                    label = { Text(category.name.localized(currentLang)) },
                    leadingIcon = { Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("cat_filter_${category.name.lowercase()}")
                )
            }
        }

        // Status Filter Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = activeStatus == "ALL",
                onClick = { viewModel.selectedStatusFilter.value = "ALL" },
                label = { Text("All".localized(currentLang)) },
                modifier = Modifier.testTag("status_filter_all")
            )
            
            ComplaintStatus.values().forEach { status ->
                val isSelected = activeStatus == status.name
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.selectedStatusFilter.value = status.name },
                    label = { Text(status.name.localized(currentLang)) },
                    leadingIcon = {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(getStatusColor(status.name))
                        )
                    },
                    modifier = Modifier.testTag("status_filter_${status.name.lowercase()}")
                )
            }
        }

        // List vs Map Toggle Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                .padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (!isMapViewActive) MaterialTheme.colorScheme.primary else Color.Transparent)
                    .clickable { isMapViewActive = false }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.List,
                        contentDescription = "List view icon",
                        tint = if (!isMapViewActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Feed".localized(currentLang),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (!isMapViewActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isMapViewActive) MaterialTheme.colorScheme.primary else Color.Transparent)
                    .clickable { isMapViewActive = true }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Map,
                        contentDescription = "Map view icon",
                        tint = if (isMapViewActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Map View".localized(currentLang),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (isMapViewActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Complaint list / Map view or Empty state
        if (complaints.isEmpty()) {
            EmptyFeedState(
                hasFilters = activeCategory != "ALL" || activeStatus != "ALL",
                onClearFilters = {
                    viewModel.selectedCategoryFilter.value = "ALL"
                    viewModel.selectedStatusFilter.value = "ALL"
                }
            )
        } else {
            if (isMapViewActive) {
                CivicMapView(
                    complaints = complaints,
                    onSelectComplaint = { selectedComplaint = it },
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 16.dp)
                )
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("complaints_list"),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(complaints, key = { it.id }) { complaint ->
                        ComplaintCard(
                            complaint = complaint,
                            viewModel = viewModel,
                            onClick = { selectedComplaint = complaint },
                            modifier = Modifier.testTag("complaint_card_${complaint.id}")
                        )
                    }
                }
            }
        }
    }

    // Expanding Detail Dialog
    selectedComplaint?.let { complaint ->
        ComplaintDetailsDialog(
            complaint = complaint,
            viewModel = viewModel,
            onDismiss = { selectedComplaint = null }
        )
    }
}

@Composable
fun ComplaintCard(
    complaint: Complaint,
    viewModel: CivicViewModel,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isUrgent = complaint.priority == "URGENT"
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .border(
                if (isUrgent) 2.dp else 1.dp,
                if (isUrgent) Color(0xFFEF4444) else MaterialTheme.colorScheme.outline.copy(alpha = 0.7f),
                RoundedCornerShape(24.dp)
            ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isUrgent) 8.dp else 0.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isUrgent) Color(0xFFFEF2F2) else MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Category & Time & Priority Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val catIcon = getCategoryIcon(complaint.category)
                    val catColor = getCategoryColor(complaint.category)
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(catColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = catIcon,
                            contentDescription = complaint.category,
                            tint = catColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = formatCategoryText(complaint.category),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (isUrgent) {
                        Badge(containerColor = Color(0xFFEF4444)) {
                            Text("URGENT", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Text(
                    text = DateUtils.getRelativeTimeSpanString(
                        complaint.timestamp,
                        System.currentTimeMillis(),
                        DateUtils.MINUTE_IN_MILLIS
                    ).toString(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Title
            Text(
                text = complaint.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Description
            Text(
                text = complaint.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Upvote & Status Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { viewModel.upvoteComplaint(complaint.id) },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Icon(Icons.Filled.ThumbUp, contentDescription = "Upvote", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSecondaryContainer)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "${complaint.upvoteCount}", color = MaterialTheme.colorScheme.onSecondaryContainer)
                }

                StatusPill(status = complaint.status)
            }
        }
    }
}

@Composable
fun StatusPill(status: String, modifier: Modifier = Modifier) {
    val containerColor = getStatusColor(status).copy(alpha = 0.15f)
    val contentColor = getStatusColor(status)
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = containerColor,
        modifier = modifier
    ) {
        Text(
            text = formatStatusText(status),
            color = contentColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun EmptyFeedState(
    hasFilters: Boolean,
    onClearFilters: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = if (hasFilters) Icons.Filled.FilterAltOff else Icons.Filled.AssignmentTurnedIn,
            contentDescription = "No reports found",
            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
            modifier = Modifier.size(80.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = if (hasFilters) "No Matching Reports" else "All Quiet in Your City",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = if (hasFilters) "No issues match the selected category or status filter settings." else "There are no reported civic issues in this area right now. If you spot one, submit a request!",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(modifier = Modifier.height(20.dp))
        if (hasFilters) {
            Button(onClick = onClearFilters) {
                Text("Clear Active Filters")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComplaintDetailsDialog(
    complaint: Complaint,
    viewModel: CivicViewModel,
    onDismiss: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val isAdmin = currentUser?.isAdmin == true
    
    var officialCommentText by remember { mutableStateOf(complaint.officialComment ?: "") }
    var selectedStatus by remember { mutableStateOf(ComplaintStatus.valueOf(complaint.status)) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Issue Details", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Filled.ArrowBack, contentDescription = "Close")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            },
            modifier = Modifier.fillMaxSize()
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Category & Status Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(getCategoryColor(complaint.category).copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = getCategoryIcon(complaint.category),
                                contentDescription = null,
                                tint = getCategoryColor(complaint.category),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Text(
                            text = formatCategoryText(complaint.category),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    StatusPill(status = complaint.status, modifier = Modifier.scaleModifier(1.2f))
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Title
                Text(
                    text = complaint.title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Metadata Block
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(bottom = 6.dp)
                        ) {
                            Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Reported by: ${complaint.userName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(bottom = 6.dp)
                        ) {
                            Icon(Icons.Default.Place, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Location: ${complaint.location}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Date: " + android.text.format.DateFormat.format("yyyy-MM-dd hh:mm a", complaint.timestamp).toString(),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Description
                Text(
                    text = "Description",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = complaint.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 22.sp
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Attachment Rendering (if any)
                if (complaint.attachmentType != AttachmentType.NONE.name) {
                    Text(
                        text = "Attached Media Evidence",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    
                    AttachmentMediaRenderer(
                        type = complaint.attachmentType,
                        url = complaint.attachmentUrl,
                        category = complaint.category
                    )
                    
                    Spacer(modifier = Modifier.height(20.dp))
                }

                // Official Action Panel (Admin updates status, Citizens view updates)
                if (isAdmin) {
                    AdminOfficialCommentPanel(
                        selectedStatus = selectedStatus,
                        onStatusChange = { selectedStatus = it },
                        commentText = officialCommentText,
                        onCommentChange = { officialCommentText = it },
                        onUpdateSubmit = {
                            viewModel.updateComplaintStatus(complaint.id, selectedStatus, officialCommentText)
                            onDismiss()
                        }
                    )
                } else if (complaint.officialComment != null) {
                    CitizenResolutionView(
                        status = complaint.status,
                        comment = complaint.officialComment
                    )
                }
            }
        }
    }
}

fun getCategoryRealImageUrl(category: String): String {
    return when (category.uppercase()) {
        "ROADS" -> "https://images.unsplash.com/photo-1515162305285-0293e4767cc2?auto=format&fit=crop&q=80&w=800"
        "WATER" -> "https://images.unsplash.com/photo-1585800414768-d6787aaef7a5?auto=format&fit=crop&q=80&w=800"
        "ELECTRICITY" -> "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&q=80&w=800"
        "GARBAGE" -> "https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&q=80&w=800"
        else -> "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800"
    }
}

@Composable
fun AttachmentMediaRenderer(
    type: String,
    url: String?,
    category: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(180.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        when (type) {
            AttachmentType.PHOTO.name -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    val imageModel = if (url != null && (url.startsWith("http") || url.startsWith("content") || url.startsWith("file"))) {
                        url
                    } else {
                        getCategoryRealImageUrl(category)
                    }
                    AsyncImage(
                        model = imageModel,
                        contentDescription = "Complaint Evidence Photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    
                    // Dark scrim overlay for professional look and readable metadata
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f)),
                                    startY = 100f
                                )
                            )
                    )

                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "COMPLAINT EVIDENCE IMAGE",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        val photoLabel = if (url != null && (url.startsWith("http") || url.startsWith("content") || url.startsWith("file"))) {
                            url.substringAfterLast("/")
                        } else {
                            category.lowercase() + "_evidence_093.jpg"
                        }
                        Text(
                            text = "Reference: " + photoLabel,
                            fontSize = 10.sp,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }
                }
            }
            AttachmentType.AUDIO.name -> {
                val context = LocalContext.current
                var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
                var isPlaying by remember { mutableStateOf(false) }
                var playProgress by remember { mutableStateOf(0f) }
                var currentPositionMs by remember { mutableStateOf(0) }
                var durationMs by remember { mutableStateOf(0) }

                val isSimulated = url == null || (!url.startsWith("http") && !url.startsWith("file") && !url.startsWith("content"))

                DisposableEffect(url) {
                    onDispose {
                        try {
                            mediaPlayer?.release()
                        } catch (e: Exception) {}
                        mediaPlayer = null
                    }
                }

                // Periodic progress timer
                LaunchedEffect(isPlaying) {
                    while (isPlaying) {
                        if (isSimulated) {
                            kotlinx.coroutines.delay(200)
                            currentPositionMs += 200
                            if (durationMs > 0) {
                                playProgress = currentPositionMs.toFloat() / durationMs
                                if (currentPositionMs >= durationMs) {
                                    isPlaying = false
                                    playProgress = 0f
                                    currentPositionMs = 0
                                }
                            }
                        } else {
                            mediaPlayer?.let { mp ->
                                try {
                                    if (mp.isPlaying) {
                                        currentPositionMs = mp.currentPosition
                                        durationMs = mp.duration
                                        if (durationMs > 0) {
                                            playProgress = currentPositionMs.toFloat() / durationMs
                                        }
                                    } else {
                                        isPlaying = false
                                    }
                                } catch (e: Exception) {
                                    isPlaying = false
                                }
                            }
                            kotlinx.coroutines.delay(200)
                        }
                    }
                }

                val togglePlay = {
                    if (isSimulated) {
                        if (durationMs == 0) {
                            durationMs = 15000
                        }
                        isPlaying = !isPlaying
                    } else {
                        if (isPlaying) {
                            try {
                                mediaPlayer?.pause()
                            } catch (e: Exception) {}
                            isPlaying = false
                        } else {
                            if (mediaPlayer == null && url != null) {
                                try {
                                    mediaPlayer = MediaPlayer().apply {
                                        setDataSource(context, Uri.parse(url))
                                        prepare()
                                        setOnCompletionListener {
                                            isPlaying = false
                                            playProgress = 0f
                                            currentPositionMs = 0
                                        }
                                    }
                                    durationMs = mediaPlayer?.duration ?: 0
                                } catch (e: Exception) {
                                    Log.e("AttachmentMediaRenderer", "Error prepping MediaPlayer", e)
                                    Toast.makeText(context, "Could not play audio track.", Toast.LENGTH_SHORT).show()
                                }
                            }
                            try {
                                mediaPlayer?.start()
                                isPlaying = true
                            } catch (e: Exception) {
                                Log.e("AttachmentMediaRenderer", "Error starting player", e)
                            }
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(MaterialTheme.colorScheme.surface, MaterialTheme.colorScheme.surfaceVariant)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        IconButton(
                            onClick = { togglePlay() },
                            colors = IconButtonDefaults.iconButtonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = "Play Audio Evidence",
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                        
                        Column(modifier = Modifier.weight(1f)) {
                            val audioLabel = if (isSimulated) {
                                "Citizen Voice Memo.mp4"
                            } else {
                                url?.substringAfterLast("/") ?: "audio_evidence.mp3"
                            }
                            Text(
                                text = audioLabel,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val displayPos = currentPositionMs / 1000
                            val displayDur = if (durationMs > 0) durationMs / 1000 else 15
                            Text(
                                text = "0:${String.format("%02d", displayPos)} / 0:${String.format("%02d", displayDur)}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            // Simulated pulsating audio spectrum!
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.height(24.dp)
                            ) {
                                val heights = if (isPlaying) listOf(14, 8, 22, 16, 24, 12, 18, 10, 20, 6, 16) else listOf(10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10)
                                heights.forEach { height ->
                                    Box(
                                        modifier = Modifier
                                            .width(4.dp)
                                            .height(height.dp)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(
                                                if (isPlaying) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                                            )
                                    )
                                }
                            }
                        }
                    }
                }
            }
            AttachmentType.VIDEO.name -> {
                val context = LocalContext.current
                val isSimulated = url == null || (!url.startsWith("http") && !url.startsWith("file") && !url.startsWith("content"))

                val playVideoAction = {
                    if (!isSimulated && url != null) {
                        try {
                            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                setDataAndType(Uri.parse(url), "video/*")
                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Log.e("AttachmentMediaRenderer", "Error playing video intent", e)
                            Toast.makeText(context, "No player for this video. URL: $url", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        Toast.makeText(context, "Playing simulated high-fidelity video clip...", Toast.LENGTH_SHORT).show()
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable { playVideoAction() },
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = getCategoryRealImageUrl(category),
                        contentDescription = "Video Thumbnail",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    
                    // Dim/Overlay Scrim
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.5f))
                    )

                    Icon(
                        imageVector = Icons.Filled.PlayCircleFilled,
                        contentDescription = "Play Video Evidence",
                        tint = Color.White.copy(alpha = 0.9f),
                        modifier = Modifier.size(64.dp)
                    )

                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(12.dp)
                            .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(Color.Gray)
                        )
                        val videoLabel = if (isSimulated) {
                            "COMPLAINT_VIDEO_CLIP.MP4"
                        } else {
                            url?.substringAfterLast("/") ?: "video_evidence.mp4"
                        }
                        Text(
                            text = videoLabel.uppercase(),
                            fontSize = 10.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AdminOfficialCommentPanel(
    selectedStatus: ComplaintStatus,
    onStatusChange: (ComplaintStatus) -> Unit,
    commentText: String,
    onCommentChange: (String) -> Unit,
    onUpdateSubmit: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
        border = CardDefaults.outlinedCardBorder(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.AdminPanelSettings,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Official Action Panel",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = "Update Resolution Status",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(6.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ComplaintStatus.values().forEach { status ->
                    val isSelected = selectedStatus == status
                    val statusColor = getStatusColor(status.name)
                    
                    OutlinedButton(
                        onClick = { onStatusChange(status) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("admin_status_${status.name.lowercase()}"),
                        shape = RoundedCornerShape(8.dp),
                        colors = if (isSelected) ButtonDefaults.outlinedButtonColors(containerColor = statusColor.copy(alpha = 0.15f)) else ButtonDefaults.outlinedButtonColors(),
                        border = ButtonDefaults.outlinedButtonBorder().copy(
                            brush = Brush.linearGradient(
                                colors = if (isSelected) listOf(statusColor, statusColor) else listOf(MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                            )
                        )
                    ) {
                        Text(
                            text = formatStatusText(status.name),
                            color = if (isSelected) statusColor else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Official Comment / Actions Taken",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = commentText,
                onValueChange = onCommentChange,
                placeholder = { Text("Describe the dispatch action, crew report, or resolution timeline...", fontSize = 13.sp) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .testTag("admin_official_comment"),
                shape = RoundedCornerShape(10.dp),
                textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onUpdateSubmit,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_update_button")
            ) {
                Icon(imageVector = Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Save and Update Status")
            }
        }
    }
}

@Composable
fun CitizenResolutionView(
    status: String,
    comment: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Campaign,
                    contentDescription = null,
                    tint = getStatusColor(status)
                )
                Text(
                    text = "Official Update: " + formatStatusText(status),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = getStatusColor(status)
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = comment,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 20.sp
            )
        }
    }
}

// Utility Helpers
fun getCategoryIcon(category: String): ImageVector {
    return when (category.uppercase()) {
        "ROADS" -> Icons.Filled.AddRoad
        "WATER" -> Icons.Filled.WaterDrop
        "ELECTRICITY" -> Icons.Filled.Bolt
        "GARBAGE" -> Icons.Filled.DeleteOutline
        else -> Icons.Filled.Info
    }
}

fun getCategoryColor(category: String): Color {
    return when (category.uppercase()) {
        "ROADS" -> Color(0xFF64748B) // Slate-500
        "WATER" -> Color(0xFF2563EB) // Blue-600
        "ELECTRICITY" -> Color(0xFFD97706) // Amber-600
        "GARBAGE" -> Color(0xFF16A34A) // Green-600
        else -> Color(0xFF8B5CF6) // Violet-500
    }
}

fun getCategoryGradient(category: String): Brush {
    val primary = getCategoryColor(category)
    return Brush.verticalGradient(
        colors = listOf(primary, primary.copy(alpha = 0.6f))
    )
}

fun getStatusColor(status: String): Color {
    return when (status.uppercase()) {
        "PENDING" -> Color(0xFFEF4444) // Red-500
        "IN_PROGRESS" -> Color(0xFF2563EB) // Blue-600 (Clean Minimalism specific)
        "RESOLVED" -> Color(0xFF10B981) // Green-500
        else -> Color(0xFF64748B) // Slate-500
    }
}

fun formatStatusText(status: String): String {
    return when (status.uppercase()) {
        "PENDING" -> "Pending"
        "IN_PROGRESS" -> "In Progress"
        "RESOLVED" -> "Resolved"
        else -> status
    }
}

fun formatCategoryText(category: String): String {
    return when (category.uppercase()) {
        "ROADS" -> "Roads & Potholes"
        "WATER" -> "Water Supply"
        "ELECTRICITY" -> "Power Grid"
        "GARBAGE" -> "Garbage & Sanitation"
        else -> "Civic Incident"
    }
}

// Helper Modifier for scale mapping
fun Modifier.scaleModifier(scale: Float): Modifier = this

@Composable
fun CivicMapView(
    complaints: List<Complaint>,
    onSelectComplaint: (Complaint) -> Unit,
    modifier: Modifier = Modifier
) {
    val colorScheme = MaterialTheme.colorScheme
    var selectedMarker by remember { mutableStateOf<Complaint?>(null) }
    
    // Pulse animation for pins
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 2.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseScale"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseAlpha"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(24.dp))
            .background(colorScheme.surfaceVariant.copy(alpha = 0.15f))
            .border(1.dp, colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(complaints) {
                    detectTapGestures { offset ->
                        var closest: Complaint? = null
                        var minDist = Float.MAX_VALUE
                        
                        val w = size.width.toFloat()
                        val h = size.height.toFloat()
                        
                        for (c in complaints) {
                            val (lat, lng) = getComplaintCoordinates(c)
                            val minLat = 34.0450f
                            val maxLat = 34.0610f
                            val minLng = 118.2350f
                            val maxLng = 118.2550f
                            
                            val xPercent = 1.0f - ((lng - minLng) / (maxLng - minLng))
                            val yPercent = 1.0f - ((lat - minLat) / (maxLat - minLat))
                            
                            val markerX = xPercent * w
                            val markerY = yPercent * h
                            
                            val dist = Math.hypot((offset.x - markerX).toDouble(), (offset.y - markerY).toDouble()).toFloat()
                            if (dist < minDist && dist < 100f) { // Within 100px radius
                                minDist = dist
                                closest = c
                            }
                        }
                        selectedMarker = closest
                    }
                }
        ) {
            val w = size.width
            val h = size.height
            
            // 1. Draw grid / streets background
            val gridSpacing = 40.dp.toPx()
            val gridColor = colorScheme.outline.copy(alpha = 0.1f)
            
            for (x in 0..(w / gridSpacing).toInt()) {
                drawLine(
                    color = gridColor,
                    start = androidx.compose.ui.geometry.Offset(x * gridSpacing, 0f),
                    end = androidx.compose.ui.geometry.Offset(x * gridSpacing, h),
                    strokeWidth = 1.5.dp.toPx()
                )
            }
            for (y in 0..(h / gridSpacing).toInt()) {
                drawLine(
                    color = gridColor,
                    start = androidx.compose.ui.geometry.Offset(0f, y * gridSpacing),
                    end = androidx.compose.ui.geometry.Offset(w, y * gridSpacing),
                    strokeWidth = 1.5.dp.toPx()
                )
            }
            
            // 2. Draw Major Streets (aesthetic avenues)
            drawLine(
                color = colorScheme.outline.copy(alpha = 0.18f),
                start = androidx.compose.ui.geometry.Offset(0f, h * 0.25f),
                end = androidx.compose.ui.geometry.Offset(w, h * 0.45f),
                strokeWidth = 5.dp.toPx()
            )
            drawLine(
                color = colorScheme.outline.copy(alpha = 0.18f),
                start = androidx.compose.ui.geometry.Offset(w * 0.3f, 0f),
                end = androidx.compose.ui.geometry.Offset(w * 0.7f, h),
                strokeWidth = 6.dp.toPx()
            )
            
            // 3. Draw a River winding through
            val riverPath = Path().apply {
                moveTo(0f, h * 0.8f)
                cubicTo(w * 0.3f, h * 0.75f, w * 0.5f, h * 0.95f, w, h * 0.82f)
            }
            drawPath(
                path = riverPath,
                color = Color(0xFF60A5FA).copy(alpha = 0.35f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 20.dp.toPx(), cap = StrokeCap.Round)
            )
            
            // 4. Draw large Parks / green districts
            drawRoundRect(
                color = Color(0xFF10B981).copy(alpha = 0.1f),
                topLeft = androidx.compose.ui.geometry.Offset(w * 0.05f, h * 0.05f),
                size = androidx.compose.ui.geometry.Size(w * 0.32f, h * 0.16f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(16.dp.toPx())
            )
            drawRoundRect(
                color = Color(0xFF10B981).copy(alpha = 0.1f),
                topLeft = androidx.compose.ui.geometry.Offset(w * 0.62f, h * 0.55f),
                size = androidx.compose.ui.geometry.Size(w * 0.33f, h * 0.2f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(16.dp.toPx())
            )
            
            // 5. Draw Complaint Pins
            val minLat = 34.0450f
            val maxLat = 34.0610f
            val minLng = 118.2350f
            val maxLng = 118.2550f
            
            for (c in complaints) {
                val (lat, lng) = getComplaintCoordinates(c)
                val xPercent = 1.0f - ((lng - minLng) / (maxLng - minLng))
                val yPercent = 1.0f - ((lat - minLat) / (maxLat - minLat))
                
                val pinX = xPercent * w
                val pinY = yPercent * h
                
                val categoryColor = getCategoryColor(c.category)
                val isSelected = selectedMarker?.id == c.id
                
                // Pulsing Halo for active (Pending / In Progress) issues
                if (c.status.uppercase() != "RESOLVED") {
                    drawCircle(
                        color = categoryColor,
                        radius = (if (isSelected) 22.dp.toPx() else 14.dp.toPx()) * pulseScale,
                        center = androidx.compose.ui.geometry.Offset(pinX, pinY),
                        alpha = pulseAlpha
                    )
                }
                
                // Pin outer shadow / ring
                drawCircle(
                    color = Color.Black.copy(alpha = 0.15f),
                    radius = if (isSelected) 11.dp.toPx() else 7.5f.dp.toPx(),
                    center = androidx.compose.ui.geometry.Offset(pinX, pinY + 1.5f.dp.toPx())
                )
                
                // Pin fill
                drawCircle(
                    color = categoryColor,
                    radius = if (isSelected) 9.5f.dp.toPx() else 6.5f.dp.toPx(),
                    center = androidx.compose.ui.geometry.Offset(pinX, pinY)
                )
                
                // Pin center dot (white)
                drawCircle(
                    color = Color.White,
                    radius = if (isSelected) 4.dp.toPx() else 2.5f.dp.toPx(),
                    center = androidx.compose.ui.geometry.Offset(pinX, pinY)
                )
            }
        }
        
        // Floating map info overlay (labels)
        Box(
            modifier = Modifier
                .padding(12.dp)
                .background(colorScheme.surface.copy(alpha = 0.85f), RoundedCornerShape(12.dp))
                .border(1.dp, colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp)
                .align(Alignment.TopStart)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(Icons.Filled.Info, contentDescription = null, tint = colorScheme.primary, modifier = Modifier.size(14.dp))
                Text(
                    text = "Metropolitan Service Map",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = colorScheme.onSurface
                )
            }
        }

        // Selected Pin Card Overlay
        AnimatedVisibility(
            visible = selectedMarker != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
                .fillMaxWidth()
        ) {
            selectedMarker?.let { complaint ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectComplaint(complaint) },
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = colorScheme.surface),
                    border = BorderStroke(1.dp, colorScheme.outline.copy(alpha = 0.6f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        val catIcon = getCategoryIcon(complaint.category)
                        val catColor = getCategoryColor(complaint.category)
                        
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(catColor.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = catIcon,
                                contentDescription = null,
                                tint = catColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = formatCategoryText(complaint.category),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = catColor
                                )
                                Box(
                                    modifier = Modifier
                                        .size(4.dp)
                                        .clip(CircleShape)
                                        .background(colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
                                )
                                Text(
                                    text = formatStatusText(complaint.status),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = getStatusColor(complaint.status)
                                )
                            }
                            
                            Text(
                                text = complaint.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            
                            Text(
                                text = complaint.location,
                                fontSize = 11.sp,
                                color = colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        
                        IconButton(
                            onClick = { onSelectComplaint(complaint) },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = colorScheme.primaryContainer,
                                contentColor = colorScheme.primary
                            )
                        ) {
                            Icon(Icons.Filled.ArrowForwardIos, contentDescription = "View Details", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

fun parsePositiveCoordinates(locationString: String): Pair<Float, Float>? {
    try {
        val regex = """([0-9.]+)\s*N,\s*([0-9.]+)\s*W""".toRegex()
        val match = regex.find(locationString)
        if (match != null) {
            val lat = match.groupValues[1].toFloatOrNull()
            val lng = match.groupValues[2].toFloatOrNull()
            if (lat != null && lng != null) {
                return Pair(lat, lng)
            }
        }
    } catch (e: Exception) {}
    return null
}

fun getComplaintCoordinates(complaint: Complaint): Pair<Float, Float> {
    val coords = parsePositiveCoordinates(complaint.location)
    if (coords != null) return coords
    
    // Stable pseudo-random coords based on complaint ID hash
    val hash = Math.abs(complaint.id.hashCode())
    val rLat = 34.0450f + (hash % 1000 / 1000.0f) * (34.0610f - 34.0450f)
    val rLng = 118.2350f + ((hash / 1000) % 1000 / 1000.0f) * (118.2550f - 118.2350f)
    return Pair(rLat, rLng)
}
