package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.Complaint
import com.example.model.ComplaintStatus
import com.example.ui.CivicViewModel

@Composable
fun AdminConsoleScreen(
    viewModel: CivicViewModel,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val testingAdminToggle by viewModel.testingAdminToggle.collectAsStateWithLifecycle()
    val complaints by viewModel.filteredComplaints.collectAsStateWithLifecycle() // Can check all

    val pendingCount = complaints.count { it.status.uppercase() == "PENDING" }
    val pendingReviewCount = complaints.count { it.status.uppercase() == "PENDING_REVIEW" }
    val inProgressCount = complaints.count { it.status.uppercase() == "IN_PROGRESS" }
    val resolvedCount = complaints.count { it.status.uppercase() == "RESOLVED" }
    val totalCount = complaints.size
    var currentTab by remember { mutableStateOf(0) }
    
    Column(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(20.dp).padding(bottom = 0.dp)) {
            // Console Header
            Text(
                text = "Official Admin Console",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Review incoming reports, manage dispatches, and update service timelines.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            
            TabRow(selectedTabIndex = currentTab) {
                Tab(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    text = { Text("Dashboard") }
                )
                Tab(
                    selected = currentTab == 1,
                    onClick = { currentTab = 1 },
                    text = { Text("Complaint Map") }
                )
            }
        }
        
        if (currentTab == 1) {
            AdminMapScreen(viewModel = viewModel, modifier = Modifier.weight(1f))
        } else {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
        // Sandbox Simulator Controller Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
            ),
            shape = RoundedCornerShape(24.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Tune,
                        contentDescription = "Simulation Controller",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Review Mode Sandbox Controller",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                
                Text(
                    text = "This toggle simulates official administrative status instantly, giving you full access to update complaint resolution status in the feed without needing server-level permissions.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Enable Official Admin Mode",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = if (testingAdminToggle) "Logged in as Authorized Official" else "Logged in as Citizen / Guest",
                            fontSize = 11.sp,
                            color = if (testingAdminToggle) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Switch(
                        checked = testingAdminToggle,
                        onCheckedChange = { viewModel.toggleAdminMode(it) },
                        modifier = Modifier.testTag("admin_sim_toggle")
                    )
                }
            }
        }

        // Metrics Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                count = pendingCount,
                label = "Pending",
                color = Color(0xFFEF4444),
                icon = Icons.Filled.Warning,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                count = pendingReviewCount,
                label = "Review Queue",
                color = Color(0xFFF59E0B),
                icon = Icons.Filled.Rule,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                count = inProgressCount,
                label = "In Progress",
                color = Color(0xFF2563EB),
                icon = Icons.Filled.Engineering,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                count = resolvedCount,
                label = "Resolved",
                color = Color(0xFF10B981),
                icon = Icons.Filled.CheckCircle,
                modifier = Modifier.weight(1f)
            )
        }

        // Category Breakdown
        Text(
            text = "Issues by Category",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                com.example.model.ComplaintCategory.values().forEach { category ->
                    val count = complaints.count { it.category.equals(category.name, true) }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = category.displayName, style = MaterialTheme.typography.bodyMedium)
                        Text(text = count.toString(), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Visual Distribution Chart (Canvas drawing)
        Text(
            text = "Resolution Analytics Status",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    // Donut Chart Drawing with Canvas
                    Box(
                        modifier = Modifier.size(96.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val strokeWidth = 12.dp.toPx()
                            val sizeMin = size.minDimension
                            val radius = (sizeMin - strokeWidth) / 2
                            
                            // Calculate sweeps
                            val total = totalCount.toFloat().coerceAtLeast(1f)
                            val pSweep = (pendingCount / total) * 360f
                            val iSweep = (inProgressCount / total) * 360f
                            val rSweep = (resolvedCount / total) * 360f

                            // Draw arc sectors
                            drawArc(
                                color = Color(0xFFEF4444),
                                startAngle = -90f,
                                sweepAngle = pSweep,
                                useCenter = false,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                            drawArc(
                                color = Color(0xFF2563EB),
                                startAngle = -90f + pSweep,
                                sweepAngle = iSweep,
                                useCenter = false,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                            drawArc(
                                color = Color(0xFF10B981),
                                startAngle = -90f + pSweep + iSweep,
                                sweepAngle = rSweep,
                                useCenter = false,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                        }
                        
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = totalCount.toString(),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "TOTAL",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Chart Legends
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        LegendItem(color = Color(0xFFEF4444), label = "Pending Action", count = pendingCount, percentage = getPercentage(pendingCount, totalCount))
                        LegendItem(color = Color(0xFF2563EB), label = "Active Crew Dispatched", count = inProgressCount, percentage = getPercentage(inProgressCount, totalCount))
                        LegendItem(color = Color(0xFF10B981), label = "Successfully Resolved", count = resolvedCount, percentage = getPercentage(resolvedCount, totalCount))
                    }
                }
            }
        }

        // Quick Admin Resolution Panel
        if (testingAdminToggle) {
            Text(
                text = "Rapid Dispatches & Resolution",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(24.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    val pendingIssues = complaints.filter { it.status.uppercase() == "PENDING" }.take(3)
                    
                    AdminComplaintTable(viewModel = viewModel, complaints = complaints)
                }
            }
        }
        } // end of Column
    } // end else
} // end main column
} // end AdminConsoleScreen

@Composable
fun MetricCard(
    count: Int,
    label: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.height(100.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(14.dp)
                    )
                }
                Text(
                    text = count.toString(),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = color
                )
            }
            
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun LegendItem(
    color: Color,
    label: String,
    count: Int,
    percentage: Int
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        
        Text(
            text = "$count ($percentage%)",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

fun getPercentage(value: Int, total: Int): Int {
    if (total == 0) return 0
    return ((value.toFloat() / total.toFloat()) * 100f).toInt()
}
