package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.Complaint
import com.example.ui.CivicViewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(viewModel: CivicViewModel, onNavigateToSubmit: () -> Unit) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val complaints by viewModel.filteredComplaints.collectAsStateWithLifecycle()
    
    var isLoading by remember { mutableStateOf(true) }
    var isRefreshing by remember { mutableStateOf(false) }

    // Simulated data fetching
    LaunchedEffect(Unit) {
        delay(1500)
        isLoading = false
    }
    
    // Polling simulation every 30 seconds
    LaunchedEffect(Unit) {
        while(true) {
            delay(30000)
            // viewModel.forceRefresh() // In real app
        }
    }

    if (isLoading) {
        DashboardSkeleton()
        return
    }

    val pullRefreshState = remember { mutableStateOf(false) } // Use simple state for mock refresh

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Greeting Header
            item {
                val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
                val greeting = when (hour) {
                    in 0..11 -> "Good morning"
                    in 12..16 -> "Good afternoon"
                    else -> "Good evening"
                }
                val name = currentUser?.displayName ?: "Citizen"
                val dateFormat = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())
                val today = dateFormat.format(Date())

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = today,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    Text(
                        text = "$greeting, $name",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                IconButton(onClick = { /* Navigate to profile */ }) {
                    Icon(Icons.Default.Person, contentDescription = "Profile", tint = MaterialTheme.colorScheme.primary)
                }
            }

            // Announcements Carousel
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    AnnouncementCard(
                        title = "Water Main Maintenance",
                        desc = "Downtown area may experience low pressure today from 2 PM - 5 PM.",
                        color = Color(0xFF1E88E5),
                        icon = Icons.Filled.WaterDrop
                    )
                    AnnouncementCard(
                        title = "City Hall Closed",
                        desc = "Offices closed this Friday for Civic Holiday. Online services available.",
                        color = Color(0xFFE53935),
                        icon = Icons.Filled.AccountBalance
                    )
                }
            }

            // Quick Stats
            item {
                val activeCount = complaints.count { it.status == "PENDING" || it.status == "IN_PROGRESS" }
                val resolvedCount = complaints.count { it.status == "RESOLVED" }
                
                var visible by remember { mutableStateOf(false) }
                LaunchedEffect(Unit) { visible = true }

                AnimatedVisibility(
                    visible = visible,
                    enter = fadeIn(animationSpec = tween(500)) + slideInVertically(initialOffsetY = { 50 }, animationSpec = tween(500))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        StatCard(title = "Active\nComplaints", value = activeCount.toString(), modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.primary)
                        StatCard(title = "Resolved\nThis Month", value = resolvedCount.toString(), modifier = Modifier.weight(1f), color = Color(0xFF10B981))
                        StatCard(title = "Next Bill\nDue In", value = "5 Days", modifier = Modifier.weight(1f), color = Color(0xFFF59E0B))
                    }
                }
            }

            // Quick Actions
            item {
                Text(
                    text = "Quick Actions",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 20.dp, end = 20.dp, bottom = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    QuickActionButton(
                        icon = Icons.Filled.WaterDrop,
                        label = "Water",
                        onClick = {
                            viewModel.formCategory.value = com.example.model.ComplaintCategory.WATER
                            onNavigateToSubmit()
                        }
                    )
                    QuickActionButton(
                        icon = Icons.Filled.Bolt,
                        label = "Electricity",
                        onClick = {
                            viewModel.formCategory.value = com.example.model.ComplaintCategory.ELECTRICITY
                            onNavigateToSubmit()
                        }
                    )
                    QuickActionButton(
                        icon = Icons.Filled.Delete,
                        label = "Drainage",
                        onClick = {
                            viewModel.formCategory.value = com.example.model.ComplaintCategory.GARBAGE // Or DRAINAGE
                            onNavigateToSubmit()
                        }
                    )
                    QuickActionButton(
                        icon = Icons.Filled.TrackChanges,
                        label = "Track",
                        onClick = { /* Navigate to profile */ }
                    )
                }
            }

            // Recent Activity Feed
            item {
                Text(
                    text = "Recent Activity",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
            }

            val recentActivity = complaints.take(4) // Just using complaints as activity feed
            if (recentActivity.isEmpty()) {
                item {
                    Text(
                        text = "No recent activity found.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
                    )
                }
            } else {
                items(recentActivity) { activity ->
                    ActivityFeedItem(activity = activity)
                }
            }
            
            // Link to old feed
            item {
                TextButton(
                    onClick = { /* Would navigate to full feed */ },
                    modifier = Modifier.padding(horizontal = 12.dp)
                ) {
                    Text("View Full Public Feed")
                }
            }
        }
    }
}

@Composable
fun AnnouncementCard(title: String, desc: String, color: Color, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(
        modifier = Modifier
            .width(280.dp)
            .height(110.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.1f)),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold, color = color, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 16.sp)
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier, color: Color) {
    Card(
        modifier = modifier.height(100.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = color)
            Text(title, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 14.sp)
        }
    }
}

@Composable
fun QuickActionButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = MaterialTheme.colorScheme.primary)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(label, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun ActivityFeedItem(activity: Complaint) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.Top
    ) {
        val color = when(activity.status) {
            "RESOLVED" -> Color(0xFF10B981)
            "IN_PROGRESS" -> Color(0xFF2563EB)
            else -> Color(0xFFF59E0B)
        }
        
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Notifications, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
        }
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    text = "Status updated to ${activity.status}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = SimpleDateFormat("MMM dd", Locale.getDefault()).format(Date(activity.timestamp)),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Your complaint '${activity.title}' was updated.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun DashboardSkeleton() {
    val infiniteTransition = rememberInfiniteTransition()
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(20.dp)
    ) {
        Box(modifier = Modifier.width(120.dp).height(14.dp).background(Color.Gray.copy(alpha = alpha), RoundedCornerShape(4.dp)))
        Spacer(modifier = Modifier.height(8.dp))
        Box(modifier = Modifier.width(200.dp).height(28.dp).background(Color.Gray.copy(alpha = alpha), RoundedCornerShape(4.dp)))
        
        Spacer(modifier = Modifier.height(24.dp))
        Box(modifier = Modifier.fillMaxWidth().height(110.dp).background(Color.Gray.copy(alpha = alpha), RoundedCornerShape(16.dp)))
        
        Spacer(modifier = Modifier.height(24.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(modifier = Modifier.weight(1f).height(100.dp).background(Color.Gray.copy(alpha = alpha), RoundedCornerShape(16.dp)))
            Box(modifier = Modifier.weight(1f).height(100.dp).background(Color.Gray.copy(alpha = alpha), RoundedCornerShape(16.dp)))
            Box(modifier = Modifier.weight(1f).height(100.dp).background(Color.Gray.copy(alpha = alpha), RoundedCornerShape(16.dp)))
        }
        
        Spacer(modifier = Modifier.height(32.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            repeat(4) {
                Box(modifier = Modifier.size(56.dp).background(Color.Gray.copy(alpha = alpha), CircleShape))
            }
        }
    }
}
