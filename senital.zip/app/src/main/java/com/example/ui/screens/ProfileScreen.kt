package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.model.Complaint
import com.example.ui.CivicViewModel

@Composable
fun ProfileScreen(
    viewModel: CivicViewModel,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val complaints by viewModel.filteredComplaints.collectAsStateWithLifecycle()

    var showSignInSelection by remember { mutableStateOf(false) }
    var selectedComplaintForDetail by remember { mutableStateOf<Complaint?>(null) }
    
    var isSignUpMode by remember { mutableStateOf(false) }
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var confirmPasswordInput by remember { mutableStateOf("") }
    var nameInput by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var isConfirmPasswordVisible by remember { mutableStateOf(false) }
    
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var confirmPasswordError by remember { mutableStateOf<String?>(null) }
    var nameError by remember { mutableStateOf<String?>(null) }
    var authErrorMessage by remember { mutableStateOf<String?>(null) }
    var isAuthLoading by remember { mutableStateOf(false) }
    
    fun validateEmail(email: String): Boolean {
        val emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$".toRegex()
        return emailRegex.matches(email)
    }

    fun resetErrors() {
        emailError = null
        passwordError = null
        confirmPasswordError = null
        nameError = null
        authErrorMessage = null
    }

    val myComplaints = remember(complaints, currentUser) {
        val email = currentUser?.email
        if (email == null) emptyList()
        else complaints.filter { it.userId == email }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Header
        Text(
            text = "User Profile Hub",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(vertical = 12.dp)
        )

        currentUser?.let { user ->
            // Signed-In User Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // User Avatar image loading
                        if (user.photoUrl != null) {
                            AsyncImage(
                                model = user.photoUrl,
                                contentDescription = "User Profile Picture",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                            )
                        } else {
                            // Letter avatar placeholder
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = user.displayName.firstOrNull()?.uppercase() ?: "G",
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = user.displayName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = user.email,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            
                            Spacer(modifier = Modifier.height(6.dp))

                            // Role Badge
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (user.isAdmin) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer,
                                modifier = Modifier.testTag("role_badge")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = if (user.isAdmin) Icons.Filled.AdminPanelSettings else Icons.Filled.Person,
                                        contentDescription = null,
                                        tint = if (user.isAdmin) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Text(
                                        text = if (user.isAdmin) "Official Administrator" else "Verified Citizen",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (user.isAdmin) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { viewModel.signOut() },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.testTag("signout_button")
                        ) {
                            Icon(imageVector = Icons.Filled.ExitToApp, contentDescription = "Log out", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Log Out", color = MaterialTheme.colorScheme.error, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { showSignInSelection = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.testTag("switch_account_button")
                        ) {
                            Text("Switch Account", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        }
                    }
                }
            }

            // Citizen Submission History
            Text(
                text = "My Submitted Reports (${myComplaints.size})",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            if (myComplaints.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(imageVector = Icons.Filled.DriveFileRenameOutline, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No Submissions Yet",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Any complaints or requests you file will be tracked here in real-time.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp),
                    modifier = Modifier.testTag("user_complaints_list")
                ) {
                    items(myComplaints, key = { it.id }) { complaint ->
                        ComplaintCard(
                            complaint = complaint,
                            viewModel = viewModel,
                            onClick = { selectedComplaintForDetail = complaint },
                            modifier = Modifier.testTag("user_complaint_card_${complaint.id}")
                        )
                    }
                }
            }

        } ?: run {
            // Signed-Out State
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Filled.AccountCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Access Your Civic Identity",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "Sign in to securely submit official service request complaints, view dispatches, and get real-time resolution alerts.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                    )
                    
                    Button(
                        onClick = { showSignInSelection = true },
                        modifier = Modifier.fillMaxWidth().testTag("primary_signin_trigger")
                    ) {
                        Icon(imageVector = Icons.Filled.Login, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Sign In / Create Account")
                    }
                }
            }
        }
    }

    // Account choice sheet/dialog
    if (showSignInSelection) {
        Dialog(onDismissRequest = { if (!isAuthLoading) showSignInSelection = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header Title
                    Text(
                        text = if (isSignUpMode) "Create an Account" else "Sign In to Senital",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // Validation Error Banner
                    if (authErrorMessage != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Error,
                                    contentDescription = "Error icon",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = authErrorMessage ?: "",
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    // Role Selection
                    var userRole by remember { mutableStateOf("Citizen") }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { 
                                userRole = "Citizen" 
                                if (emailInput == "divyapalleti2006@gmail.com") emailInput = ""
                                resetErrors()
                            }
                        ) {
                            androidx.compose.material3.RadioButton(
                                selected = userRole == "Citizen",
                                onClick = null
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Citizen")
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable {
                                userRole = "Admin"
                                emailInput = "divyapalleti2006@gmail.com"
                                passwordInput = "12345678"
                                resetErrors()
                            }
                        ) {
                            androidx.compose.material3.RadioButton(
                                selected = userRole == "Admin",
                                onClick = null
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Admin")
                        }
                    }

                    // Form Inputs
                    if (isSignUpMode) {
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it; resetErrors() },
                            label = { Text("Full Name") },
                            placeholder = { Text("e.g. John Doe") },
                            singleLine = true,
                            enabled = !isAuthLoading,
                            shape = RoundedCornerShape(12.dp),
                            isError = nameError != null,
                            supportingText = { nameError?.let { Text(it) } },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                            leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) }
                        )
                    }

                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = { emailInput = it; resetErrors() },
                        label = { Text("Email Address") },
                        placeholder = { Text("e.g. user@example.com") },
                        singleLine = true,
                        enabled = !isAuthLoading,
                        readOnly = userRole == "Admin",
                        shape = RoundedCornerShape(12.dp),
                        isError = emailError != null,
                        supportingText = { emailError?.let { Text(it) } },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        leadingIcon = { Icon(Icons.Filled.Email, contentDescription = null) }
                    )

                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = { passwordInput = it; resetErrors() },
                        label = { Text("Password") },
                        placeholder = { Text("Min 8 characters") },
                        singleLine = true,
                        enabled = !isAuthLoading,
                        visualTransformation = if (isPasswordVisible) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        shape = RoundedCornerShape(12.dp),
                        isError = passwordError != null,
                        supportingText = { passwordError?.let { Text(it) } },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                        trailingIcon = {
                            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                Icon(
                                    imageVector = if (isPasswordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    contentDescription = if (isPasswordVisible) "Hide password" else "Show password"
                                )
                            }
                        }
                    )

                    if (isSignUpMode) {
                        OutlinedTextField(
                            value = confirmPasswordInput,
                            onValueChange = { confirmPasswordInput = it; resetErrors() },
                            label = { Text("Confirm Password") },
                            placeholder = { Text("Re-enter password") },
                            singleLine = true,
                            enabled = !isAuthLoading,
                            visualTransformation = if (isConfirmPasswordVisible) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                            shape = RoundedCornerShape(12.dp),
                            isError = confirmPasswordError != null,
                            supportingText = { confirmPasswordError?.let { Text(it) } },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                            trailingIcon = {
                                IconButton(onClick = { isConfirmPasswordVisible = !isConfirmPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isConfirmPasswordVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                        contentDescription = if (isConfirmPasswordVisible) "Hide password" else "Show password"
                                    )
                                }
                            }
                        )
                    } else {
                        // Forgot Password Link
                        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                            TextButton(
                                onClick = {
                                    if (emailInput.isBlank() || !validateEmail(emailInput)) {
                                        emailError = "Please enter a valid email to reset your password"
                                    } else {
                                        isAuthLoading = true
                                        viewModel.resetPassword(
                                            emailInput,
                                            onSuccess = {
                                                isAuthLoading = false
                                                authErrorMessage = "Password reset link sent to your email (simulated)."
                                            },
                                            onFailure = { error ->
                                                isAuthLoading = false
                                                authErrorMessage = error
                                            }
                                        )
                                    }
                                },
                                enabled = !isAuthLoading
                            ) {
                                Text("Forgot Password?", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    // Main Action Button
                    Button(
                        onClick = {
                            resetErrors()
                            var isValid = true

                            if (isSignUpMode) {
                                if (nameInput.isBlank()) {
                                    nameError = "Full name is required"
                                    isValid = false
                                }
                            }
                            if (emailInput.isBlank() || !validateEmail(emailInput)) {
                                emailError = "Valid email is required"
                                isValid = false
                            }
                            if (passwordInput.isBlank()) {
                                passwordError = "Password is required"
                                isValid = false
                            } else if (passwordInput.length < 8) {
                                passwordError = "Password must be at least 8 characters"
                                isValid = false
                            }
                            if (isSignUpMode) {
                                if (confirmPasswordInput != passwordInput) {
                                    confirmPasswordError = "Passwords do not match"
                                    isValid = false
                                }
                            }

                            if (!isValid) return@Button

                            isAuthLoading = true
                            if (isSignUpMode) {
                                viewModel.signUpWithEmail(
                                    email = emailInput.trim(),
                                    password = passwordInput,
                                    displayName = nameInput.trim(),
                                    isAdmin = userRole == "Admin",
                                    onSuccess = {
                                        isAuthLoading = false
                                        showSignInSelection = false
                                    },
                                    onFailure = { error ->
                                        isAuthLoading = false
                                        authErrorMessage = error
                                    }
                                )
                            } else {
                                viewModel.signInWithEmail(
                                    email = emailInput.trim(),
                                    password = passwordInput,
                                    onSuccess = {
                                        isAuthLoading = false
                                        showSignInSelection = false
                                    },
                                    onFailure = { error ->
                                        isAuthLoading = false
                                        authErrorMessage = "Invalid email or password"
                                    }
                                )
                            }
                        },
                        enabled = !isAuthLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp, top = 8.dp),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        if (isAuthLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        } else {
                            Text(if (isSignUpMode) "Register" else "Login")
                        }
                    }

                    // Toggle Mode Link
                    TextButton(
                        onClick = {
                            isSignUpMode = !isSignUpMode
                            resetErrors()
                        },
                        enabled = !isAuthLoading
                    ) {
                        Text(if (isSignUpMode) "Already have an account? Login" else "Don't have an account? Register")
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    TextButton(
                        onClick = { showSignInSelection = false },
                        enabled = !isAuthLoading
                    ) {
                        Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    // Detail dialog
    selectedComplaintForDetail?.let { complaint ->
        ComplaintDetailsDialog(
            complaint = complaint,
            viewModel = viewModel,
            onDismiss = { selectedComplaintForDetail = null }
        )
    }
}
