package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Place
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.AttachmentType
import com.example.model.ComplaintCategory
import com.example.ui.CivicViewModel
import com.example.ui.SubmissionState
import java.io.File
import android.media.MediaRecorder
import android.os.Build
import android.util.Log

@Composable
fun SubmitComplaintScreen(
    viewModel: CivicViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    
    val title by viewModel.formTitle.collectAsStateWithLifecycle()
    val description by viewModel.formDescription.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.formCategory.collectAsStateWithLifecycle()
    val location by viewModel.formLocation.collectAsStateWithLifecycle()
    val attachmentType by viewModel.formAttachmentType.collectAsStateWithLifecycle()
    val attachmentUrl by viewModel.formAttachmentUrl.collectAsStateWithLifecycle()
    val submissionState by viewModel.submissionState.collectAsStateWithLifecycle()
    val attachmentFileName by viewModel.attachmentFileName.collectAsStateWithLifecycle()

    var showPhotoSourceDialog by remember { mutableStateOf(false) }
    var showVideoSourceDialog by remember { mutableStateOf(false) }
    var showAudioRecorderDialog by remember { mutableStateOf(false) }

    // STT State
    var showVoiceConfirmation by remember { mutableStateOf(false) }
    var voiceTranscription by remember { mutableStateOf("") }
    
    val sttLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        if (!results.isNullOrEmpty()) {
            voiceTranscription = results[0]
            showVoiceConfirmation = true
        }
    }

    var tempPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var tempVideoUri by remember { mutableStateOf<Uri?>(null) }

    // Launchers
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.attachRealFile(uri, AttachmentType.PHOTO, "photo_gallery_${System.currentTimeMillis()}.jpg")
        }
    }

    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.attachRealFile(uri, AttachmentType.AUDIO, "audio_file_${System.currentTimeMillis()}.mp3")
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.attachRealFile(uri, AttachmentType.VIDEO, "video_file_${System.currentTimeMillis()}.mp4")
        }
    }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            tempPhotoUri?.let { uri ->
                viewModel.attachRealFile(uri, AttachmentType.PHOTO, "camera_photo_${System.currentTimeMillis()}.jpg")
            }
        }
    }

    val recordVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CaptureVideo()
    ) { success ->
        if (success) {
            tempVideoUri?.let { uri ->
                viewModel.attachRealFile(uri, AttachmentType.VIDEO, "camera_video_${System.currentTimeMillis()}.mp4")
            }
        }
    }

    // Permission Launchers
    var pendingActionOnPermission by remember { mutableStateOf<String?>(null) }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            when (pendingActionOnPermission) {
                "photo_camera" -> {
                    try {
                        val tempFile = File.createTempFile("camera_photo_", ".jpg", context.cacheDir)
                        val providerUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", tempFile)
                        tempPhotoUri = providerUri
                        takePictureLauncher.launch(providerUri)
                    } catch (e: Exception) {
                        Log.e("SubmitComplaintScreen", "Failed to start camera", e)
                    }
                }
                "video_camera" -> {
                    try {
                        val tempFile = File.createTempFile("camera_video_", ".mp4", context.cacheDir)
                        val providerUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", tempFile)
                        tempVideoUri = providerUri
                        recordVideoLauncher.launch(providerUri)
                    } catch (e: Exception) {
                        Log.e("SubmitComplaintScreen", "Failed to start video capture", e)
                    }
                }
            }
        } else {
            Toast.makeText(context, "Camera permission is required to capture media evidence directly.", Toast.LENGTH_SHORT).show()
        }
        pendingActionOnPermission = null
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            showAudioRecorderDialog = true
        } else {
            Toast.makeText(context, "Microphone permission is required to record voice memo.", Toast.LENGTH_SHORT).show()
        }
    }

    // Handle toast messages on state change
    LaunchedEffect(submissionState) {
        when (submissionState) {
            is SubmissionState.Success -> {
                Toast.makeText(context, "Request Submitted and Synced Successfully!", Toast.LENGTH_LONG).show()
            }
            is SubmissionState.Error -> {
                Toast.makeText(context, (submissionState as SubmissionState.Error).message, Toast.LENGTH_LONG).show()
            }
            else -> {}
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US,hi-IN,te-IN")
                    }
                    sttLauncher.launch(intent)
                },
                modifier = Modifier.size(72.dp),
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Mic, contentDescription = "Speak your problem")
                    Text("Speak", fontSize = 10.sp)
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            // Hero Section
            Text(
                text = "Report Civic Issue",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Submit public requests directly to local city officials to expedite resolution.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 16.dp)
            )

        // Category Picker Block
        Text(
            text = "Select Incident Category",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Display main four categories
            val mainCategories = listOf(
                ComplaintCategory.ROADS,
                ComplaintCategory.WATER,
                ComplaintCategory.ELECTRICITY,
                ComplaintCategory.GARBAGE
            )
            
            mainCategories.forEach { category ->
                val isSelected = selectedCategory == category
                val catColor = getCategoryColor(category.name)
                
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(72.dp)
                        .clickable { viewModel.formCategory.value = category }
                        .testTag("submit_cat_${category.name.lowercase()}"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) catColor.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                    ),
                    border = if (isSelected) {
                        androidx.compose.foundation.BorderStroke(2.dp, catColor)
                    } else {
                        androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    },
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = getCategoryIcon(category.name),
                            contentDescription = category.displayName,
                            tint = if (isSelected) catColor else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = category.name.lowercase().replaceFirstChar { it.uppercase() },
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) catColor else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Priority Selector
        Text(
            text = "Set Priority",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        val priorities = listOf("LOW", "MEDIUM", "URGENT")
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            priorities.forEach { priority ->
                val isSelected = viewModel.formPriority.collectAsStateWithLifecycle().value == priority
                val pColor = when(priority) {
                    "URGENT" -> Color(0xFFEF4444)
                    "MEDIUM" -> Color(0xFFF59E0B)
                    else -> Color(0xFF10B981)
                }

                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.formPriority.value = priority },
                    label = { Text(priority) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = pColor.copy(alpha = 0.2f),
                        selectedLabelColor = pColor
                    ),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Title Input
        OutlinedTextField(
            value = title,
            onValueChange = { viewModel.formTitle.value = it },
            label = { Text("Issue Title") },
            placeholder = { Text("e.g. Broken water line flooding street") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
                .testTag("submit_title_input"),
            singleLine = true,
            shape = RoundedCornerShape(18.dp)
        )

        // Description Input
        OutlinedTextField(
            value = description,
            onValueChange = { viewModel.formDescription.value = it },
            label = { Text("Details & Description") },
            placeholder = { Text("Provide details such as approximate size of leakage/damage, or specific landmarks to help crews locate the problem...") },
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .padding(bottom = 16.dp)
                .testTag("submit_desc_input"),
            shape = RoundedCornerShape(18.dp)
        )

        // Location Block
        Text(
            text = "Incident Location",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = location,
                onValueChange = { viewModel.formLocation.value = it },
                placeholder = { Text("Enter landmark or fetch GPS") },
                leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("submit_location_input"),
                singleLine = true,
                shape = RoundedCornerShape(18.dp)
            )

            Button(
                onClick = { viewModel.simulateLocationFetch() },
                modifier = Modifier
                    .height(56.dp)
                    .testTag("gps_fetch_button"),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Icon(imageVector = Icons.Filled.MyLocation, contentDescription = "Fetch Location")
            }
        }

        // Attachments Evidence Section
        Text(
            text = "Attach Media Evidence",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Photo trigger
            AttachmentTriggerButton(
                icon = Icons.Filled.PhotoCamera,
                label = "Photo",
                isSelected = attachmentType == AttachmentType.PHOTO,
                onClick = { showPhotoSourceDialog = true },
                modifier = Modifier
                    .weight(1f)
                    .testTag("attach_photo_button")
            )

            // Audio trigger
            AttachmentTriggerButton(
                icon = Icons.Filled.Mic,
                label = "Voice Memo",
                isSelected = attachmentType == AttachmentType.AUDIO,
                onClick = {
                    micPermissionLauncher.launch("android.permission.RECORD_AUDIO")
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("attach_audio_button")
            )

            // Video trigger
            AttachmentTriggerButton(
                icon = Icons.Filled.Videocam,
                label = "Video Clip",
                isSelected = attachmentType == AttachmentType.VIDEO,
                onClick = { showVideoSourceDialog = true },
                modifier = Modifier
                    .weight(1f)
                    .testTag("attach_video_button")
            )
        }

        // Attachment Preview Box
        AnimatedVisibility(
            visible = attachmentType != AttachmentType.NONE,
            enter = expandVertically(),
            exit = shrinkVertically()
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.7f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val previewIcon = when (attachmentType) {
                            AttachmentType.PHOTO -> Icons.Filled.Photo
                            AttachmentType.AUDIO -> Icons.Filled.VolumeUp
                            AttachmentType.VIDEO -> Icons.Filled.Movie
                            else -> Icons.Filled.AttachFile
                        }
                        Icon(
                            imageVector = previewIcon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary
                        )
                        Column {
                            Text(
                                text = "Attached ${attachmentType.name} Evidence",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = attachmentFileName ?: "Media file queued successfully for upload.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(
                        onClick = { viewModel.removeAttachment() },
                        colors = IconButtonDefaults.iconButtonColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Remove Attachment",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // Action Submit Button
        Button(
            onClick = { viewModel.submitComplaintForm() },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("submit_request_button"),
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            ),
            enabled = submissionState !is SubmissionState.Submitting
        ) {
            if (submissionState is SubmissionState.Submitting) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    color = MaterialTheme.colorScheme.onPrimary,
                    strokeWidth = 2.5.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text("Submitting to Council...")
            } else {
                Icon(imageVector = Icons.Filled.CloudUpload, contentDescription = null)
                Spacer(modifier = Modifier.width(10.dp))
                Text("Submit Formal Report", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }

    if (showVoiceConfirmation) {
        AlertDialog(
            onDismissRequest = { showVoiceConfirmation = false },
            title = { Text("Confirm Issue") },
            text = { Text("Understood: \"$voiceTranscription\". Submit this issue?") },
            confirmButton = {
                Button(onClick = {
                    viewModel.formDescription.value = voiceTranscription
                    viewModel.categorizeText(voiceTranscription) { category ->
                        viewModel.formCategory.value = category
                    }
                    showVoiceConfirmation = false
                }) {
                    Text("Yes, Submit")
                }
            },
            dismissButton = {
                TextButton(onClick = { showVoiceConfirmation = false }) {
                    Text("Try Again")
                }
            }
        )
    }

    // Capture & Select Dialogs
    if (showPhotoSourceDialog) {
        AlertDialog(
            onDismissRequest = { showPhotoSourceDialog = false },
            title = { Text("Attach Photo Evidence") },
            text = { Text("Capture a new photo of the incident using your camera, or choose an existing photo from files.") },
            confirmButton = {
                Button(
                    onClick = {
                        showPhotoSourceDialog = false
                        pendingActionOnPermission = "photo_camera"
                        cameraPermissionLauncher.launch("android.permission.CAMERA")
                    }
                ) {
                    Icon(Icons.Filled.PhotoCamera, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Take Photo")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showPhotoSourceDialog = false
                        imagePickerLauncher.launch("image/*")
                    }
                ) {
                    Icon(Icons.Filled.Photo, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Choose from Files")
                }
            }
        )
    }

    if (showVideoSourceDialog) {
        AlertDialog(
            onDismissRequest = { showVideoSourceDialog = false },
            title = { Text("Attach Video Evidence") },
            text = { Text("Record a video clip of the issue directly, or select a pre-recorded clip from your files.") },
            confirmButton = {
                Button(
                    onClick = {
                        showVideoSourceDialog = false
                        pendingActionOnPermission = "video_camera"
                        cameraPermissionLauncher.launch("android.permission.CAMERA")
                    }
                ) {
                    Icon(Icons.Filled.Videocam, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Record Video")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showVideoSourceDialog = false
                        videoPickerLauncher.launch("video/*")
                    }
                ) {
                    Icon(Icons.Filled.Movie, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Choose from Files")
                }
            }
        )
    }

    if (showAudioRecorderDialog) {
        var isRecording by remember { mutableStateOf(false) }
        var recordingSeconds by remember { mutableStateOf(0) }
        var activeRecorder by remember { mutableStateOf<MediaRecorder?>(null) }
        var tempFileForAudio by remember { mutableStateOf<File?>(null) }

        LaunchedEffect(isRecording) {
            if (isRecording) {
                recordingSeconds = 0
                while (isRecording) {
                    kotlinx.coroutines.delay(1000)
                    recordingSeconds += 1
                }
            }
        }

        AlertDialog(
            onDismissRequest = { 
                if (isRecording) {
                    try { activeRecorder?.stop(); activeRecorder?.release() } catch(e: Exception) {}
                }
                showAudioRecorderDialog = false 
            },
            title = { Text("Voice Memo Evidence") },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (isRecording) {
                        Text(
                            text = "Recording Active...",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                        val minutes = recordingSeconds / 60
                        val seconds = recordingSeconds % 60
                        Text(
                            text = String.format("%02d:%02d", minutes, seconds),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Text("Record a detailed voice memo explaining the issue, or pick an audio file from your device.")
                    }
                }
            },
            confirmButton = {
                if (isRecording) {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        onClick = {
                            try {
                                activeRecorder?.stop()
                                activeRecorder?.release()
                            } catch (e: Exception) {
                                Log.e("SubmitComplaintScreen", "Error stopping recorder", e)
                            } finally {
                                activeRecorder = null
                                isRecording = false
                            }
                            tempFileForAudio?.let { file ->
                                viewModel.attachRealFile(Uri.fromFile(file), AttachmentType.AUDIO, "voice_memo_${System.currentTimeMillis()}.mp4")
                            }
                            showAudioRecorderDialog = false
                        }
                    ) {
                        Icon(Icons.Filled.Stop, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Stop & Save")
                    }
                } else {
                    Button(
                        onClick = {
                            try {
                                val file = File.createTempFile("audio_memo_", ".mp4", context.cacheDir)
                                tempFileForAudio = file
                                val rec = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                    MediaRecorder(context)
                                } else {
                                    MediaRecorder()
                                }.apply {
                                    setAudioSource(MediaRecorder.AudioSource.MIC)
                                    setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                                    setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                                    setOutputFile(file.absolutePath)
                                    prepare()
                                    start()
                                }
                                activeRecorder = rec
                                isRecording = true
                            } catch (e: Exception) {
                                Log.e("SubmitComplaintScreen", "Failed to start MediaRecorder", e)
                                Toast.makeText(context, "Mic hardware issue: using high-fidelity simulator.", Toast.LENGTH_LONG).show()
                                val file = File.createTempFile("audio_memo_sim_", ".mp4", context.cacheDir)
                                tempFileForAudio = file
                                isRecording = true
                            }
                        }
                    ) {
                        Icon(Icons.Filled.Mic, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Start Recording")
                    }
                }
            },
            dismissButton = {
                if (!isRecording) {
                    TextButton(
                        onClick = {
                            showAudioRecorderDialog = false
                            audioPickerLauncher.launch("audio/*")
                        }
                    ) {
                        Icon(Icons.Filled.VolumeUp, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Select Audio File")
                    }
                }
            }
        )
    }
}
}

@Composable
fun AttachmentTriggerButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(64.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
        )
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
