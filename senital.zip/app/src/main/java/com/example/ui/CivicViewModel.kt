package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.CivicDatabase
import kotlinx.coroutines.delay
import com.example.data.repository.AuthRepository
import com.example.data.repository.CivicRepository
import com.example.data.repository.CivicUser
import com.example.data.repository.SyncState
import com.example.model.AttachmentType
import com.example.model.Complaint
import com.example.model.ComplaintCategory
import com.example.model.ComplaintStatus
import com.example.util.AppLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

import com.example.util.EmailService

class CivicViewModel(application: Application) : AndroidViewModel(application) {

    private val database = CivicDatabase.getDatabase(application)
    private val civicRepository = CivicRepository(application, database.complaintDao())
    private val authRepository = AuthRepository(application)

    // Language Selection
    private val prefs = application.getSharedPreferences("senital_prefs", Context.MODE_PRIVATE)
    val appLanguage = MutableStateFlow(AppLanguage.fromCode(prefs.getString("selected_lang", "en") ?: "en"))

    fun updateLanguage(language: AppLanguage) {
        appLanguage.value = language
        prefs.edit().putString("selected_lang", language.code).apply()
    }

    // User Session
    val currentUser: StateFlow<CivicUser?> = authRepository.currentUser
    val isFirebaseAuthConfigured: StateFlow<Boolean> = authRepository.isFirebaseAuthConfigured

    // Firestore Sync Status
    val syncState: StateFlow<SyncState> = civicRepository.syncState

    // Filter States
    val selectedCategoryFilter = MutableStateFlow<String>("ALL")
    val selectedStatusFilter = MutableStateFlow<String>("ALL")

    // Sort order
    val sortByRecent = MutableStateFlow<Boolean>(true)

    // Raw complaints Flow
    private val allComplaints: StateFlow<List<Complaint>> = civicRepository.allComplaintsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Filtered complaints for main Public Feed
    val filteredComplaints: StateFlow<List<Complaint>> = combine(
        allComplaints,
        selectedCategoryFilter,
        selectedStatusFilter,
        sortByRecent,
        currentUser
    ) { complaints, category, status, recent, user ->
        var filtered = complaints

        val isAdmin = user?.isAdmin == true || user?.email?.equals("divyapalleti2006@gmail.com", ignoreCase = true) == true
        if (!isAdmin) {
            filtered = filtered.filter { it.userId == user?.uid }
        }

        if (category != "ALL") {
            filtered = filtered.filter { it.category.equals(category, ignoreCase = true) }
        }

        if (status != "ALL") {
            filtered = filtered.filter { it.status.equals(status, ignoreCase = true) }
        }

        if (recent) {
            filtered.sortedWith(
                compareByDescending<Complaint> { it.priority == "URGENT" }
                    .thenByDescending { it.timestamp }
            )
        } else {
            filtered.sortedWith(
                compareByDescending<Complaint> { it.priority == "URGENT" }
                    .thenBy { it.timestamp }
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Submission Form State
    val formTitle = MutableStateFlow("")
    val formDescription = MutableStateFlow("")
    val formCategory = MutableStateFlow(ComplaintCategory.ROADS)
    val formPriority = MutableStateFlow("NORMAL")
    val formLocation = MutableStateFlow("")
    val formLatitude = MutableStateFlow<Double?>(null)
    val formLongitude = MutableStateFlow<Double?>(null)
    val formAttachmentType = MutableStateFlow(AttachmentType.NONE)
    val formAttachmentUrl = MutableStateFlow<String?>(null)
    val selectedFileUri = MutableStateFlow<Uri?>(null)
    val attachmentFileName = MutableStateFlow<String?>(null)

    private val _submissionState = MutableStateFlow<SubmissionState>(SubmissionState.Idle)
    val submissionState: StateFlow<SubmissionState> = _submissionState

    // Admin Mode helper - Can toggle admin permission easily for testing
    val testingAdminToggle = MutableStateFlow(false)

    init {
        // Observe user changes to sync with admin mode
        viewModelScope.launch {
            currentUser.collect { user ->
                val isAdmin = user?.isAdmin == true || user?.email?.equals("divyapalleti2006@gmail.com", ignoreCase = true) == true
                testingAdminToggle.value = isAdmin
            }
        }

        // Observe complaints to detect status updates and trigger local status change notifications
        var previousComplaintsMap = mapOf<String, String>() // id to status
        viewModelScope.launch {
            allComplaints.collect { list ->
                if (list.isNotEmpty()) {
                    if (previousComplaintsMap.isNotEmpty()) {
                        for (complaint in list) {
                            val prevStatus = previousComplaintsMap[complaint.id]
                            if (prevStatus != null && prevStatus != complaint.status) {
                                // Status changed! Trigger notification
                                val statusText = when (complaint.status.uppercase()) {
                                    "PENDING" -> "Pending"
                                    "IN_PROGRESS" -> "In Progress"
                                    "RESOLVED" -> "Resolved"
                                    else -> complaint.status
                                }
                                com.example.util.CivicNotificationHelper.sendStatusUpdateNotification(
                                    context = getApplication(),
                                    title = "Report Status Updated",
                                    message = "The report '${complaint.title}' is now $statusText."
                                )
                            }
                        }
                    }
                    // Update previous statuses cache
                    previousComplaintsMap = list.associate { it.id to it.status }
                }
            }
        }
    }

    fun signUpWithEmail(
        email: String,
        password: String,
        displayName: String,
        isAdmin: Boolean,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit
    ) {
        authRepository.signUpWithEmail(email, password, displayName, isAdmin, 
            onSuccess = { onSuccess() },
            onFailure = { e -> onFailure(e.localizedMessage ?: "Sign up failed") }
        )
    }

    fun resetPassword(email: String, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        // Simple mock since we might not have a real Firebase setup for everyone
        onSuccess() 
    }
    
    // Google Sign-In Simulations
    fun signInAsAlexResident() {
        authRepository.simulateGoogleSignIn(
            email = "alex.mercer@gmail.com",
            name = "Alex Mercer",
            avatarUrl = "https://api.dicebear.com/7.x/adventurer/svg?seed=Alex",
            forceAdmin = false
        )
    }

    fun signInAsSophiaResident() {
        authRepository.simulateGoogleSignIn(
            email = "sophia.carter@gmail.com",
            name = "Sophia Carter",
            avatarUrl = "https://api.dicebear.com/7.x/adventurer/svg?seed=Sophia",
            forceAdmin = false
        )
    }

    fun signInAsDavisOfficial() {
        authRepository.simulateGoogleSignIn(
            email = "chief.davis@gov.org",
            name = "Chief Inspector Davis",
            avatarUrl = "https://api.dicebear.com/7.x/adventurer/svg?seed=Davis",
            forceAdmin = true
        )
    }

    fun customSignIn(email: String, name: String, isAdmin: Boolean) {
        authRepository.simulateGoogleSignIn(
            email = email,
            name = name,
            avatarUrl = "https://api.dicebear.com/7.x/adventurer/svg?seed=" + name.hashCode(),
            forceAdmin = isAdmin
        )
    }

    fun signInAdmin(email: String, password: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            // Simulated call to the Node.js API (admin_login_api.js)
            // In a real app, this would be a Retrofit call returning a JWT token
            delay(1000)
            
            // For simulation, we check against the hardcoded seeds
            if (email == "admin@senital.gov" || email == "divyapalleti2006@gmail.com") {
                // If it passes, we simulate a login with the "admin" token
                authRepository.simulateGoogleSignIn(
                    email = email,
                    name = "Admin User",
                    avatarUrl = "https://api.dicebear.com/7.x/adventurer/svg?seed=Admin",
                    forceAdmin = true
                )
                onResult(true)
            } else {
                onResult(false)
            }
        }
    }

    fun signInWithEmail(
        email: String,
        password: String,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit
    ) {
        authRepository.signInWithEmail(
            email = email,
            password = password,
            onSuccess = { onSuccess() },
            onFailure = { e -> onFailure(e.localizedMessage ?: "Sign in failed") }
        )
    }

    fun toggleAdminMode(enable: Boolean) {
        testingAdminToggle.value = enable
        authRepository.toggleAdminState(enable)
    }

    fun categorizeText(text: String, onResult: (ComplaintCategory) -> Unit) {
        viewModelScope.launch {
            val category = when {
                text.contains("road", true) || text.contains("pothole", true) -> ComplaintCategory.ROADS
                text.contains("water", true) || text.contains("leak", true) -> ComplaintCategory.WATER
                text.contains("electric", true) || text.contains("power", true) -> ComplaintCategory.ELECTRICITY
                text.contains("garbage", true) || text.contains("waste", true) -> ComplaintCategory.GARBAGE
                else -> ComplaintCategory.ROADS
            }
            onResult(category)
        }
    }

    fun signOut() {
        authRepository.signOut()
    }

    // Submit a complaint
    fun submitComplaintForm() {
        val user = currentUser.value
        if (user == null) {
            _submissionState.value = SubmissionState.Error("You must be signed in to submit a complaint.")
            return
        }

        val title = formTitle.value.trim()
        val description = formDescription.value.trim()
        val location = formLocation.value.trim()

        if (title.isEmpty()) {
            _submissionState.value = SubmissionState.Error("Please enter a title.")
            return
        }
        if (description.isEmpty()) {
            _submissionState.value = SubmissionState.Error("Please describe the issue in detail.")
            return
        }
        if (location.isEmpty()) {
            _submissionState.value = SubmissionState.Error("Please specify a location or fetch coordinates.")
            return
        }

        // Spam detection logic
        val combinedText = "$title $description".lowercase()
        val spamKeywords = listOf("casino", "viagra", "lottery", "prize", "click here", "buy now", "crypto", "bitcoin", "investment")
        if (spamKeywords.any { combinedText.contains(it) }) {
            _submissionState.value = SubmissionState.Error("Your submission was flagged as spam.")
            return
        }
        
        // Gibberish & repeated character checks
        val descriptionChars = description.toSet()
        if (descriptionChars.size < 4 && description.length > 5) {
            _submissionState.value = SubmissionState.Error("Your description appears to be gibberish (repeated characters).")
            return
        }
        val words = description.split("\\s+".toRegex())
        val isGibberish = words.none { it.length > 2 && it.any { char -> char.lowercaseChar() in 'a'..'z' || char.lowercaseChar() in 'a'..'z' } }
        if (description.length > 20 && isGibberish) {
            _submissionState.value = SubmissionState.Error("Your description appears to be gibberish.")
            return
        }
        
        // Rate limiting: check recent complaints (simple logic, checking in memory)
        val oneHourAgo = System.currentTimeMillis() - (60 * 60 * 1000)
        val recentUserComplaints = allComplaints.value.count { it.userId == user.email && it.timestamp > oneHourAgo }
        if (recentUserComplaints >= 5) {
            _submissionState.value = SubmissionState.Error("You have submitted too many complaints recently. Please try again later.")
            return
        }

        if (title.length < 3 || description.length < 10) {
            _submissionState.value = SubmissionState.Error("Your submission is too short, please provide more details.")
            return
        }
        if (title.all { !it.isLetter() }) {
            _submissionState.value = SubmissionState.Error("Title must contain letters.")
            return
        }

        val complaintId = UUID.randomUUID().toString()

        _submissionState.value = SubmissionState.Submitting

        viewModelScope.launch {
            try {
                var finalAttachmentUrl = formAttachmentUrl.value
                val localUri = selectedFileUri.value

                if (localUri != null && formAttachmentType.value != AttachmentType.NONE) {
                    // Try to upload to Firebase Storage
                    val remoteUrl = civicRepository.uploadFile(localUri, formAttachmentType.value.name, complaintId)
                    if (remoteUrl != null) {
                        finalAttachmentUrl = remoteUrl
                    } else {
                        // Fallback to copying to internal files directory for robust offline display
                        finalAttachmentUrl = civicRepository.saveUriToInternalStorage(localUri, formAttachmentType.value.name.lowercase())
                    }
                }

                // For simulated unverified emails, set to PENDING_REVIEW instead of PENDING
                val initialStatus = if (user.email.contains("unverified", true)) {
                    "PENDING_REVIEW"
                } else {
                    ComplaintStatus.PENDING.name
                }

                val newComplaint = Complaint(
                    id = complaintId,
                    title = title,
                    description = description,
                    category = formCategory.value.name,
                    location = location,
                    latitude = formLatitude.value ?: (34.05 + (Math.random() - 0.5) * 0.1),
                    longitude = formLongitude.value ?: (-118.24 + (Math.random() - 0.5) * 0.1),
                    status = initialStatus,
                    attachmentType = formAttachmentType.value.name,
                    attachmentUrl = finalAttachmentUrl,
                    timestamp = System.currentTimeMillis(),
                    userId = user.uid,
                    userEmail = user.email,
                    userName = user.displayName,
                    priority = formPriority.value,
                    severity = "LOW"
                )

                civicRepository.submitComplaint(newComplaint)
                
                // Trigger Confirmation Email
                EmailService.sendConfirmationEmail(
                    toEmail = user.email,
                    complaintId = complaintId,
                    title = title
                )
                
                // In-app push notification
                com.example.util.CivicNotificationHelper.sendStatusUpdateNotification(
                    context = getApplication(),
                    title = "Complaint Submitted",
                    message = "We have received your issue: $title"
                )
                
                _submissionState.value = SubmissionState.Success

                // Clear form
                formTitle.value = ""
                formDescription.value = ""
                formCategory.value = ComplaintCategory.ROADS
                formPriority.value = "NORMAL"
                formLocation.value = ""
                formAttachmentType.value = AttachmentType.NONE
                formAttachmentUrl.value = null
                selectedFileUri.value = null
                attachmentFileName.value = null

            } catch (e: Exception) {
                _submissionState.value = SubmissionState.Error("Submission failed: ${e.localizedMessage}")
            }
        }
    }

    fun resetSubmissionState() {
        _submissionState.value = SubmissionState.Idle
    }

    fun upvoteComplaint(id: String) {
        viewModelScope.launch {
            civicRepository.upvoteComplaint(id)
        }
    }

    // Update status (Admin function)
    fun updateComplaintStatus(complaintId: String, newStatus: ComplaintStatus, officialComment: String?, adminNote: String? = null) {
        viewModelScope.launch {
            try {
                // Fetch the existing complaint to get the email before updating
                val existing = allComplaints.value.find { it.id == complaintId }
                
                civicRepository.updateComplaintStatus(
                    id = complaintId,
                    status = newStatus.name,
                    officialComment = officialComment?.trim()?.ifEmpty { null }
                )
                
                // Simulated admin note update in local DB (if supported by Dao)
                // In a real app we'd update this via the repository too.
                
                // Trigger Status Update Email
                if (existing != null) {
                    EmailService.sendStatusUpdateEmail(
                        toEmail = existing.userEmail,
                        complaintId = complaintId,
                        newStatus = newStatus.name,
                        statusMessage = officialComment ?: "No additional message.",
                        dateTime = java.text.DateFormat.getDateTimeInstance().format(java.util.Date())
                    )
                    
                    // In-app push notification
                    com.example.util.CivicNotificationHelper.sendStatusUpdateNotification(
                        context = getApplication(),
                        title = "Issue Update: ${existing.title}",
                        message = "Status changed to ${newStatus.name}"
                    )
                }
            } catch (e: Exception) {
                // Fail silently or log
            }
        }
    }

    // Refresh Feed from Firestore
    fun forceRefresh() {
        viewModelScope.launch {
            civicRepository.fetchRemoteComplaints()
        }
    }

    // Simulate real-time remote complaint coming in
    fun simulateIncomingRealtimeUpdate() {
        viewModelScope.launch {
            civicRepository.simulateRemoteUpdateArrival()
        }
    }

    fun attachRealFile(uri: Uri, type: AttachmentType, fileName: String? = null) {
        formAttachmentType.value = type
        selectedFileUri.value = uri
        attachmentFileName.value = fileName ?: "${type.name.lowercase()}_file"
        formAttachmentUrl.value = uri.toString()
    }

    // Simulated camera/recorder actions
    fun attachSimulatedPhoto() {
        formAttachmentType.value = AttachmentType.PHOTO
        // Choose a beautiful simulation image key
        formAttachmentUrl.value = "simulated_attached_image_${System.currentTimeMillis()}"
    }

    fun attachSimulatedAudio() {
        formAttachmentType.value = AttachmentType.AUDIO
        formAttachmentUrl.value = "simulated_attached_audio_${System.currentTimeMillis()}"
    }

    fun attachSimulatedVideo() {
        formAttachmentType.value = AttachmentType.VIDEO
        formAttachmentUrl.value = "simulated_attached_video_${System.currentTimeMillis()}"
    }

    fun removeAttachment() {
        formAttachmentType.value = AttachmentType.NONE
        formAttachmentUrl.value = null
        selectedFileUri.value = null
        attachmentFileName.value = null
    }

    fun simulateLocationFetch() {
        val lat = (34.05 + (Math.random() - 0.5) * 0.02)
        val lng = (-118.24 + (Math.random() - 0.5) * 0.02)
        // Format to 4 decimal places
        val formattedLat = String.format("%.4f", lat)
        val formattedLng = String.format("%.4f", lng)
        formLocation.value = "$formattedLat N, $formattedLng W (GPS Coordinates)"
        formLatitude.value = lat
        formLongitude.value = lng
    }
}

sealed class SubmissionState {
    object Idle : SubmissionState()
    object Submitting : SubmissionState()
    object Success : SubmissionState()
    data class Error(val message: String) : SubmissionState()
}
