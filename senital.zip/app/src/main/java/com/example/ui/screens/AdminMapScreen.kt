package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.Complaint
import com.example.model.ComplaintCategory
import com.example.ui.CivicViewModel
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.*
import com.google.maps.android.compose.clustering.Clustering

@Composable
fun AdminMapScreen(
    viewModel: CivicViewModel,
    modifier: Modifier = Modifier
) {
    val complaints by viewModel.filteredComplaints.collectAsStateWithLifecycle()
    var selectedCategory by remember { mutableStateOf("All") }
    var selectedStatus by remember { mutableStateOf("All") }
    var selectedComplaint by remember { mutableStateOf<Complaint?>(null) }
    
    val filteredComplaints = complaints.filter {
        (selectedCategory == "All" || it.category == selectedCategory) &&
        (selectedStatus == "All" || it.status.uppercase() == selectedStatus)
    }

    // Centered around an arbitrary location or average location
    val centerLat = filteredComplaints.mapNotNull { it.latitude }.average().takeIf { !it.isNaN() } ?: 34.05
    val centerLng = filteredComplaints.mapNotNull { it.longitude }.average().takeIf { !it.isNaN() } ?: -118.24
    
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(LatLng(centerLat, centerLng), 10f)
    }

    // Google Maps requires API Key. If missing, this might just show blank map or crash, 
    // but code complies with prompt.
    Box(modifier = modifier.fillMaxSize()) {
        val validItems = filteredComplaints.filter { 
            it.latitude != null && it.longitude != null && 
            it.latitude!! in -90.0..90.0 && it.longitude!! in -180.0..180.0 
        }

        if (validItems.isEmpty() && filteredComplaints.isNotEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Location not available for these complaints", color = MaterialTheme.colorScheme.error)
            }
        } else {
            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = cameraPositionState,
                properties = MapProperties(isMyLocationEnabled = false)
            ) {
                val items = validItems.map { MapClusterItem(it) }
                
                Clustering(
                    items = items,
                    onClusterItemClick = { item ->
                        selectedComplaint = item.complaint
                        false
                    },
                    clusterItemContent = { item ->
                        val color = when(item.complaint.category) {
                            ComplaintCategory.WATER.name -> 210f // Blue
                            ComplaintCategory.ELECTRICITY.name -> 60f // Yellow
                            ComplaintCategory.GARBAGE.name -> 30f // Orange/Brownish
                            else -> BitmapDescriptorFactory.HUE_RED // Red
                        }
                        val statusColor = when(item.complaint.status.uppercase()) {
                            "RESOLVED" -> Color.Green
                            "PENDING" -> Color.Red
                            else -> Color.Yellow
                        }
                        
                        Box(modifier = Modifier.size(40.dp), contentAlignment = Alignment.Center) {
                            // A custom visual for pin with badge
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color.hsv(color, 1f, 1f))
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(statusColor)
                            )
                        }
                    }
                )
            }
        }

        // Filters UI
        Column(modifier = Modifier.align(Alignment.TopCenter).padding(16.dp)) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(5) { index ->
                    val cat = listOf("All", ComplaintCategory.WATER.name, ComplaintCategory.ELECTRICITY.name, ComplaintCategory.GARBAGE.name, ComplaintCategory.ROADS.name)[index]
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat.take(12), fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(containerColor = MaterialTheme.colorScheme.surface)
                    )
                }
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                items(4) { index ->
                    val stat = listOf("All", "PENDING", "IN_PROGRESS", "RESOLVED")[index]
                    FilterChip(
                        selected = selectedStatus == stat,
                        onClick = { selectedStatus = stat },
                        label = { Text(stat, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(containerColor = MaterialTheme.colorScheme.surface)
                    )
                }
            }
        }
        
        // Selected Complaint Popup
        if (selectedComplaint != null) {
            Card(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(24.dp)
                    .fillMaxWidth()
                    .clickable {
                        // Could open full detail modal here
                    },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(selectedComplaint!!.title, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
                        Text(selectedComplaint!!.status, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    Text(selectedComplaint!!.userId, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(selectedComplaint!!.description, fontSize = 14.sp, maxLines = 2)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { selectedComplaint = null },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Close / View Details")
                    }
                }
            }
        }
    }
}

class MapClusterItem(val complaint: Complaint) : com.google.maps.android.clustering.ClusterItem {
    override fun getPosition(): LatLng {
        val lat = complaint.latitude ?: 0.0
        val lng = complaint.longitude ?: 0.0
        return if (lat in -90.0..90.0 && lng in -180.0..180.0) LatLng(lat, lng) else LatLng(0.0, 0.0)
    }
    override fun getTitle(): String = complaint.title
    override fun getSnippet(): String = complaint.description
    override fun getZIndex(): Float? = null
}
