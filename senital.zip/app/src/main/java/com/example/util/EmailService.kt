package com.example.util

import android.util.Log

object EmailService {
    fun sendStatusUpdateEmail(
        toEmail: String,
        complaintId: String,
        newStatus: String,
        statusMessage: String,
        dateTime: String
    ) {
        val emailBody = """
            Subject: Update on your Civic Complaint #$complaintId
            
            Hello,
            
            The status of your complaint has been updated to: $newStatus
            
            Message from administration:
            $statusMessage
            
            Date: $dateTime
            
            To view more details, open the CivicConnect App or visit: app://civic/complaint/$complaintId
            
            Thank you for helping improve our community!
            - CivicConnect Team
        """.trimIndent()
        
        Log.d("EmailService_Tx", "Sending email to: $toEmail\n$emailBody")
        // In a real app, integrate with SendGrid, AWS SES, or Firebase Trigger Email extension here.
    }

    fun sendConfirmationEmail(
        toEmail: String,
        complaintId: String,
        title: String
    ) {
        val emailBody = """
            Subject: Confirmation: Civic Complaint #$complaintId Received
            
            Hello,
            
            This is to confirm that we have successfully received your complaint: "$title".
            Your complaint ID/ticket number is: $complaintId.
            
            We will review it and keep you updated on its status.
            
            - CivicConnect Team
        """.trimIndent()
        
        Log.d("EmailService_Tx", "Sending confirmation email to: $toEmail\n$emailBody")
    }
}
