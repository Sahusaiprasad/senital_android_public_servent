package com.example.util

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

enum class AppLanguage(val code: String, val displayName: String, val flag: String) {
    ENGLISH("en", "English", "🇺🇸"),
    TELUGU("te", "Telugu (తెలుగు)", "🇮🇳"),
    HINDI("hi", "Hindi (हिन्दी)", "🇮🇳"),
    TAMIL("ta", "Tamil (தமிழ்)", "🇮🇳");

    companion object {
        fun fromCode(code: String): AppLanguage {
            return entries.find { it.code == code } ?: ENGLISH
        }
    }
}

object Localization {
    private val translations = mapOf(
        "Municipal Services Platform" to mapOf(
            AppLanguage.ENGLISH to "Municipal Services Platform",
            AppLanguage.TELUGU to "మునిసిపల్ సేవల ప్లాట్‌ఫారమ్",
            AppLanguage.HINDI to "नगर पालिका सेवा मंच",
            AppLanguage.TAMIL to "நகராட்சி சேவைகள் தளம்"
        ),
        "Synced" to mapOf(
            AppLanguage.ENGLISH to "Synced",
            AppLanguage.TELUGU to "సింక్ చేయబడింది",
            AppLanguage.HINDI to "सिंक किया गया",
            AppLanguage.TAMIL to "ஒத்திசைக்கப்பட்டது"
        ),
        "Syncing" to mapOf(
            AppLanguage.ENGLISH to "Syncing",
            AppLanguage.TELUGU to "సమకాలీకరిస్తోంది",
            AppLanguage.HINDI to "सिंक हो रहा है",
            AppLanguage.TAMIL to "ஒத்திசைக்கப்படுகிறது"
        ),
        "Offline" to mapOf(
            AppLanguage.ENGLISH to "Offline",
            AppLanguage.TELUGU to "ఆఫ్‌లైన్",
            AppLanguage.HINDI to "ऑफ़लाइन",
            AppLanguage.TAMIL to "ஆஃப்லைன்"
        ),
        "Public Feed" to mapOf(
            AppLanguage.ENGLISH to "Public Feed",
            AppLanguage.TELUGU to "ఫీడ్",
            AppLanguage.HINDI to "फ़ीड",
            AppLanguage.TAMIL to "செய்தி ஓடை"
        ),
        "Report Issue" to mapOf(
            AppLanguage.ENGLISH to "Report Issue",
            AppLanguage.TELUGU to "సమర్పించు",
            AppLanguage.HINDI to "जमा करें",
            AppLanguage.TAMIL to "சமர்ப்பி"
        ),
        "Admin Hub" to mapOf(
            AppLanguage.ENGLISH to "Admin Hub",
            AppLanguage.TELUGU to "అడ్మిన్",
            AppLanguage.HINDI to "प्रशासक",
            AppLanguage.TAMIL to "நிர்வாகி"
        ),
        "My Profile" to mapOf(
            AppLanguage.ENGLISH to "My Profile",
            AppLanguage.TELUGU to "ప్రొఫైల్",
            AppLanguage.HINDI to "प्रोफ़ाइल",
            AppLanguage.TAMIL to "சுயவிவரம்"
        ),
        "Senital" to mapOf(
            AppLanguage.ENGLISH to "Senital",
            AppLanguage.TELUGU to "సెనిటల్",
            AppLanguage.HINDI to "सेनिटल",
            AppLanguage.TAMIL to "செனிட்டல்"
        ),
        "Public request resolution tracking" to mapOf(
            AppLanguage.ENGLISH to "Public request resolution tracking",
            AppLanguage.TELUGU to "పౌర అభ్యర్థన పరిష్కార ట్రాకింగ్",
            AppLanguage.HINDI to "सार्वजनिक अनुरोध समाधान ट्रैकिंग",
            AppLanguage.TAMIL to "பொது கோரிக்கை தீர்வு கண்காணிப்பு"
        ),
        "Senital runs offline-first with a local high-performance Room database, and automatically syncs to Google Cloud Firestore in real time once connected." to mapOf(
            AppLanguage.ENGLISH to "Senital runs offline-first with a local high-performance Room database, and automatically syncs to Google Cloud Firestore in real time once connected.",
            AppLanguage.TELUGU to "సెనిటల్ లోకల్ రూమ్ డేటాబేస్ ద్వారా ఆఫ్ లైన్ లో రన్ అవుతుంది, కనెక్ట్ అవ్వగానే ఫైర్ స్టోర్ తో సింక్ అవుతుంది.",
            AppLanguage.HINDI to "सेनिटल एक स्थानीय उच्च-प्रदर्शन रूम डेटाबेस के साथ ऑफ़लाइन-प्रथम चलता है, और कनेक्ट होने पर रीयल टाइम में Google क्लाउड फ़ायरस्टोर में सिंक हो जाता है।",
            AppLanguage.TAMIL to "செனிட்டல் உள்ளூர் ரூம் தரவுத்தளத்துடன் ஆஃப்லைனில் இயங்குகிறது, மேலும் இணைக்கப்பட்டதும் நிகழ்நேரத்தில் கூகிள் கிளவுட் ஃபயர்ஸ்டோருடன் ஒத்திசைகிறது."
        ),
        "Syncing..." to mapOf(
            AppLanguage.ENGLISH to "Syncing...",
            AppLanguage.TELUGU to "సమకాలీకరిస్తోంది...",
            AppLanguage.HINDI to "सिंक हो रहा है...",
            AppLanguage.TAMIL to "ஒத்திசைக்கப்படுகிறது..."
        ),
        "Synced to Cloud" to mapOf(
            AppLanguage.ENGLISH to "Synced to Cloud",
            AppLanguage.TELUGU to "క్లౌడ్‌కి సింక్ చేయబడింది",
            AppLanguage.HINDI to "क्लाउड से सिंक किया गया",
            AppLanguage.TAMIL to "கிளவுடுடன் ஒத்திசைக்கப்பட்டது"
        ),
        "Offline Mode" to mapOf(
            AppLanguage.ENGLISH to "Offline Mode",
            AppLanguage.TELUGU to "ఆఫ్‌లైన్ మోడ్",
            AppLanguage.HINDI to "ऑफ़लाइन मोड",
            AppLanguage.TAMIL to "ஆஃப்லைன் பயன்முறை"
        ),
        "Authentication Required" to mapOf(
            AppLanguage.ENGLISH to "Authentication Required",
            AppLanguage.TELUGU to "ధృవీకరణ అవసరం",
            AppLanguage.HINDI to "प्रमाणीकरण आवश्यक",
            AppLanguage.TAMIL to "அங்கீகாரம் தேவை"
        ),
        "To submit, manage, or track public service complaints and reports, please sign up or sign in below." to mapOf(
            AppLanguage.ENGLISH to "To submit, manage, or track public service complaints and reports, please sign up or sign in below.",
            AppLanguage.TELUGU to "పౌర సేవల ఫిర్యాదులు సమర్పించడానికి, నిర్వహించడానికి లేదా ట్రాక్ చేయడానికి, దయచేసి క్రింద సైన్ అప్ లేదా సైన్ ఇన్ చేయండి.",
            AppLanguage.HINDI to "सार्वजनिक सेवा शिकायतों और रिपोर्टों को प्रस्तुत करने, प्रबंधित करने या ट्रैक करने के लिए, कृपया नीचे साइन अप या साइन इन करें।",
            AppLanguage.TAMIL to "பொது சேவை புகார்களை சமர்ப்பிக்க, நிர்வகிக்க அல்லது கண்காணிக்க, தயவுசெய்து கீழே பதிவு செய்யவும் அல்லது உள்நுழையவும்."
        ),
        "Create Civic Account" to mapOf(
            AppLanguage.ENGLISH to "Create Civic Account",
            AppLanguage.TELUGU to "పౌర ఖాతాను సృష్టించండి",
            AppLanguage.HINDI to "नागरिक खाता बनाएं",
            AppLanguage.TAMIL to "குடிமகன் கணக்கை உருவாக்கு"
        ),
        "Sign In to Senital" to mapOf(
            AppLanguage.ENGLISH to "Sign In to Senital",
            AppLanguage.TELUGU to "సెనిటల్‌కు సైన్ ఇన్ చేయండి",
            AppLanguage.HINDI to "सेनिटल में साइन इन करें",
            AppLanguage.TAMIL to "செனிட்டலில் உள்நுழையவும்"
        ),
        "Sign In" to mapOf(
            AppLanguage.ENGLISH to "Sign In",
            AppLanguage.TELUGU to "సైన్ ఇన్",
            AppLanguage.HINDI to "साइन इन करें",
            AppLanguage.TAMIL to "உள்நுழை"
        ),
        "Sign Up" to mapOf(
            AppLanguage.ENGLISH to "Sign Up",
            AppLanguage.TELUGU to "సైన్ అప్",
            AppLanguage.HINDI to "साइन अप करें",
            AppLanguage.TAMIL to "பதிவு செய்"
        ),
        "Full Name" to mapOf(
            AppLanguage.ENGLISH to "Full Name",
            AppLanguage.TELUGU to "పూర్తి పేరు",
            AppLanguage.HINDI to "पूरा नाम",
            AppLanguage.TAMIL to "முழு பெயர்"
        ),
        "Email Address" to mapOf(
            AppLanguage.ENGLISH to "Email Address",
            AppLanguage.TELUGU to "ఇమెయిల్ చిరునామా",
            AppLanguage.HINDI to "ईमेल पता",
            AppLanguage.TAMIL to "மின்னஞ்சல் முகவரி"
        ),
        "Password" to mapOf(
            AppLanguage.ENGLISH to "Password",
            AppLanguage.TELUGU to "పాస్‌వర్డ్",
            AppLanguage.HINDI to "पासवर्ड",
            AppLanguage.TAMIL to "கடவுச்சொல்"
        ),
        "At least 6 characters" to mapOf(
            AppLanguage.ENGLISH to "At least 6 characters",
            AppLanguage.TELUGU to "కనీసం 6 అక్షరాలు",
            AppLanguage.HINDI to "कम से कम 6 अक्षर",
            AppLanguage.TAMIL to "குறைந்தது 6 எழுத்துக்கள்"
        ),
        "Choose Your Role:" to mapOf(
            AppLanguage.ENGLISH to "Choose Your Role:",
            AppLanguage.TELUGU to "మీ పాత్రను ఎంచుకోండి:",
            AppLanguage.HINDI to "अपनी भूमिका चुनें:",
            AppLanguage.TAMIL to "உங்கள் பாத்திரத்தை தேர்வு செய்யவும்:"
        ),
        "Citizen" to mapOf(
            AppLanguage.ENGLISH to "Citizen",
            AppLanguage.TELUGU to "పౌరుడు",
            AppLanguage.HINDI to "नागरिक",
            AppLanguage.TAMIL to "குடிமகன்"
        ),
        "Official" to mapOf(
            AppLanguage.ENGLISH to "Official",
            AppLanguage.TELUGU to "అధికారి",
            AppLanguage.HINDI to "अधिकारी",
            AppLanguage.TAMIL to "அதிகாரி"
        ),
        "Register Account" to mapOf(
            AppLanguage.ENGLISH to "Register Account",
            AppLanguage.TELUGU to "ఖాతా నమోదు చేయండి",
            AppLanguage.HINDI to "खाता पंजीकृत करें",
            AppLanguage.TAMIL to "கணக்கை பதிவு செய்"
        ),
        "Secure Sign-In" to mapOf(
            AppLanguage.ENGLISH to "Secure Sign-In",
            AppLanguage.TELUGU to "సురక్షిత సైన్-ఇన్",
            AppLanguage.HINDI to "सुरक्षित साइन-इन",
            AppLanguage.TAMIL to "பாதுகாப்பான உள்நுழைவு"
        ),
        "Or quick-start with simulation presets:" to mapOf(
            AppLanguage.ENGLISH to "Or quick-start with simulation presets:",
            AppLanguage.TELUGU to "లేదా సిమ్యులేషన్ ప్రీసెట్లతో త్వరగా ప్రారంభించండి:",
            AppLanguage.HINDI to "या सिमुलेशन प्रीसेट के साथ त्वरित-प्रारंभ करें:",
            AppLanguage.TAMIL to "அல்லது உருவகப்படுத்துதல் முன்னமைவுகளுடன் விரைவாகத் தொடங்கவும்:"
        ),
        "Alex Mercer (Citizen Preset)" to mapOf(
            AppLanguage.ENGLISH to "Alex Mercer (Citizen Preset)",
            AppLanguage.TELUGU to "అలెక్స్ మెర్సర్ (పౌరుడి ప్రీసెట్)",
            AppLanguage.HINDI to "एलेक्स मर्सर (नागरिक प्रीसेट)",
            AppLanguage.TAMIL to "அலெக்ஸ் மெர்சர் (குடிமகன் முன்னமைவு)"
        ),
        "Chief Inspector Davis (Official Admin Preset)" to mapOf(
            AppLanguage.ENGLISH to "Chief Inspector Davis (Official Admin Preset)",
            AppLanguage.TELUGU to "చీఫ్ ఇన్‌స్పెక్టర్ డేవిస్ (అధికారిక ప్రీసెట్)",
            AppLanguage.HINDI to "मुख्य निरीक्षक डेविस (अधिकारी प्रीसेट)",
            AppLanguage.TAMIL to "தலைமை ஆய்வாளர் டேவிஸ் (அதிகாரி முன்னமைவு)"
        ),
        "All fields are required" to mapOf(
            AppLanguage.ENGLISH to "All fields are required",
            AppLanguage.TELUGU to "అన్ని ఫీల్డ్‌లు తప్పనిసరి",
            AppLanguage.HINDI to "सभी फ़ील्ड आवश्यक हैं",
            AppLanguage.TAMIL to "அனைத்து புலங்களும் தேவை"
        ),
        "Password must be at least 6 characters" to mapOf(
            AppLanguage.ENGLISH to "Password must be at least 6 characters",
            AppLanguage.TELUGU to "పాస్‌వర్డ్ కనీసం 6 అక్షరాలు ఉండాలి",
            AppLanguage.HINDI to "पासवर्ड कम से कम 6 अक्षर होना चाहिए",
            AppLanguage.TAMIL to "கடவுச்சொல் குறைந்தது 6 எழுத்துக்களாக இருக்க வேண்டும்"
        ),
        "Email and password are required" to mapOf(
            AppLanguage.ENGLISH to "Email and password are required",
            AppLanguage.TELUGU to "ఇమెయిల్ మరియు పాస్‌వర్డ్ అవసరం",
            AppLanguage.HINDI to "ईमेल और पासवर्ड आवश्यक हैं",
            AppLanguage.TAMIL to "மின்னஞ்சல் மற்றும் கடவுச்சொல் தேவை"
        ),
        "Community Issues Feed" to mapOf(
            AppLanguage.ENGLISH to "Community Issues Feed",
            AppLanguage.TELUGU to "సమాజ సమస్యల ఫీడ్",
            AppLanguage.HINDI to "सामुदायिक मुद्दे फ़ीड",
            AppLanguage.TAMIL to "சமூகப் பிரச்சினைகள் ஓடை"
        ),
        "Filter issues & track resolution progress in real-time" to mapOf(
            AppLanguage.ENGLISH to "Filter issues & track resolution progress in real-time",
            AppLanguage.TELUGU to "నిజ సమయంలో సమస్యలను ఫిల్టర్ చేయండి మరియు పరిష్కార పురోగతిని ట్రాక్ చేయండి",
            AppLanguage.HINDI to "वास्तविक समय में मुद्दों को फ़िल्टर करें और समाधान प्रगति को ट्रैक करें",
            AppLanguage.TAMIL to "நிகழ்நேரத்தில் சிக்கல்களை வடிகட்டி, தீர்வு முன்னேற்றத்தைக் கண்காணிக்கவும்"
        ),
        "Filters" to mapOf(
            AppLanguage.ENGLISH to "Filters",
            AppLanguage.TELUGU to "ఫిల్టర్లు",
            AppLanguage.HINDI to "फ़िल्टर",
            AppLanguage.TAMIL to "வடிகட்டிகள்"
        ),
        "Sort By" to mapOf(
            AppLanguage.ENGLISH to "Sort By",
            AppLanguage.TELUGU to "సమయం ప్రకారం",
            AppLanguage.HINDI to "क्रमबद्ध करें",
            AppLanguage.TAMIL to "வரிசைப்படுத்து"
        ),
        "Recent" to mapOf(
            AppLanguage.ENGLISH to "Recent",
            AppLanguage.TELUGU to "ఇటీవలివి",
            AppLanguage.HINDI to "हाल का",
            AppLanguage.TAMIL to "சமீபத்தியவை"
        ),
        "Oldest" to mapOf(
            AppLanguage.ENGLISH to "Oldest",
            AppLanguage.TELUGU to "పాతవి",
            AppLanguage.HINDI to "सबसे पुराना",
            AppLanguage.TAMIL to "பழையவை"
        ),
        "All" to mapOf(
            AppLanguage.ENGLISH to "All",
            AppLanguage.TELUGU to "అన్నీ",
            AppLanguage.HINDI to "सभी",
            AppLanguage.TAMIL to "அனைத்தும்"
        ),
        "No issues match the selected category or status filter settings." to mapOf(
            AppLanguage.ENGLISH to "No issues match the selected category or status filter settings.",
            AppLanguage.TELUGU to "ఎంచుకున్న ఫిల్టర్లకు సరిపోయే సమస్యలు ఏవీ లేవు.",
            AppLanguage.HINDI to "चयनित श्रेणी या स्थिति फ़िल्टर सेटिंग्स से कोई भी मुद्दा मेल नहीं खाता।",
            AppLanguage.TAMIL to "தேர்ந்தெடுக்கப்பட்ட வடிகட்டி அமைப்புகளுடன் எந்தவொரு சிக்கலும் பொருந்தவில்லை."
        ),
        "There are no reported civic issues in this area right now. If you spot one, submit a request!" to mapOf(
            AppLanguage.ENGLISH to "There are no reported civic issues in this area right now. If you spot one, submit a request!",
            AppLanguage.TELUGU to "ఈ ప్రాంతంలో ప్రస్తుతానికి ఎలాంటి సమస్యలు నివేదించబడలేదు. ఏదైనా సమస్య ఉంటే, సమర్పించండి!",
            AppLanguage.HINDI to "इस क्षेत्र में अभी कोई रिपोर्ट किया गया नागरिक मुद्दा नहीं है। यदि आप कोई देखते हैं, तो अनुरोध सबमिट करें!",
            AppLanguage.TAMIL to "இந்த பகுதியில் தற்போது எந்த சிவில் பிரச்சினைகளும் பதிவாகவில்லை. நீங்கள் ஒன்றைக் கண்டால், சமர்ப்பிக்கவும்!"
        ),
        "Official Comment" to mapOf(
            AppLanguage.ENGLISH to "Official Comment",
            AppLanguage.TELUGU to "అధికారిక వ్యాఖ్య",
            AppLanguage.HINDI to "आधिकारिक टिप्पणी",
            AppLanguage.TAMIL to "அதிகாரப்பூர்வ கருத்து"
        ),
        "No official comment yet" to mapOf(
            AppLanguage.ENGLISH to "No official comment yet",
            AppLanguage.TELUGU to "ఇంకా అధికారిక వ్యాఖ్య లేదు",
            AppLanguage.HINDI to "अभी तक कोई आधिकारिक टिप्पणी नहीं",
            AppLanguage.TAMIL to "இதுவரை அதிகாரப்பூர்வ கருத்து எதுவும் இல்லை"
        ),
        "By" to mapOf(
            AppLanguage.ENGLISH to "By",
            AppLanguage.TELUGU to "ద్వారా",
            AppLanguage.HINDI to "द्वारा",
            AppLanguage.TAMIL to "வழங்கியவர்"
        ),
        "at" to mapOf(
            AppLanguage.ENGLISH to "at",
            AppLanguage.TELUGU to "వద్ద",
            AppLanguage.HINDI to "पर",
            AppLanguage.TAMIL to "நேரத்தில்"
        ),
        "Resolve Issue" to mapOf(
            AppLanguage.ENGLISH to "Resolve Issue",
            AppLanguage.TELUGU to "సమస్యను పరిష్కరించు",
            AppLanguage.HINDI to "मुद्दा हल करें",
            AppLanguage.TAMIL to "பிரச்சினையைத் தீர்க்கவும்"
        ),
        "Mark as In Progress" to mapOf(
            AppLanguage.ENGLISH to "Mark as In Progress",
            AppLanguage.TELUGU to "ప్రగతిలో ఉన్నట్లు మార్క్ చేయి",
            AppLanguage.HINDI to "प्रगति पर चिह्नित करें",
            AppLanguage.TAMIL to "செயல்பாட்டில் உள்ளதாகக் குறிக்கவும்"
        ),
        "Mark as Resolved" to mapOf(
            AppLanguage.ENGLISH to "Mark as Resolved",
            AppLanguage.TELUGU to "పరిష్కరించబడినట్లు మార్క్ చేయి",
            AppLanguage.HINDI to "हल किया गया चिह्नित करें",
            AppLanguage.TAMIL to "தீர்க்கப்பட்டதாகக் குறிக்கவும்"
        ),
        "Update Status" to mapOf(
            AppLanguage.ENGLISH to "Update Status",
            AppLanguage.TELUGU to "స్థితిని నవీకరించు",
            AppLanguage.HINDI to "स्थिति अपडेट करें",
            AppLanguage.TAMIL to "நிலையை புதுப்பிக்கவும்"
        ),
        "Official Action Center" to mapOf(
            AppLanguage.ENGLISH to "Official Action Center",
            AppLanguage.TELUGU to "అధికారిక చర్యల కేంద్రం",
            AppLanguage.HINDI to "आधिकारिक कार्रवाई केंद्र",
            AppLanguage.TAMIL to "அதிகாரப்பூர்வ நடவடிக்கை மையம்"
        ),
        "Change status, post real-time updates and provide feedback." to mapOf(
            AppLanguage.ENGLISH to "Change status, post real-time updates and provide feedback.",
            AppLanguage.TELUGU to "పరిష్కార స్థితిని మార్చండి, నిజ సమయ నవీకరణలను మరియు అభిప్రాయాన్ని అందించండి.",
            AppLanguage.HINDI to "स्थिति बदलें, रीयल-टाइम अपडेट पोस्ट करें और प्रतिक्रिया प्रदान करें।",
            AppLanguage.TAMIL to "நிலையை மாற்றவும், நிகழ்நேர புதுப்பிப்புகளை இடுகையிடவும் மற்றும் கருத்துக்களை வழங்கவும்."
        ),
        "Write an official resolution comment..." to mapOf(
            AppLanguage.ENGLISH to "Write an official resolution comment...",
            AppLanguage.TELUGU to "అధికారిక పరిష్కార వ్యాఖ్యను వ్రాయండి...",
            AppLanguage.HINDI to "आधिकारिक समाधान टिप्पणी लिखें...",
            AppLanguage.TAMIL to "அதிகாரப்பூர்வ தீர்வுக் கருத்தை எழுதவும்..."
        ),
        "Submit Update" to mapOf(
            AppLanguage.ENGLISH to "Submit Update",
            AppLanguage.TELUGU to "నవీకరణను సమర్పించు",
            AppLanguage.HINDI to "अपडेट सबमिट करें",
            AppLanguage.TAMIL to "புதுப்பிப்பைச் சமர்ப்பிக்கவும்"
        ),
        "Map View" to mapOf(
            AppLanguage.ENGLISH to "Map View",
            AppLanguage.TELUGU to "మ్యాప్ వీక్షణ",
            AppLanguage.HINDI to "मानचित्र दृश्य",
            AppLanguage.TAMIL to "வரைபடக் காட்சி"
        ),
        "Analytics Dashboard" to mapOf(
            AppLanguage.ENGLISH to "Analytics Dashboard",
            AppLanguage.TELUGU to "విశ్లేషణ డాష్‌బోర్డ్",
            AppLanguage.HINDI to "विश्लेषण डैशबोर्ड",
            AppLanguage.TAMIL to "பகுப்பாய்வு டாஷ்போர்டு"
        ),
        "Visual distribution of civic complaints in your city" to mapOf(
            AppLanguage.ENGLISH to "Visual distribution of civic complaints in your city",
            AppLanguage.TELUGU to "నగరంలో పౌర ఫిర్యాదుల దృశ్య వర్గీకరణ",
            AppLanguage.HINDI to "आपके शहर में नागरिक शिकायतों का दृश्य वितरण",
            AppLanguage.TAMIL to "உங்கள் நகரத்தில் சிவில் புகார்களின் காட்சி விநியோகம்"
        ),
        "Issue Details" to mapOf(
            AppLanguage.ENGLISH to "Issue Details",
            AppLanguage.TELUGU to "సమస్య వివరాలు",
            AppLanguage.HINDI to "मुद्दे का विवरण",
            AppLanguage.TAMIL to "பிரச்சினை விவரங்கள்"
        ),
        "Report New Civic Issue" to mapOf(
            AppLanguage.ENGLISH to "Report New Civic Issue",
            AppLanguage.TELUGU to "కొత్త పౌర సమస్యను నివేదించండి",
            AppLanguage.HINDI to "नए नागरिक मुद्दे की रिपोर्ट करें",
            AppLanguage.TAMIL to "புதிய சிவில் பிரச்சினையைப் புகாரளிக்கவும்"
        ),
        "Select Incident Category" to mapOf(
            AppLanguage.ENGLISH to "Select Incident Category",
            AppLanguage.TELUGU to "సమస్య వర్గాన్ని ఎంచుకోండి",
            AppLanguage.HINDI to "घटना श्रेणी चुनें",
            AppLanguage.TAMIL to "சம்பவ வகையைத் தேர்ந்தெடுக்கவும்"
        ),
        "Issue Title" to mapOf(
            AppLanguage.ENGLISH to "Issue Title",
            AppLanguage.TELUGU to "సమస్య శీర్షిక",
            AppLanguage.HINDI to "मुद्दे का शीर्षक",
            AppLanguage.TAMIL to "பிரச்சினை தலைப்பு"
        ),
        "e.g. Broken water pipe" to mapOf(
            AppLanguage.ENGLISH to "e.g. Broken water pipe",
            AppLanguage.TELUGU to "ఉదా. నీటి పైపు పగిలిపోయింది",
            AppLanguage.HINDI to "उदा. टूटी हुई पानी की पाइप",
            AppLanguage.TAMIL to "உதாரணம்: உடைந்த தண்ணீர் குழாய்"
        ),
        "Detailed Description" to mapOf(
            AppLanguage.ENGLISH to "Detailed Description",
            AppLanguage.TELUGU to "వివరణాత్మక వివరణ",
            AppLanguage.HINDI to "विस्तृत विवरण",
            AppLanguage.TAMIL to "விரிவான விளக்கம்"
        ),
        "e.g. Heavy leakage on Main Road for past 3 days..." to mapOf(
            AppLanguage.ENGLISH to "e.g. Heavy leakage on Main Road for past 3 days...",
            AppLanguage.TELUGU to "ఉదా. గత 3 రోజులుగా మెయిన్ రోడ్డుపై భారీ లీకేజీ...",
            AppLanguage.HINDI to "उदा. पिछले 3 दिनों से मुख्य सड़क पर भारी रिसाव...",
            AppLanguage.TAMIL to "உதாரணம்: கடந்த 3 நாட்களாக பிரதான சாலையில் கடுமையான கசிவு..."
        ),
        "Location / Landmark" to mapOf(
            AppLanguage.ENGLISH to "Location / Landmark",
            AppLanguage.TELUGU to "స్థలం / మైలురాయి",
            AppLanguage.HINDI to "स्थान / मील का पत्थर",
            AppLanguage.TAMIL to "இடம் / அடையாளச் சின்னம்"
        ),
        "e.g. Near Community Center, Block B" to mapOf(
            AppLanguage.ENGLISH to "e.g. Near Community Center, Block B",
            AppLanguage.TELUGU to "ఉదా. కమ్యూనిటీ సెంటర్ సమీపంలో, బ్లాక్ బి",
            AppLanguage.HINDI to "उदा. सामुदायिक केंद्र के पास, ब्लॉक बी",
            AppLanguage.TAMIL to "உதாரணம்: சமூக மையத்திற்கு அருகில், பிளாக் பி"
        ),
        "Capture / Add Evidence" to mapOf(
            AppLanguage.ENGLISH to "Capture / Add Evidence",
            AppLanguage.TELUGU to "ఆధారాలను జోడించండి",
            AppLanguage.HINDI to "साक्ष्य कैप्चर करें / जोड़ें",
            AppLanguage.TAMIL to "ஆதாரத்தைப் பிடிக்கவும் / சேர்க்கவும்"
        ),
        "Voice Description" to mapOf(
            AppLanguage.ENGLISH to "Voice Description",
            AppLanguage.TELUGU to "వాయిస్ వివరణ",
            AppLanguage.HINDI to "आवाज विवरण",
            AppLanguage.TAMIL to "குரல் விளக்கம்"
        ),
        "Submit Civic Complaint" to mapOf(
            AppLanguage.ENGLISH to "Submit Civic Complaint",
            AppLanguage.TELUGU to "పౌర ఫిర్యాదును సమర్పించు",
            AppLanguage.HINDI to "नागरिक शिकायत सबमिट करें",
            AppLanguage.TAMIL to "சிவில் புகாரைச் சமர்ப்பிக்கவும்"
        ),
        "Complaint submitted successfully!" to mapOf(
            AppLanguage.ENGLISH to "Complaint submitted successfully!",
            AppLanguage.TELUGU to "ఫిర్యాదు విజయవంతంగా సమర్పించబడింది!",
            AppLanguage.HINDI to "शिकायत सफलतापूर्वक सबमिट की गई!",
            AppLanguage.TAMIL to "புகார் வெற்றிகரமாக சமர்ப்பிக்கப்பட்டது!"
        ),
        "Submitting..." to mapOf(
            AppLanguage.ENGLISH to "Submitting...",
            AppLanguage.TELUGU to "సమర్పిస్తోంది...",
            AppLanguage.HINDI to "सबमिट किया जा रहा है...",
            AppLanguage.TAMIL to "சமர்ப்பிக்கப்படுகிறது..."
        ),
        "Audio recorded successfully" to mapOf(
            AppLanguage.ENGLISH to "Audio recorded successfully",
            AppLanguage.TELUGU to "ఆడియో విజయవంతంగా రికార్డ్ చేయబడింది",
            AppLanguage.HINDI to "ऑडियो सफलतापूर्वक रिकॉर्ड किया गया",
            AppLanguage.TAMIL to "ஒலிப்பதிவு வெற்றிகரமாக முடிந்தது"
        ),
        "Record Voice Description" to mapOf(
            AppLanguage.ENGLISH to "Record Voice Description",
            AppLanguage.TELUGU to "వాయిస్ వివరణను రికార్డ్ చేయి",
            AppLanguage.HINDI to "आवाज विवरण रिकॉर्ड करें",
            AppLanguage.TAMIL to "குரல் விளக்கத்தைப் பதிவு செய்யவும்"
        ),
        "Photo Evidence" to mapOf(
            AppLanguage.ENGLISH to "Photo Evidence",
            AppLanguage.TELUGU to "ఫోటో ఆధారం",
            AppLanguage.HINDI to "फोटो साक्ष्य",
            AppLanguage.TAMIL to "புகைப்பட ஆதாரம்"
        ),
        "Video Evidence" to mapOf(
            AppLanguage.ENGLISH to "Video Evidence",
            AppLanguage.TELUGU to "వీడియో ఆధారం",
            AppLanguage.HINDI to "वीडियो साक्ष्य",
            AppLanguage.TAMIL to "வீடியோ ஆதாரம்"
        ),
        "Take Photo with Camera" to mapOf(
            AppLanguage.ENGLISH to "Take Photo with Camera",
            AppLanguage.TELUGU to "కెమెరాతో ఫోటో తీయండి",
            AppLanguage.HINDI to "कैमरे से फोटो लें",
            AppLanguage.TAMIL to "கேமரா மூலம் புகைப்படம் எடுக்கவும்"
        ),
        "Choose from Gallery" to mapOf(
            AppLanguage.ENGLISH to "Choose from Gallery",
            AppLanguage.TELUGU to "గ్యాలరీ నుండి ఎంచుకోండి",
            AppLanguage.HINDI to "गैलरी से चुनें",
            AppLanguage.TAMIL to "கேலரியில் இருந்து தேர்ந்தெடுக்கவும்"
        ),
        "Record Video" to mapOf(
            AppLanguage.ENGLISH to "Record Video",
            AppLanguage.TELUGU to "వీడియో రికార్డ్ చేయి",
            AppLanguage.HINDI to "वीडियो रिकॉर्ड करें",
            AppLanguage.TAMIL to "வீடியோவை பதிவு செய்யவும்"
        ),
        "Select Video from Gallery" to mapOf(
            AppLanguage.ENGLISH to "Select Video from Gallery",
            AppLanguage.TELUGU to "గ్యాలరీ నుండి వీడియో ఎంచుకోండి",
            AppLanguage.HINDI to "गैलरी से वीडियो चुनें",
            AppLanguage.TAMIL to "கேலரியில் இருந்து வீடியோவைத் தேர்ந்தெடுக்கவும்"
        ),
        "Dismiss" to mapOf(
            AppLanguage.ENGLISH to "Dismiss",
            AppLanguage.TELUGU to "రద్దు చేయి",
            AppLanguage.HINDI to "खारिज करें",
            AppLanguage.TAMIL to "நிராகரி"
        ),
        "Citizen Profile Dashboard" to mapOf(
            AppLanguage.ENGLISH to "Citizen Profile Dashboard",
            AppLanguage.TELUGU to "పౌరుడి ప్రొఫైల్ డాష్‌బోర్డ్",
            AppLanguage.HINDI to "नागरिक प्रोफ़ाइल डैशबोर्ड",
            AppLanguage.TAMIL to "குடிமகன் சுயவிவர டாஷ்போர்டு"
        ),
        "Official Administrator" to mapOf(
            AppLanguage.ENGLISH to "Official Administrator",
            AppLanguage.TELUGU to "అధికారిక నిర్వాహకుడు",
            AppLanguage.HINDI to "आधिकारिक प्रशासक",
            AppLanguage.TAMIL to "அதிகாரப்பூர்வ நிர்வாகி"
        ),
        "Verified Citizen" to mapOf(
            AppLanguage.ENGLISH to "Verified Citizen",
            AppLanguage.TELUGU to "ధృవీకరించబడిన పౌరుడు",
            AppLanguage.HINDI to "सत्यापित नागरिक",
            AppLanguage.TAMIL to "சரிபார்க்கப்பட்ட குடிமகன்"
        ),
        "Your Submitted Complaints" to mapOf(
            AppLanguage.ENGLISH to "Your Submitted Complaints",
            AppLanguage.TELUGU to "మీరు సమర్పించిన ఫిర్యాదులు",
            AppLanguage.HINDI to "आपकी प्रस्तुत शिकायतें",
            AppLanguage.TAMIL to "நீங்கள் சமர்ப்பித்த புகார்கள்"
        ),
        "No complaints filed yet by your account." to mapOf(
            AppLanguage.ENGLISH to "No complaints filed yet by your account.",
            AppLanguage.TELUGU to "మీ ఖాతా ద్వారా ఇంకా ఎలాంటి ఫిర్యాదులు దాఖలు కాలేదు.",
            AppLanguage.HINDI to "आपके खाते द्वारा अभी तक कोई शिकायत दर्ज नहीं की गई है।",
            AppLanguage.TAMIL to "உங்கள் கணக்கிலிருந்து இதுவரை புகார்கள் எதுவும் பதிவு செய்யப்படவில்லை."
        ),
        "Language Settings" to mapOf(
            AppLanguage.ENGLISH to "Language Settings",
            AppLanguage.TELUGU to "భాష సెట్టింగులు",
            AppLanguage.HINDI to "भाषा सेटिंग्स",
            AppLanguage.TAMIL to "மொழி அமைப்புகள்"
        ),
        "Log Out" to mapOf(
            AppLanguage.ENGLISH to "Log Out",
            AppLanguage.TELUGU to "లాగ్ అవుట్",
            AppLanguage.HINDI to "लॉग आउट करें",
            AppLanguage.TAMIL to "வெளியேறு"
        ),
        "User Information" to mapOf(
            AppLanguage.ENGLISH to "User Information",
            AppLanguage.TELUGU to "వినియోగదారు సమాచారం",
            AppLanguage.HINDI to "उपयोगकर्ता जानकारी",
            AppLanguage.TAMIL to "பயனர் தகவல்"
        ),
        "Contact Email" to mapOf(
            AppLanguage.ENGLISH to "Contact Email",
            AppLanguage.TELUGU to "సంప్రదింపు ఇమెయిల్",
            AppLanguage.HINDI to "संपर्क ईमेल",
            AppLanguage.TAMIL to "தொடர்பு மின்னஞ்சல்"
        ),
        "Testing Tools (Simulated)" to mapOf(
            AppLanguage.ENGLISH to "Testing Tools (Simulated)",
            AppLanguage.TELUGU to "టెస్టింగ్ టూల్స్ (సిమ్యులేటెడ్)",
            AppLanguage.HINDI to "परीक्षण उपकरण (सिम्युलेटेड)",
            AppLanguage.TAMIL to "சோதனை கருவிகள் (உருவகப்படுத்தப்பட்டவை)"
        ),
        "Admin Permissions" to mapOf(
            AppLanguage.ENGLISH to "Admin Permissions",
            AppLanguage.TELUGU to "అడ్మిన్ అనుమతులు",
            AppLanguage.HINDI to "प्रशासक अनुमतियां",
            AppLanguage.TAMIL to "நிர்வாகி அனுமதிகள்"
        ),
        "Toggle government administrator override capabilities." to mapOf(
            AppLanguage.ENGLISH to "Toggle government administrator override capabilities.",
            AppLanguage.TELUGU to "ప్రభుత్వ నిర్వాహక అనుమతులను టోగుల్ చేయండి.",
            AppLanguage.HINDI to "सरकारी प्रशासक ओवरराइड क्षमताओं को टॉगल करें।",
            AppLanguage.TAMIL to "அரசு நிர்வாகி மேலெழுதும் திறன்களை மாற்றுங்கள்."
        ),
        "ROADS" to mapOf(
            AppLanguage.ENGLISH to "Roads",
            AppLanguage.TELUGU to "రోడ్లు",
            AppLanguage.HINDI to "सड़कें",
            AppLanguage.TAMIL to "சாலைகள்"
        ),
        "WATER" to mapOf(
            AppLanguage.ENGLISH to "Water",
            AppLanguage.TELUGU to "నీరు",
            AppLanguage.HINDI to "पानी",
            AppLanguage.TAMIL to "நீர்"
        ),
        "ELECTRICITY" to mapOf(
            AppLanguage.ENGLISH to "Electricity",
            AppLanguage.TELUGU to "విద్యుత్",
            AppLanguage.HINDI to "बिजली",
            AppLanguage.TAMIL to "மின்సாரம்"
        ),
        "GARBAGE" to mapOf(
            AppLanguage.ENGLISH to "Garbage",
            AppLanguage.TELUGU to "చెత్త",
            AppLanguage.HINDI to "कचरा",
            AppLanguage.TAMIL to "குப்பை"
        ),
        "OTHER" to mapOf(
            AppLanguage.ENGLISH to "Other",
            AppLanguage.TELUGU to "ఇతర",
            AppLanguage.HINDI to "अन्य",
            AppLanguage.TAMIL to "இதర"
        ),
        "Roads & Potholes" to mapOf(
            AppLanguage.ENGLISH to "Roads & Potholes",
            AppLanguage.TELUGU to "రోడ్లు & గుంతలు",
            AppLanguage.HINDI to "सड़कें और गड्ढे",
            AppLanguage.TAMIL to "சாலைகள் & குழிகள்"
        ),
        "Water Supply & Leaks" to mapOf(
            AppLanguage.ENGLISH to "Water Supply & Leaks",
            AppLanguage.TELUGU to "నీటి సరఫరా & లీకులు",
            AppLanguage.HINDI to "जलापूर्ति और रिसाव",
            AppLanguage.TAMIL to "நீர் வழங்கல் & கசிவுகள்"
        ),
        "Power Outages & Lights" to mapOf(
            AppLanguage.ENGLISH to "Power Outages & Lights",
            AppLanguage.TELUGU to "విద్యుత్ అంతరాయాలు & దీపాలు",
            AppLanguage.HINDI to "बिजली कटौती और लाइटें",
            AppLanguage.TAMIL to "மின் தடை & விளக்குகள்"
        ),
        "Garbage & Waste" to mapOf(
            AppLanguage.ENGLISH to "Garbage & Waste",
            AppLanguage.TELUGU to "చెత్త & వ్యర్థాలు",
            AppLanguage.HINDI to "कचरा और अपशिष्ट",
            AppLanguage.TAMIL to "குப்பை & கழிவு"
        ),
        "Other Civic Issues" to mapOf(
            AppLanguage.ENGLISH to "Other Civic Issues",
            AppLanguage.TELUGU to "ఇతర పౌర సమస్యలు",
            AppLanguage.HINDI to "अन्य नागरिक मुद्दे",
            AppLanguage.TAMIL to "இதర சிவில் பிரச்சினைகள்"
        ),
        "PENDING" to mapOf(
            AppLanguage.ENGLISH to "Pending",
            AppLanguage.TELUGU to "పెండింగ్‌లో ఉంది",
            AppLanguage.HINDI to "लंबित",
            AppLanguage.TAMIL to "நிலுவையில் உள்ளது"
        ),
        "IN_PROGRESS" to mapOf(
            AppLanguage.ENGLISH to "In Progress",
            AppLanguage.TELUGU to "ప్రగతిలో ఉంది",
            AppLanguage.HINDI to "प्रगति पर",
            AppLanguage.TAMIL to "செயல்பாட்டில் உள்ளது"
        ),
        "RESOLVED" to mapOf(
            AppLanguage.ENGLISH to "Resolved",
            AppLanguage.TELUGU to "పరిష్కరించబడింది",
            AppLanguage.HINDI to "हल किया गया",
            AppLanguage.TAMIL to "தீர்வு காணப்பட்டது"
        ),
        "Pending" to mapOf(
            AppLanguage.ENGLISH to "Pending",
            AppLanguage.TELUGU to "పెండింగ్‌లో ఉంది",
            AppLanguage.HINDI to "लंबित",
            AppLanguage.TAMIL to "நிலுவையில் உள்ளது"
        ),
        "In Progress" to mapOf(
            AppLanguage.ENGLISH to "In Progress",
            AppLanguage.TELUGU to "ప్రగతిలో ఉంది",
            AppLanguage.HINDI to "प्रगति पर",
            AppLanguage.TAMIL to "செயல்பாட்டில் உள்ளது"
        ),
        "Resolved" to mapOf(
            AppLanguage.ENGLISH to "Resolved",
            AppLanguage.TELUGU to "పరిష్కరించబడింది",
            AppLanguage.HINDI to "हल किया गया",
            AppLanguage.TAMIL to "தீர்வு காணப்பட்டது"
        ),
        "Feed" to mapOf(
            AppLanguage.ENGLISH to "Feed",
            AppLanguage.TELUGU to "ఫీడ్",
            AppLanguage.HINDI to "फ़ीड",
            AppLanguage.TAMIL to "செய்தி ஓடை"
        ),
        "Submit" to mapOf(
            AppLanguage.ENGLISH to "Submit",
            AppLanguage.TELUGU to "సమర్పించు",
            AppLanguage.HINDI to "जमा करें",
            AppLanguage.TAMIL to "சமர்ப்பి"
        ),
        "Profile" to mapOf(
            AppLanguage.ENGLISH to "Profile",
            AppLanguage.TELUGU to "ప్రొఫైల్",
            AppLanguage.HINDI to "प्रोफ़ाइल",
            AppLanguage.TAMIL to "சுயவிவரம்"
        ),
        "Admin" to mapOf(
            AppLanguage.ENGLISH to "Admin",
            AppLanguage.TELUGU to "అడ్మిన్",
            AppLanguage.HINDI to "प्रशासक",
            AppLanguage.TAMIL to "நிர்வாகி"
        ),
        "Select Language" to mapOf(
            AppLanguage.ENGLISH to "Select Language",
            AppLanguage.TELUGU to "భాషను ఎంచుకోండి",
            AppLanguage.HINDI to "भाषा चुनें",
            AppLanguage.TAMIL to "மொழியைத் தேர்ந்தெடுக்கவும்"
        )
    )

    fun getString(key: String, lang: AppLanguage): String {
        val normalizedKey = key.trim()
        val langMap = translations[normalizedKey] 
            ?: translations[normalizedKey.uppercase()] 
            ?: translations[normalizedKey.lowercase().replaceFirstChar { it.uppercase() }]
        if (langMap != null) {
            return langMap[lang] ?: key
        }
        
        // Let's also do a fallback search for contains or ignorecase
        val matchingKey = translations.keys.find { it.equals(normalizedKey, ignoreCase = true) }
        if (matchingKey != null) {
            return translations[matchingKey]?.get(lang) ?: key
        }

        return key
    }
}

fun String.localized(lang: AppLanguage): String {
    return Localization.getString(this, lang)
}
