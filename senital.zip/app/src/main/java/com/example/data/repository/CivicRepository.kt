package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.data.local.ComplaintDao
import com.example.model.Complaint
import com.example.model.ComplaintEntity
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class CivicRepository(
    private val context: Context,
    private val complaintDao: ComplaintDao
) {
    private var firestore: FirebaseFirestore? = null
    private var storage: FirebaseStorage? = null
    private var realtimeListener: com.google.firebase.firestore.ListenerRegistration? = null
    
    private val _syncState = MutableStateFlow<SyncState>(SyncState.LocalOnly("Awaiting initialization"))
    val syncState: StateFlow<SyncState> = _syncState

    init {
        initializeFirestore()
    }

    private fun initializeFirestore() {
        try {
            // Check if any Firebase Apps are initialized. If google-services.json is missing,
            // FirebaseApp.getInstance() or FirebaseFirestore.getInstance() will throw.
            val apps = FirebaseApp.getApps(context)
            if (apps.isNotEmpty()) {
                firestore = FirebaseFirestore.getInstance()
                storage = FirebaseStorage.getInstance()
                _syncState.value = SyncState.Synced
                Log.d("CivicRepository", "Firebase Firestore and Storage initialized successfully!")
                startRealtimeSync()
            } else {
                _syncState.value = SyncState.LocalOnly("Offline/Simulation Mode (No google-services.json)")
                Log.w("CivicRepository", "No Firebase App found. Using high-fidelity offline database mode.")
                insertDefaultLocalComplaintsIfEmpty()
            }
        } catch (e: Exception) {
            _syncState.value = SyncState.LocalOnly("Offline Fallback: ${e.localizedMessage}")
            Log.w("CivicRepository", "Firestore initialisation failed. Running in Local Room cache mode: ${e.message}")
            insertDefaultLocalComplaintsIfEmpty()
        }
    }

    // Connect to Firestore so data syncs in real time
    private fun startRealtimeSync() {
        val fs = firestore ?: return
        try {
            realtimeListener?.remove()
            realtimeListener = fs.collection("complaints")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e("CivicRepository", "Firestore real-time sync failed.", error)
                        _syncState.value = SyncState.LocalOnly("Real-time sync error: ${error.localizedMessage}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null) {
                        Log.d("CivicRepository", "Real-time snapshot received with ${snapshot.size()} documents.")
                        _syncState.value = SyncState.Syncing
                        CoroutineScope(Dispatchers.IO).launch {
                            try {
                                val remoteComplaints = snapshot.documents.mapNotNull { doc ->
                                    try {
                                        val id = doc.getString("id") ?: doc.id
                                        val title = doc.getString("title") ?: ""
                                        val description = doc.getString("description") ?: ""
                                        val category = doc.getString("category") ?: "OTHER"
                                        val location = doc.getString("location") ?: "Unknown"
                                        val status = doc.getString("status") ?: "PENDING"
                                        val attachmentType = doc.getString("attachmentType") ?: "NONE"
                                        val attachmentUrl = doc.getString("attachmentUrl")
                                        val timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()
                                        val userId = doc.getString("userId") ?: ""
                                        val userName = doc.getString("userName") ?: "Anonymous"
                                        val officialComment = doc.getString("officialComment")
                                        
                                        ComplaintEntity(
                                            id = id,
                                            title = title,
                                            description = description,
                                            category = category,
                                            location = location,
                                            status = status,
                                            attachmentType = attachmentType,
                                            attachmentUrl = attachmentUrl,
                                            timestamp = timestamp,
                                            userId = userId,
                                            userEmail = userId, // Using userId as fallback for userEmail
                                            userName = userName,
                                            officialComment = officialComment
                                        )
                                    } catch (e: Exception) {
                                        Log.e("CivicRepository", "Error parsing doc ${doc.id}", e)
                                        null
                                    }
                                }
                                if (remoteComplaints.isNotEmpty()) {
                                    complaintDao.insertComplaints(remoteComplaints)
                                }
                                _syncState.value = SyncState.Synced
                            } catch (e: Exception) {
                                Log.e("CivicRepository", "Error caching synced documents to Room", e)
                                _syncState.value = SyncState.LocalOnly("Local Cache Write Error")
                            }
                        }
                    }
                }
        } catch (e: Exception) {
            Log.e("CivicRepository", "Failed to start real-time Firestore listener", e)
            _syncState.value = SyncState.LocalOnly("Listener failed: ${e.localizedMessage}")
        }
    }

    // High fidelity simulator method to demonstrate real-time updates when offline
    suspend fun simulateRemoteUpdateArrival() {
        withContext(Dispatchers.IO) {
            _syncState.value = SyncState.Syncing
            kotlinx.coroutines.delay(1200) // Simulating network latency

            val randomTitles = listOf(
                "Water Main Burst on Maple Street",
                "Damaged Street Sign on 5th Avenue",
                "Graffiti on Community Center Wall",
                "Street Light Out on Pine Road",
                "Overflowing Recycling Bin in Central Park"
            )
            val randomDescriptions = listOf(
                "Water has flooded the sidewalk and is flowing down the gutter. Very high pressure, needs quick attention.",
                "The stop sign is bent at a 45-degree angle and is difficult for incoming motorists to see.",
                "Large graffiti mural on the north facing brick wall of the community center, needs painting over.",
                "The street light is completely out, making the corner very dark and unsafe at night.",
                "Recycling container is completely filled and trash is blowing across the lawn."
            )
            val randomCategories = listOf("WATER", "ROADS", "OTHER", "ELECTRICITY", "GARBAGE")
            val randomUsers = listOf("citizen.test@gmail.com", "jane.doe@gmail.com", "john.smith@gmail.com")
            val randomUserNames = listOf("Alex Rivera", "Jane Doe", "John Smith")

            val index = (Math.random() * randomTitles.size).toInt()
            val userIndex = (Math.random() * randomUsers.size).toInt()
            val id = "simulated-realtime-" + System.currentTimeMillis()

            val newComplaint = ComplaintEntity(
                id = id,
                title = randomTitles[index],
                description = randomDescriptions[index],
                category = randomCategories[index],
                location = "34.05${(10 + Math.random() * 80).toInt()} N, 118.24${(10 + Math.random() * 80).toInt()} W (Simulated Real-time Update)",
                status = "PENDING",
                attachmentType = "NONE",
                attachmentUrl = null,
                timestamp = System.currentTimeMillis(),
                userId = randomUsers[userIndex],
                userEmail = randomUsers[userIndex],
                userName = randomUserNames[userIndex],
                officialComment = null
            )

            complaintDao.insertComplaint(newComplaint)
            
            _syncState.value = SyncState.Synced
            Log.d("CivicRepository", "Simulated realtime update synced successfully!")
        }
    }

    // Expose all public complaints reactively
    val allComplaintsFlow: Flow<List<Complaint>> = complaintDao.getAllComplaints().map { list ->
        list.map { it.toDomain() }
    }

    // Expose complaints for a specific resident
    fun getComplaintsByUserId(userId: String): Flow<List<Complaint>> {
        return complaintDao.getComplaintsByUserId(userId).map { list ->
            list.map { it.toDomain() }
        }
    }

    suspend fun upvoteComplaint(id: String) {
        withContext(Dispatchers.IO) {
            val complaint = complaintDao.getComplaintById(id)
            if (complaint != null) {
                val updatedComplaint = complaint.copy(upvoteCount = complaint.upvoteCount + 1)
                complaintDao.insertComplaint(updatedComplaint)
                
                // Sync to Firestore
                val fs = firestore
                if (fs != null) {
                    try {
                        fs.collection("complaints").document(id).update("upvoteCount", updatedComplaint.upvoteCount).await()
                    } catch (e: Exception) {
                        Log.e("CivicRepository", "Failed to sync upvote", e)
                    }
                }
            }
        }
    }

    // Submit complaint
    suspend fun submitComplaint(complaint: Complaint) {
        withContext(Dispatchers.IO) {
            // Save to Local Room DB first (Offline-first)
            complaintDao.insertComplaint(complaint.toEntity())
            Log.d("CivicRepository", "Complaint saved locally in Room: ${complaint.id}")

            // Try to push to Firestore
            val fs = firestore
            if (fs != null) {
                try {
                    _syncState.value = SyncState.Syncing
                    fs.collection("complaints")
                        .document(complaint.id)
                        .set(complaint)
                        .await()
                    _syncState.value = SyncState.Synced
                    Log.d("CivicRepository", "Complaint synced to Firestore: ${complaint.id}")
                } catch (e: Exception) {
                    _syncState.value = SyncState.LocalOnly("Sync Error: ${e.localizedMessage}. Queued locally.")
                    Log.e("CivicRepository", "Failed to sync complaint to Firestore, stored locally.", e)
                }
            }
        }
    }

    // Update Complaint Status (Admin/Officials capability)
    suspend fun updateComplaintStatus(id: String, status: String, officialComment: String?) {
        withContext(Dispatchers.IO) {
            // Update locally
            complaintDao.updateComplaintStatus(id, status, officialComment)
            Log.d("CivicRepository", "Complaint status updated locally: $id -> $status")

            // Update in Firestore
            val fs = firestore
            if (fs != null) {
                try {
                    _syncState.value = SyncState.Syncing
                    val updates = mapOf(
                        "status" to status,
                        "officialComment" to officialComment
                    )
                    fs.collection("complaints")
                        .document(id)
                        .set(updates, SetOptions.merge())
                        .await()
                    _syncState.value = SyncState.Synced
                    Log.d("CivicRepository", "Complaint status synced to Firestore: $id")
                } catch (e: Exception) {
                    _syncState.value = SyncState.LocalOnly("Sync Error: ${e.localizedMessage}")
                    Log.e("CivicRepository", "Failed to sync status update to Firestore.", e)
                }
            }
        }
    }

    // Fetch and cache remote complaints
    suspend fun fetchRemoteComplaints() {
        val fs = firestore ?: return
        withContext(Dispatchers.IO) {
            try {
                _syncState.value = SyncState.Syncing
                val snapshot = fs.collection("complaints")
                    .get()
                    .await()
                
                val remoteComplaints = snapshot.documents.mapNotNull { doc ->
                    try {
                        val id = doc.getString("id") ?: doc.id
                        val title = doc.getString("title") ?: ""
                        val description = doc.getString("description") ?: ""
                        val category = doc.getString("category") ?: "OTHER"
                        val location = doc.getString("location") ?: "Unknown"
                        val status = doc.getString("status") ?: "PENDING"
                        val attachmentType = doc.getString("attachmentType") ?: "NONE"
                        val attachmentUrl = doc.getString("attachmentUrl")
                        val timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()
                        val userId = doc.getString("userId") ?: ""
                        val userName = doc.getString("userName") ?: "Anonymous"
                        val officialComment = doc.getString("officialComment")
                        
                        ComplaintEntity(
                            id = id,
                            title = title,
                            description = description,
                            category = category,
                            location = location,
                            status = status,
                            attachmentType = attachmentType,
                            attachmentUrl = attachmentUrl,
                            timestamp = timestamp,
                            userId = userId,
                                            userEmail = userId,
                            userName = userName,
                            officialComment = officialComment
                        )
                    } catch (e: Exception) {
                        Log.e("CivicRepository", "Error parsing doc ${doc.id}", e)
                        null
                    }
                }

                if (remoteComplaints.isNotEmpty()) {
                    complaintDao.insertComplaints(remoteComplaints)
                }
                _syncState.value = SyncState.Synced
            } catch (e: Exception) {
                _syncState.value = SyncState.LocalOnly("Fetch Failed: ${e.localizedMessage}")
                Log.e("CivicRepository", "Failed to fetch remote complaints.", e)
            }
        }
    }

    // High fidelity seed data for demonstration so the app feels full on first launch
    private fun insertDefaultLocalComplaintsIfEmpty() {
        CoroutineScope(Dispatchers.IO).launch {
            // Use custom check on DB count or just check flow
            // Since Room requires a thread or helper:
            try {
                // If the flow is empty or no entities exist, insert nice seed issues:
                val list = complaintDao.getComplaintById("seed-1")
                if (list == null) {
                    val seed1 = ComplaintEntity(
                        id = "seed-1",
                        title = "Major Pothole on Oak Avenue",
                        description = "There is a deep pothole on Oak Avenue near the 4th block crossing. It is extremely hazardous for motorcycles and has caused a near-accident. Needs immediate filling.",
                        category = "ROADS",
                        location = "34.0522 N, 118.2437 W (Oak Ave & 4th St)",
                        status = "PENDING",
                        attachmentType = "PHOTO",
                        attachmentUrl = "simulated_pothole",
                        timestamp = System.currentTimeMillis() - 86400000, // 1 day ago
                        userId = "citizen1@gmail.com",
                        userEmail = "citizen1@gmail.com",
                        userName = "Alex Mercer",
                        officialComment = null
                    )
                    val seed2 = ComplaintEntity(
                        id = "seed-2",
                        title = "Water Leak at Main Street Mainline",
                        description = "Water is gushing out of the pavement near the public library. It has been running for 6 hours now, wasting clean municipal drinking water.",
                        category = "WATER",
                        location = "34.0530 N, 118.2445 W (Main St Public Library)",
                        status = "IN_PROGRESS",
                        attachmentType = "VIDEO",
                        attachmentUrl = "simulated_water_leak",
                        timestamp = System.currentTimeMillis() - 172800000, // 2 days ago
                        userId = "citizen2@gmail.com",
                        userEmail = "citizen2@gmail.com",
                        userName = "Sophia Carter",
                        officialComment = "Public Works Dispatch #2409 dispatched repair crew to isolate and repair the main valve."
                    )
                    val seed3 = ComplaintEntity(
                        id = "seed-3",
                        title = "Power Line Flickering & Sparking",
                        description = "During high winds, the power line connecting to the substation sparks and lights go out. Very dangerous, could start a fire.",
                        category = "ELECTRICITY",
                        location = "34.0510 N, 118.2410 W (Maple Substation)",
                        status = "RESOLVED",
                        attachmentType = "AUDIO",
                        attachmentUrl = "simulated_electricity_sparking",
                        timestamp = System.currentTimeMillis() - 259200000, // 3 days ago
                        userId = "citizen3@gmail.com",
                        userEmail = "citizen3@gmail.com",
                        userName = "Marcus Brody",
                        officialComment = "Electrical engineers cleared overgrown tree branches and replaced the damaged insulator on Pole #89B. Normal voltage restored."
                    )
                    val seed4 = ComplaintEntity(
                        id = "seed-4",
                        title = "Illegal Trash Dumping in Greenway",
                        description = "Unidentified truck dumped multiple bags of commercial garbage and old tires directly into the nature trail greenway.",
                        category = "GARBAGE",
                        location = "34.0550 N, 118.2480 W (Greenway Trailhead)",
                        status = "PENDING",
                        attachmentType = "PHOTO",
                        attachmentUrl = "simulated_garbage_dumping",
                        timestamp = System.currentTimeMillis() - 43200000, // 12 hours ago
                        userId = "citizen1@gmail.com",
                        userEmail = "citizen1@gmail.com",
                        userName = "Alex Mercer",
                        officialComment = null
                    )
                    val seed5 = ComplaintEntity(
                        id = "seed-5",
                        title = "Broken Streetlight on Pine Street",
                        description = "The streetlight in front of house #142 on Pine Street has been completely dead for over a week, leaving the entire corner pitch black at night. This is a safety issue for kids walking home from evening activities.",
                        category = "ELECTRICITY",
                        location = "34.0544 N, 118.2422 W (142 Pine Street)",
                        status = "PENDING",
                        attachmentType = "NONE",
                        attachmentUrl = null,
                        timestamp = System.currentTimeMillis() - 28800000, // 8 hours ago
                        userId = "citizen4@gmail.com",
                        userEmail = "citizen4@gmail.com",
                        userName = "Elena Rostova",
                        officialComment = null
                    )
                    val seed6 = ComplaintEntity(
                        id = "seed-6",
                        title = "Clogged Storm Drain Flooding Roadway",
                        description = "After yesterday's heavy rain, the storm drain at the intersection of Elm and 7th is completely blocked by dead leaves and plastic trash. Water is pooling up to 6 inches deep, forcing cars to swerve dangerously.",
                        category = "WATER",
                        location = "34.0562 N, 118.2468 W (Elm St & 7th Ave)",
                        status = "IN_PROGRESS",
                        attachmentType = "PHOTO",
                        attachmentUrl = "simulated_clogged_drain",
                        timestamp = System.currentTimeMillis() - 129600000, // 1.5 days ago
                        userId = "citizen5@gmail.com",
                        userEmail = "citizen5@gmail.com",
                        userName = "David Kim",
                        officialComment = "Road maintenance crew has cleared the surface debris. Vacuum truck has been scheduled to clear internal blockages tomorrow."
                    )
                    val seed7 = ComplaintEntity(
                        id = "seed-7",
                        title = "Abandoned Sofa Blocking Sidewalk",
                        description = "Someone left a large, waterlogged old sofa on the narrow sidewalk near the corner of Maple Avenue and 9th Street. Pedestrians, especially parents with strollers, are forced to step into the busy road to bypass it.",
                        category = "GARBAGE",
                        location = "34.0505 N, 118.2395 W (Maple Ave & 9th St)",
                        status = "RESOLVED",
                        attachmentType = "PHOTO",
                        attachmentUrl = "simulated_abandoned_sofa",
                        timestamp = System.currentTimeMillis() - 345600000, // 4 days ago
                        userId = "citizen1@gmail.com",
                        userEmail = "citizen1@gmail.com",
                        userName = "Alex Mercer",
                        officialComment = "Waste Management Special Pickup team removed the item and cleaned up minor debris around the site."
                    )
                    val seed8 = ComplaintEntity(
                        id = "seed-8",
                        title = "Faded Pedestrian Crosswalk Markings",
                        description = "The white lines at the busy pedestrian crosswalk near the High School on Cedar Road are almost completely worn out. Drivers cannot see the crossing zone, which poses an immediate safety threat to students.",
                        category = "ROADS",
                        location = "34.0588 N, 118.2510 W (Cedar Rd near High School)",
                        status = "PENDING",
                        attachmentType = "NONE",
                        attachmentUrl = null,
                        timestamp = System.currentTimeMillis() - 36000000, // 10 hours ago
                        userId = "citizen2@gmail.com",
                        userEmail = "citizen2@gmail.com",
                        userName = "Sophia Carter",
                        officialComment = null
                    )
                    val seed9 = ComplaintEntity(
                        id = "seed-9",
                        title = "Excessive Loud Noise from Construction Site",
                        description = "The commercial building project on Park Boulevard is starting jackhammer operations at 5:30 AM every day, well before the permitted 7:00 AM weekday noise ordinance. It's disrupting sleep for the entire block.",
                        category = "OTHER",
                        location = "34.0535 N, 118.2450 W (250 Park Blvd)",
                        status = "IN_PROGRESS",
                        attachmentType = "AUDIO",
                        attachmentUrl = "simulated_construction_noise",
                        timestamp = System.currentTimeMillis() - 259200000, // 3 days ago
                        userId = "citizen6@gmail.com",
                        userEmail = "citizen6@gmail.com",
                        userName = "Brian O'Conner",
                        officialComment = "Code Enforcement Officer investigated the site. A formal warning letter was issued to the contractor regarding work hours. Fines will follow if violations persist."
                    )
                    val seed10 = ComplaintEntity(
                        id = "seed-10",
                        title = "Traffic Signal Timing Out of Sync",
                        description = "The green light duration for north-bound traffic on Grand Avenue at 12th Street is lasting only 4 seconds, causing a massive 1-mile gridlock during rush hour. It seems the sensor loop or timer is misconfigured.",
                        category = "ROADS",
                        location = "34.0490 N, 118.2380 W (Grand Ave & 12th St)",
                        status = "RESOLVED",
                        attachmentType = "VIDEO",
                        attachmentUrl = "simulated_traffic_light",
                        timestamp = System.currentTimeMillis() - 432000000, // 5 days ago
                        userId = "citizen3@gmail.com",
                        userEmail = "citizen3@gmail.com",
                        userName = "Marcus Brody",
                        officialComment = "Traffic Engineering department calibrated the local controller and updated the timing cycle. Green window increased to 35 seconds during peak hours."
                    )
                    val seed11 = ComplaintEntity(
                        id = "seed-11",
                        title = "Public Park Litter Bins Overflowing",
                        description = "All three garbage bins near the children's playground in Riverside Park are completely overflowing. Wind is blowing food wrappers, soda cans, and plastic packaging into the grass and play areas.",
                        category = "GARBAGE",
                        location = "34.0570 N, 118.2495 W (Riverside Park Playground)",
                        status = "PENDING",
                        attachmentType = "PHOTO",
                        attachmentUrl = "simulated_park_litter",
                        timestamp = System.currentTimeMillis() - 18000000, // 5 hours ago
                        userId = "citizen7@gmail.com",
                        userEmail = "citizen7@gmail.com",
                        userName = "Maya Lin",
                        officialComment = null
                    )
                    val seed12 = ComplaintEntity(
                        id = "seed-12",
                        title = "Low Water Pressure in North Sector",
                        description = "Starting this morning, water pressure throughout our apartment complex on Birch Street has dropped to a trickle. It's barely enough to wash dishes, let alone take a shower. No scheduled maintenance was announced.",
                        category = "WATER",
                        location = "34.0595 N, 118.2532 W (400 Birch Street Complex)",
                        status = "IN_PROGRESS",
                        attachmentType = "NONE",
                        attachmentUrl = null,
                        timestamp = System.currentTimeMillis() - 21600000, // 6 hours ago
                        userId = "citizen8@gmail.com",
                        userEmail = "citizen8@gmail.com",
                        userName = "Jordan Taylor",
                        officialComment = "Water department is investigating a potential pressure drop at the Sector 4 booster station. Repair crews are on-site."
                    )

                    complaintDao.insertComplaints(
                        listOf(
                            seed1, seed2, seed3, seed4, 
                            seed5, seed6, seed7, seed8, 
                            seed9, seed10, seed11, seed12
                        )
                    )
                    Log.d("CivicRepository", "Inserted default high-fidelity seed complaints successfully!")
                }
            } catch (e: Exception) {
                Log.e("CivicRepository", "Error seeding data", e)
            }
        }
    }

    suspend fun uploadFile(uri: Uri, attachmentType: String, id: String): String? {
        val st = storage ?: return null
        return withContext(Dispatchers.IO) {
            try {
                val filename = "attachments/${id}/${attachmentType.lowercase()}_${System.currentTimeMillis()}"
                val ref = st.reference.child(filename)
                ref.putFile(uri).await()
                ref.downloadUrl.await().toString()
            } catch (e: Exception) {
                Log.e("CivicRepository", "Failed to upload file to Firebase Storage", e)
                null
            }
        }
    }

    suspend fun saveUriToInternalStorage(uri: Uri, prefix: String): String {
        return withContext(Dispatchers.IO) {
            try {
                val extension = when (context.contentResolver.getType(uri)) {
                    "image/jpeg", "image/jpg" -> "jpg"
                    "image/png" -> "png"
                    "audio/mpeg", "audio/mp3", "audio/m4a" -> "mp3"
                    "audio/wav", "audio/x-wav" -> "wav"
                    "audio/3gpp" -> "3gp"
                    "video/mp4" -> "mp4"
                    else -> "bin"
                }
                val filename = "${prefix}_${System.currentTimeMillis()}.$extension"
                val destFile = java.io.File(context.filesDir, filename)
                context.contentResolver.openInputStream(uri)?.use { input ->
                    destFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
                Uri.fromFile(destFile).toString()
            } catch (e: Exception) {
                Log.e("CivicRepository", "Error saving Uri to internal storage", e)
                uri.toString()
            }
        }
    }
}

sealed class SyncState {
    object Synced : SyncState()
    object Syncing : SyncState()
    data class LocalOnly(val reason: String) : SyncState()
}
