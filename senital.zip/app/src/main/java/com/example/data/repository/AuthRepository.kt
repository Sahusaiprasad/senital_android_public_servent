package com.example.data.repository

import android.content.Context
import android.util.Log
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class CivicUser(
    val uid: String,
    val displayName: String,
    val email: String,
    val photoUrl: String?,
    val isAdmin: Boolean = false
)

class AuthRepository(private val context: Context) {
    private var firebaseAuth: FirebaseAuth? = null
    private var firestore: FirebaseFirestore? = null

    private val _currentUser = MutableStateFlow<CivicUser?>(null)
    val currentUser: StateFlow<CivicUser?> = _currentUser

    private val _isFirebaseAuthConfigured = MutableStateFlow(false)
    val isFirebaseAuthConfigured: StateFlow<Boolean> = _isFirebaseAuthConfigured

    // Simulated local registration for full offline/simulation fallback
    private val simulatedUsers = mutableMapOf<String, SimulatedUserData>()

    data class SimulatedUserData(
        val email: String,
        val password: String,
        val displayName: String,
        val isAdmin: Boolean
    )

    init {
        // Pre-populate simulated users for seamless presets
        simulatedUsers["alex.mercer@gmail.com"] = SimulatedUserData("alex.mercer@gmail.com", "password", "Alex Mercer", false)
        simulatedUsers["sophia.carter@gmail.com"] = SimulatedUserData("sophia.carter@gmail.com", "password", "Sophia Carter", false)
        simulatedUsers["chief.davis@gov.org"] = SimulatedUserData("chief.davis@gov.org", "password", "Chief Inspector Davis", true)
        simulatedUsers["divyapalleti2006@gmail.com"] = SimulatedUserData("divyapalleti2006@gmail.com", "12345678", "Divya Palleti", true)

        try {
            val apps = FirebaseApp.getApps(context)
            if (apps.isNotEmpty()) {
                firebaseAuth = FirebaseAuth.getInstance()
                firestore = FirebaseFirestore.getInstance()
                _isFirebaseAuthConfigured.value = true
                
                firebaseAuth?.addAuthStateListener { auth ->
                    val firebaseUser = auth.currentUser
                    if (firebaseUser != null) {
                        val email = firebaseUser.email ?: ""
                        val uid = firebaseUser.uid
                        _currentUser.value = CivicUser(
                            uid = uid,
                            displayName = firebaseUser.displayName ?: displayNameFromEmail(email),
                            email = email,
                            photoUrl = firebaseUser.photoUrl?.toString(),
                            isAdmin = checkIfAdmin(email)
                        )
                        // Fetch real status from Firestore
                        fetchAdminStatusFromFirestore(uid, email)
                    } else {
                        _currentUser.value = null
                    }
                }
            } else {
                Log.w("AuthRepository", "Firebase not initialized. Running Auth in offline/simulator mode.")
            }
        } catch (e: Exception) {
            Log.w("AuthRepository", "Failed to init Firebase Auth, using local simulator: ${e.message}")
        }
    }

    private fun checkIfAdmin(email: String): Boolean {
        return email.equals("divyapalleti2006@gmail.com", ignoreCase = true) || email.endsWith("@gov.org")
    }

    private fun fetchAdminStatusFromFirestore(uid: String, email: String) {
        val fs = firestore ?: return
        fs.collection("users").document(uid).get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    val isAdmin = document.getBoolean("isAdmin") ?: false
                    val current = _currentUser.value
                    if (current != null && current.uid == uid) {
                        _currentUser.value = current.copy(isAdmin = isAdmin || checkIfAdmin(email))
                    }
                }
            }
            .addOnFailureListener { e ->
                Log.w("AuthRepository", "Failed to fetch user role from Firestore: ${e.message}")
            }
    }

    // Email/Password Sign Up
    fun signUpWithEmail(
        email: String,
        password: String,
        displayName: String,
        isAdmin: Boolean,
        onSuccess: (CivicUser) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        val mAuth = firebaseAuth
        val mFirestore = firestore
        if (mAuth != null && mFirestore != null) {
            mAuth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener { authResult ->
                    val firebaseUser = authResult.user
                    if (firebaseUser != null) {
                        val profileUpdates = UserProfileChangeRequest.Builder()
                            .setDisplayName(displayName)
                            .build()
                        
                        firebaseUser.updateProfile(profileUpdates)
                            .addOnCompleteListener { _ ->
                                val userData = mapOf(
                                    "uid" to firebaseUser.uid,
                                    "displayName" to displayName,
                                    "email" to email,
                                    "isAdmin" to isAdmin
                                )
                                mFirestore.collection("users").document(firebaseUser.uid)
                                    .set(userData, SetOptions.merge())
                                    .addOnSuccessListener {
                                        val user = CivicUser(
                                            uid = firebaseUser.uid,
                                            displayName = displayName,
                                            email = email,
                                            photoUrl = null,
                                            isAdmin = isAdmin || checkIfAdmin(email)
                                        )
                                        _currentUser.value = user
                                        onSuccess(user)
                                    }
                                    .addOnFailureListener { e ->
                                        // Even if Firestore fails, sign in the user
                                        val user = CivicUser(
                                            uid = firebaseUser.uid,
                                            displayName = displayName,
                                            email = email,
                                            photoUrl = null,
                                            isAdmin = isAdmin || checkIfAdmin(email)
                                        )
                                        _currentUser.value = user
                                        onSuccess(user)
                                    }
                            }
                    } else {
                        onFailure(Exception("Created user is null"))
                    }
                }
                .addOnFailureListener { e ->
                    onFailure(e)
                }
        } else {
            // Simulated local mode
            if (simulatedUsers.containsKey(email.lowercase())) {
                onFailure(Exception("The email address is already in use by another account."))
                return
            }
            val newUser = SimulatedUserData(email.lowercase(), password, displayName, isAdmin)
            simulatedUsers[email.lowercase()] = newUser
            
            val user = CivicUser(
                uid = "simulated-uid-" + email.hashCode(),
                displayName = displayName,
                email = email,
                photoUrl = "https://api.dicebear.com/7.x/adventurer/svg?seed=" + displayName.replace(" ", ""),
                isAdmin = isAdmin || checkIfAdmin(email)
            )
            _currentUser.value = user
            onSuccess(user)
        }
    }

    // Email/Password Sign In
    fun signInWithEmail(
        email: String,
        password: String,
        onSuccess: (CivicUser) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        val mAuth = firebaseAuth
        val mFirestore = firestore
        if (mAuth != null && mFirestore != null) {
            mAuth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener { authResult ->
                    val firebaseUser = authResult.user
                    if (firebaseUser != null) {
                        val userEmail = firebaseUser.email ?: email
                        val uid = firebaseUser.uid
                        mFirestore.collection("users").document(uid).get()
                            .addOnSuccessListener { document ->
                                val isAdmin = if (document != null && document.exists()) {
                                    document.getBoolean("isAdmin") ?: false
                                } else {
                                    checkIfAdmin(userEmail)
                                }
                                val user = CivicUser(
                                    uid = uid,
                                    displayName = firebaseUser.displayName ?: displayNameFromEmail(userEmail),
                                    email = userEmail,
                                    photoUrl = firebaseUser.photoUrl?.toString(),
                                    isAdmin = isAdmin || checkIfAdmin(userEmail)
                                )
                                _currentUser.value = user
                                onSuccess(user)
                            }
                            .addOnFailureListener { e ->
                                val user = CivicUser(
                                    uid = uid,
                                    displayName = firebaseUser.displayName ?: displayNameFromEmail(userEmail),
                                    email = userEmail,
                                    photoUrl = firebaseUser.photoUrl?.toString(),
                                    isAdmin = checkIfAdmin(userEmail)
                                )
                                _currentUser.value = user
                                onSuccess(user)
                            }
                    } else {
                        onFailure(Exception("Authenticated user is null"))
                    }
                }
                .addOnFailureListener { e ->
                    if (e is com.google.firebase.auth.FirebaseAuthInvalidUserException) {
                        onFailure(Exception("Account not found."))
                    } else if (e is com.google.firebase.auth.FirebaseAuthInvalidCredentialsException) {
                        onFailure(Exception("Wrong password."))
                    } else if (e is com.google.firebase.FirebaseNetworkException) {
                        onFailure(Exception("Network error. Please check your connection."))
                    } else {
                        onFailure(e)
                    }
                }
        } else {
            // Simulated local mode
            val simulatedUser = simulatedUsers[email.lowercase()]
            if (simulatedUser == null) {
                onFailure(Exception("There is no user record corresponding to this identifier. The user may have been deleted."))
                return
            }
            if (simulatedUser.password != password) {
                onFailure(Exception("The password is invalid or the user does not have a password."))
                return
            }
            val user = CivicUser(
                uid = "simulated-uid-" + email.hashCode(),
                displayName = simulatedUser.displayName,
                email = simulatedUser.email,
                photoUrl = "https://api.dicebear.com/7.x/adventurer/svg?seed=" + simulatedUser.displayName.replace(" ", ""),
                isAdmin = simulatedUser.isAdmin || checkIfAdmin(email)
            )
            _currentUser.value = user
            onSuccess(user)
        }
    }

    // OTP Firestore Storage
    fun sendOTP(email: String, onSuccess: (String) -> Unit, onFailure: (Exception) -> Unit) {
        val otp = (100000..999999).random().toString()
        val expiry = System.currentTimeMillis() + 10 * 60 * 1000 // 10 minutes
        val data = mapOf("otp" to otp, "expiry" to expiry)
        
        firestore?.collection("otp_codes")?.document(email.lowercase())?.set(data)
            ?.addOnSuccessListener {
                Log.d("AuthRepository", "OTP for $email: $otp")
                onSuccess(otp)
            }
            ?.addOnFailureListener { e -> onFailure(e) }
    }

    fun verifyOTP(email: String, otp: String, onSuccess: (Boolean) -> Unit, onFailure: (Exception) -> Unit) {
        firestore?.collection("otp_codes")?.document(email.lowercase())?.get()
            ?.addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    val storedOTP = document.getString("otp")
                    val expiry = document.getLong("expiry") ?: 0
                    
                    if (storedOTP == otp && System.currentTimeMillis() < expiry) {
                        onSuccess(true)
                    } else {
                        onFailure(Exception("Invalid or expired OTP"))
                    }
                } else {
                    onFailure(Exception("No OTP found for this email"))
                }
            }
            ?.addOnFailureListener { e -> onFailure(e) }
    }
    
    // High fidelity simulate sign-in for testing/emulator
    fun simulateGoogleSignIn(email: String, name: String, avatarUrl: String?, forceAdmin: Boolean = false) {
        val user = CivicUser(
            uid = "simulated-uid-" + email.hashCode(),
            displayName = name,
            email = email,
            photoUrl = avatarUrl ?: "https://api.dicebear.com/7.x/adventurer/svg?seed=" + name.replace(" ", ""),
            isAdmin = forceAdmin || checkIfAdmin(email)
        )
        _currentUser.value = user
        Log.d("AuthRepository", "Simulated Sign-In: User ${user.displayName} is now signed in.")
    }

    fun toggleAdminState(forceAdmin: Boolean) {
        val current = _currentUser.value ?: return
        _currentUser.value = current.copy(isAdmin = forceAdmin)
    }

    fun signOut() {
        try {
            firebaseAuth?.signOut()
            val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).build()
            val googleSignInClient = GoogleSignIn.getClient(context, gso)
            googleSignInClient.signOut()
        } catch (e: Exception) {
            Log.e("AuthRepository", "Error signing out from Firebase/Google Client", e)
        }
        _currentUser.value = null
        Log.d("AuthRepository", "User signed out.")
    }

    private fun displayNameFromEmail(email: String): String {
        return email.substringBefore("@").replace(".", " ").replaceFirstChar { it.uppercase() }
    }
}
