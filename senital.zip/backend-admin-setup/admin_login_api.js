const express = require('express');
const admin = require('firebase-admin');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const router = express.Router();
const db = admin.firestore();

// Rate limiting (simple in-memory for demonstration, prefer Redis in production)
const rateLimits = new Map();

router.post('/admin/login', async (req, res) => {
    const { email, password } = req.body;
    const ip = req.ip;

    // Rate limit check: 5 attempts per 15 minutes
    const now = Date.now();
    const limitInfo = rateLimits.get(ip) || { count: 0, firstAttempt: now };
    
    if (now - limitInfo.firstAttempt > 15 * 60 * 1000) {
        limitInfo.count = 0;
        limitInfo.firstAttempt = now;
    }

    if (limitInfo.count >= 5) {
        return res.status(429).json({ error: "Too many login attempts. Please try again in 15 minutes." });
    }

    limitInfo.count += 1;
    rateLimits.set(ip, limitInfo);

    if (!email || !password) {
        return res.status(401).json({ error: "Invalid credentials" }); // Generic message
    }

    try {
        const adminsRef = db.collection('admins');
        const snapshot = await adminsRef.where('email', '==', email).limit(1).get();

        if (snapshot.empty) {
            return res.status(401).json({ error: "Invalid credentials" }); // Generic message
        }

        const adminDoc = snapshot.docs[0];
        const adminData = adminDoc.data();

        const isPasswordValid = await bcrypt.compare(password, adminData.hashed_password);

        if (!isPasswordValid) {
            return res.status(401).json({ error: "Invalid credentials" }); // Generic message
        }

        // Generate JWT token scoped to "admin" role
        const token = jwt.sign(
            { 
                uid: adminDoc.id, 
                role: 'admin' 
            }, 
            process.env.JWT_SECRET, 
            { expiresIn: '4h' }
        );

        // Reset rate limit on success
        rateLimits.delete(ip);

        // Do not return email or hashed password
        res.json({ token });

    } catch (error) {
        console.error("Login error:", error);
        res.status(500).json({ error: "Internal server error" });
    }
});

module.exports = router;
