const admin = require('firebase-admin');
const bcrypt = require('bcrypt');
require('dotenv').config();

// Initialize Firebase Admin (assuming default application credentials are set)
admin.initializeApp();
const db = admin.firestore();

async function seedAdmin() {
    const email = process.env.ADMIN_EMAIL;
    const rawPassword = process.env.ADMIN_PASSWORD;

    if (!email || !rawPassword) {
        console.error("ADMIN_EMAIL and ADMIN_PASSWORD must be set in the environment.");
        process.exit(1);
    }

    try {
        const adminsRef = db.collection('admins');
        const snapshot = await adminsRef.limit(1).get();

        if (!snapshot.empty) {
            console.log("Admin account already exists. Skipping seed to enforce single-admin system.");
            process.exit(0);
        }

        const hashedPassword = await bcrypt.hash(rawPassword, 10);

        await adminsRef.add({
            email: email,
            hashed_password: hashedPassword,
            created_at: admin.firestore.FieldValue.serverTimestamp()
        });

        console.log(`Admin account seeded successfully for ${email}.`);
        process.exit(0);
    } catch (error) {
        console.error("Error seeding admin account:", error);
        process.exit(1);
    }
}

seedAdmin();
