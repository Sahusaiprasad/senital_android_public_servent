with open("app/src/main/java/com/example/model/Complaint.kt", "r") as f:
    text = f.read()

text = text.replace(
    'val priority: String = "NORMAL"\n)',
    'val priority: String = "NORMAL",\n    val upvoteCount: Int = 0\n)'
).replace(
    'priority = priority\n        )',
    'priority = priority,\n            upvoteCount = upvoteCount\n        )'
).replace(
    'val priority: String = "NORMAL"\n) {',
    'val priority: String = "NORMAL",\n    val upvoteCount: Int = 0\n) {'
)

with open("app/src/main/java/com/example/model/Complaint.kt", "w") as f:
    f.write(text)
