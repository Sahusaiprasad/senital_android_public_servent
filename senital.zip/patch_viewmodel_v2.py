with open("app/src/main/java/com/example/ui/CivicViewModel.kt", "r") as f:
    text = f.read()

# Add formPriority
text = text.replace(
    'val formCategory = MutableStateFlow(ComplaintCategory.ROADS)',
    'val formCategory = MutableStateFlow(ComplaintCategory.ROADS)\n    val formPriority = MutableStateFlow("NORMAL")'
)

# Add upvoteComplaint method
text = text.replace(
    '// Update status (Admin function)',
    'fun upvoteComplaint(id: String) {\n        viewModelScope.launch {\n            civicRepository.upvoteComplaint(id)\n        }\n    }\n\n    // Update status (Admin function)'
)

# Update submitComplaintForm (piece by piece)
text = text.replace(
    'userName = user.displayName',
    'userName = user.displayName,\n                    priority = formPriority.value'
)

# Reset formPriority
text = text.replace(
    'formCategory.value = ComplaintCategory.ROADS',
    'formCategory.value = ComplaintCategory.ROADS\n                formPriority.value = "NORMAL"'
)

with open("app/src/main/java/com/example/ui/CivicViewModel.kt", "w") as f:
    f.write(text)
