with open("app/src/main/java/com/example/ui/CivicViewModel.kt", "r") as f:
    content = f.read()

content = content.replace(
    'formLocation.value = "$formattedLat N, $formattedLng W (GPS Coordinates)"',
    'formLocation.value = "$formattedLat N, $formattedLng W (GPS Coordinates)"\n        formLatitude.value = lat\n        formLongitude.value = lng'
).replace(
    'formLocation.value = ""\n        formCategory.value = ComplaintCategory.ROADS',
    'formLocation.value = ""\n        formLatitude.value = null\n        formLongitude.value = null\n        formCategory.value = ComplaintCategory.ROADS'
)

with open("app/src/main/java/com/example/ui/CivicViewModel.kt", "w") as f:
    f.write(content)
