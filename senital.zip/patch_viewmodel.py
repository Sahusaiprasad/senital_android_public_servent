with open("app/src/main/java/com/example/ui/CivicViewModel.kt", "r") as f:
    text = f.read()

# Add formPriority
text = text.replace(
    'val formCategory = MutableStateFlow(ComplaintCategory.ROADS)',
    'val formCategory = MutableStateFlow(ComplaintCategory.ROADS)\n    val formPriority = MutableStateFlow("NORMAL")'
)

# Add upvoteComplaint method
text = text.replace(
    '// Update status (Admin function)',
    'fun upvoteComplaint(id: String) {\n        viewModelScope.launch {\n            civicRepository.upvoteComplaint(id)\n        }\n    }\n\n    // Update status (Admin function)'
)

# Update submitComplaintForm
import re
new_complaint_pattern = r'val newComplaint = Complaint\(\n\s*id = complaintId,\n\s*title = title,\n\s*description = description,\n\s*category = formCategory\.value\.name,\n\s*location = location,\n\s*latitude = formLatitude\.value \?\: \(34\.05 \+ \(Math\.random\(\) - 0\.5\) \* 0\.1\),\n\s*longitude = formLongitude\.value \?\: \(-118\.24 \+ \(Math\.random\(\) - 0\.5\) \* 0\.1\),\n\s*status = initialStatus,\n\s*attachmentType = formAttachmentType\.value\.name,\n\s*attachmentUrl = finalAttachmentUrl,\n\s*timestamp = System\.currentTimeMillis\(\),\n\s*userId = user\.email,\n\s*userName = user\.displayName'

replacement = new_complaint_pattern.replace('userName = user\.displayName', 'userName = user\.displayName,\n                    priority = formPriority.value')
text = re.sub(new_complaint_pattern, replacement, text)

# Reset formPriority
text = text.replace(
    'formCategory.value = ComplaintCategory.ROADS',
    'formCategory.value = ComplaintCategory.ROADS\n                formPriority.value = "NORMAL"'
)

with open("app/src/main/java/com/example/ui/CivicViewModel.kt", "w") as f:
    f.write(text)
