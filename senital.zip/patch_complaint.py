with open("app/src/main/java/com/example/model/Complaint.kt", "r") as f:
    content = f.read()

content = content.replace(
    'val location: String,',
    'val location: String,\n    val latitude: Double? = null,\n    val longitude: Double? = null,'
).replace(
    'location = location,',
    'location = location,\n            latitude = latitude,\n            longitude = longitude,'
)

with open("app/src/main/java/com/example/model/Complaint.kt", "w") as f:
    f.write(content)
