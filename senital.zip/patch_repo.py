with open("app/src/main/java/com/example/data/repository/CivicRepository.kt", "r") as f:
    text = f.read()

new_method = """    suspend fun upvoteComplaint(id: String) {
        withContext(Dispatchers.IO) {
            val complaint = complaintDao.getComplaintById(id)
            if (complaint != null) {
                val updatedComplaint = complaint.copy(upvoteCount = complaint.upvoteCount + 1)
                complaintDao.insertComplaint(updatedComplaint)
                
                // Sync to Firestore
                val fs = firestore
                if (fs != null) {
                    try {
                        fs.collection("complaints").document(id).update("upvoteCount", updatedComplaint.upvoteCount).await()
                    } catch (e: Exception) {
                        Log.e("CivicRepository", "Failed to sync upvote", e)
                    }
                }
            }
        }
    }

"""

# Insert before submitComplaint
text = text.replace(
    "    // Submit complaint",
    new_method + "    // Submit complaint"
)

with open("app/src/main/java/com/example/data/repository/CivicRepository.kt", "w") as f:
    f.write(text)
