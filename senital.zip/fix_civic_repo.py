import re

with open("app/src/main/java/com/example/data/repository/CivicRepository.kt", "r") as f:
    text = f.read()

# Pattern to find ComplaintEntity(...)
# This regex is simple but should match if there are no nested parentheses
pattern = re.compile(r'ComplaintEntity\((.*?)\)', re.DOTALL)

def replacer(match):
    content = match.group(1)
    if 'userEmail' not in content:
        # Find userId and insert userEmail after it
        content = re.sub(r'userId\s*=\s*([^,]+),', r'userId = \1,\n                                            userEmail = \1,', content)
        return f'ComplaintEntity({content})'
    return match.group(0)

new_text = pattern.sub(replacer, text)

with open("app/src/main/java/com/example/data/repository/CivicRepository.kt", "w") as f:
    f.write(new_text)
