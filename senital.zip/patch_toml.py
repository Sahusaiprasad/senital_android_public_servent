import re
with open("gradle/libs.versions.toml", "r") as f:
    content = f.read()

content = content.replace('[libraries]', 'mapsCompose = "4.4.1"\nplayServicesMaps = "19.0.0"\n\n[libraries]\nmaps-compose = { group = "com.google.maps.android", name = "maps-compose", version.ref = "mapsCompose" }\nplay-services-maps = { group = "com.google.android.gms", name = "play-services-maps", version.ref = "playServicesMaps" }')

with open("gradle/libs.versions.toml", "w") as f:
    f.write(content)
