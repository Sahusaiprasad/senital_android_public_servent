with open("gradle/libs.versions.toml", "r") as f:
    text = f.read()

text = text.replace('\n[libraries]\nmaps-compose-utils = ', '\nmaps-compose-utils = ')
with open("gradle/libs.versions.toml", "w") as f:
    f.write(text)
