with open("app/src/main/java/com/example/ui/CivicViewModel.kt", "r") as f:
    content = f.read()

content = content.replace(
    'val formLocation = MutableStateFlow("")',
    'val formLocation = MutableStateFlow("")\n    val formLatitude = MutableStateFlow<Double?>(null)\n    val formLongitude = MutableStateFlow<Double?>(null)'
)

with open("app/src/main/java/com/example/ui/CivicViewModel.kt", "w") as f:
    f.write(content)
